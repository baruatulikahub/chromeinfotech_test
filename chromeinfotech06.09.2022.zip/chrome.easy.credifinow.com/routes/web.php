<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','App\Http\Controllers\FrontController@index');
Route::get('index','App\Http\Controllers\FrontController@index')->name('index');
Route::get('colors','App\Http\Controllers\FrontController@colors')->name('colors');
Route::get('categories','App\Http\Controllers\FrontController@categories')->name('categories');
Route::get('products','App\Http\Controllers\FrontController@products')->name('products');
Route::get('sizes','App\Http\Controllers\FrontController@sizes')->name('sizes');
Route::post('apply_product_registration','App\Http\Controllers\FrontController@apply_product_registration')->name('apply_product_registration');
Route::post('apply_category_registration','App\Http\Controllers\FrontController@apply_category_registration')->name('apply_category_registration');
Route::post('apply_size_registration','App\Http\Controllers\FrontController@apply_size_registration')->name('apply_size_registration');
Route::post('apply_color_registration','App\Http\Controllers\FrontController@apply_color_registration')->name('apply_color_registration');
Route::get('thank_you','App\Http\Controllers\FrontController@thank_you')->name('thank_you');
Route::get('delete_size_details/{id}','App\Http\Controllers\FrontController@delete_size_details')->name('delete_size_details');
Route::get('delete_category_details/{id}','App\Http\Controllers\FrontController@delete_category_details')->name('delete_category_details');
Route::get('delete_color_details/{id}','App\Http\Controllers\FrontController@delete_color_details')->name('delete_color_details');
Route::get('edit_size_details','App\Http\Controllers\FrontController@edit_size_details')->name('edit_size_details');
Route::get('edit_color_details','App\Http\Controllers\FrontController@edit_color_details')->name('edit_color_details');
Route::get('edit_category_details','App\Http\Controllers\FrontController@edit_category_details')->name('edit_category_details');
Route::post('update_size_details','App\Http\Controllers\FrontController@update_size_details')->name('update_size_details');
Route::post('update_category_details','App\Http\Controllers\FrontController@update_category_details')->name('update_category_details');
Route::post('update_color_details','App\Http\Controllers\FrontController@update_color_details')->name('update_color_details');





