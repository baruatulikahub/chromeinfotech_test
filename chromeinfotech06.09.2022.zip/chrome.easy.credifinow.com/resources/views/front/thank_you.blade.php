@extends('front.layout')
@section('content')

<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Source+Sans+Pro" rel="stylesheet">

<div class="content" style="margin-top:10px;">
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you !</h1>
      <p>Your data is successfully registered!  </p>
      <button class="go-home">
      <a href="{{route('index')}}">go to product page</a>
      </button>
    </div>
</div>
</div>



<br>



@endsection