@extends('front.layout')
@section('content')

  
  <div class="st-content" >
   
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
        <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 470px;">
        
            <aside class="col-lg-9 extended-card form-card">
                    <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                    <br>
              		<form method="post" class="comment-form" action="{{ route('apply_category_registration')}}">
              		    @csrf
              			    <p class="comment-form-author text">
                  			    <input name="cat_name" type="text" placeholder="Category Name*" required="">
              			    </p>
              			    <p class="form-submit">
                  				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Save <i class="fa fa-arrow-right push-right"></i></span></button>
                  			</p>
              		</form>
              		
            </aside>
        
        </div>

    </div>
    
    <div>
        
        <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                @if(Session::has('categorymsg'))                 
                    <div class="alert alert-{{Session::get('message')}} alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong>{{Session::get('categorymsg')}}</strong>
                    </div>
                    {{Session::forget('message')}}
                    {{Session::forget('categorymsg')}}
                @endif
            </div>
        </div>
              <table id="memberProfile">
                
                <tr>
                  <td><strong>Sl No.</strong></td>
                  <td><strong>Category Name</strong></td>
                  <td><strong>Edit</strong></td>
                  <td><strong>Delete</strong></td>
                </tr>
                <?php 
                    foreach ($category_details as $c) {
                ?>
                <tr>
                  <td><?php echo $c->id; ?></td>
                  <td><?php echo $c->cat_name; ?></td>
                  <td class="">
                    <a class="dropdown-item" href="<?php echo route('edit_category_details',['id'=>''.$c->id.'']) ?>" data-toggle="modal" data-target="#" >Edit <i class="fa fa-pencil" aria-hidden="true"></i></a>
                  </td>
                  <td class="">
                    <a class="dropdown-item" onclick="alert('Are You Sure To Delete This?')" href="<?php echo route('delete_category_details',['id'=>''.$c->id.'']) ?>" >Delete <i class="fa fa-trash" aria-hidden="true"></i></a>
                  </td>
                </tr>
                <?php } ?>
              
              </table>
    </div>
    <br>

  </div>

@endsection