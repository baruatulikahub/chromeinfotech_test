@extends('front.layout')
@section('content')


<?php 
    foreach ($size_details as $s) {
?>
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 600px;">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
                <form method="post" action="{{route('update_size_details')}}" enctype="multipart/form-data">
                                                    @csrf
                                                    <div class="row">
                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled" id="user_purpose">
                                                          <label class="form-control-label" for="input-username">Size</label>
                                                          <select name="sort"  class="form-control" required>
                          
                                                              <?php 
                                                                foreach ($size_details as $s) {
                                                             
                                                              ?>
                                                                <option value="<?php echo $s->id; ?>"><?php echo $s->sort; ?></option>
                                                              <?php } ?>
                                                          </select>
                                                            @if ($errors->has('sort'))
                                                              <strong class="text-danger">{{ $errors->first('sort') }}</strong>                                   
                                                            @endif
           
                                                        </div>
                                                      </div>

                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled">
                                                          <label class="form-control-label" for="input-username">Size Code </label>
                                                          <input type="hidden" class="form-control" name="update" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                                          <input type="text" name="code" id="input-username" class="form-control" Value="<?php echo $s->code?>" placeholder="Size Code">
                                                          @if ($errors->has('code'))
                                                            <strong class="text-danger">{{ $errors->first('code') }}</strong>                                   
                                                          @endif
                                                        </div>
                                                      </div>
                
                                                      <div class="col-sm-12">
                                                        <div class="form-group bmd-form-group">
                                                            <button type="submit" class="st-btn st-style1 st-size1 st-color1">Update</button>
                                                        </div>
                                                      </div>
                
                                                    </div>
                                                </form>
        </aside> 	
      </div>
      
    </div>
    
  </div>
  
<?php } ?>

@endsection