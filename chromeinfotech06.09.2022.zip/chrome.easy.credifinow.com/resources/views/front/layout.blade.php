<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
  <!-- Meta Tags -->
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="laralink" />
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <!-- Page Title -->
  <title>ChromeInfotech-Interview For PHP Developer(Assignment) </title>
  <!-- Stylesheets -->
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/bootstrap.min.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/owlCarousel.min.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/fontawesome.min.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/flaticon.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/animate.css') }}" />
  <link rel="stylesheet" href="{{ URL::asset('public/front/assets/css/style.css') }}" />

</head>

<body>
  <header class="st-header st-style1 st-sticky-menu">
    <div class="st-main-header">
      <div class="container">
        <div class="st-main-header-in">
          <div class="st-site-branding">
            <a href="{{route('index')}}" class="st-logo-link" target="_blank">
                <img src="{{ URL::asset('public/front/assets/img/logo/unnamed.png') }}" alt="demo">
            </a>
          </div>
     
          <div class="st-nav-wrap st-fade-down">
            <div class="st-nav-toggle st-style1">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </div>
            <nav class="st-nav st-desktop-nav">
              <ul class="st-nav-list onepage-nav">
                <li><a href="{{route('index')}}" target="_blank" class="smooth-scroll">Products </a></li>
                <li><a href="{{route('categories')}}" class="smooth-scroll">Category </a></li>
                <li><a href="{{route('colors')}}" class="smooth-scroll">Colors </a></li>
                <li><a href="{{route('sizes')}}" class="smooth-scroll">Size </a></li>
              </ul>
            </nav>
       
          </div><!-- .st-nav-wrap -->
        </div>
      </div>
    </div>
  </header>
  
  @yield('content')
  
  <!-- Start Footer Seciton -->

  <footer class="st-site-footer st-style1 st-sticky-footer">
    
    <div class="st-copyright text-center">
        <div class="st-copyright-text">© Copyright 2022. All Rights Reserved</div>
    </div>
    
  </footer>
  
  <!-- End Footer Seciton -->

  <!-- Scripts -->
  <script src="{{ URL::asset('public/front/assets/js/vendor/modernizr-3.5.0.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/vendor/jquery-1.12.4.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/mailchimp.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/owlCarousel.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/tamjid-counter.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/wow.min.js') }}"></script>
  <script src="{{ URL::asset('public/front/assets/js/main.js') }}"></script>
  
</body>
</html>