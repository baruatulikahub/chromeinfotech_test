@extends('front.layout')
@section('content')

  
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
          		<form method="post" class="comment-form" action="{{ route('apply_product_registration')}}">
          		    @csrf
          		        <p class="comment-form-author text">
          				    <input name="pname" type="text" placeholder="Product Name*" required="">
          			    </p>
              		
          			    <p class="comment-form-author text">
          			        <select name="category_id"  class="form-control" required>
                          
                                      <?php 
                                        foreach ($category_details as $c) {
                                     
                                      ?>
                                        <option value="<?php echo $c->cat_name; ?>"><?php echo $c->cat_name; ?></option>
                                      <?php } ?>
                                    </select>
                                    @if ($errors->has('cat_name'))
                                      <strong class="text-danger">{{ $errors->first('cat_name') }}</strong>                                   
                                    @endif
                  			</select>
          			    </p>
          			    
          			    <p class="comment-form-author text">
              			    <select name="color_id"  class="form-control" required>
                          
                                      <?php 
                                        foreach ($color_details as $c) {
                                     
                                      ?>
                                        <option value="<?php echo $c->name; ?>"><?php echo $c->name; ?></option>
                                      <?php } ?>
                                    </select>
                                    @if ($errors->has('name'))
                                      <strong class="text-danger">{{ $errors->first('name') }}</strong>                                   
                                    @endif
                  			</select>
          			    </p>
          			    <p class="comment-form-author text">
   
                  			<select name="size_id"  class="form-control" required>
                          
                                      <?php 
                                        foreach ($size_details as $s) {
                                     
                                      ?>
                                        <option value="<?php echo $s->sort; ?>"><?php echo $s->sort; ?></option>
                                      <?php } ?>
                                    </select>
                                    @if ($errors->has('sort'))
                                      <strong class="text-danger">{{ $errors->first('sort') }}</strong>                                   
                                    @endif
                  			</select>
          			    </p>
          			    <p class="comment-form-email text-amt" style="width: 96.3333%;">
          			        <label style="color: #1caffd;">Product Price*</label>
              				<input name="price" type="text" placeholder="Product Price" value="0" required="">
              			</p>
              			
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Save <i class="fa fa-arrow-right push-right"></i></span></button>
              			</p>
          		</form>
          		
        </aside> 	
      </div>
      
    </div>
    
    
    <div>
      <table id="memberProfile">
        
        <tr>
          <td><strong>Product Name</strong></td>
          <td><strong>Color</strong></td>
          <td><strong>Category</strong></td>
          <td><strong>Size</strong></td>
          <td><strong>Price</strong></td>
        </tr>
        <?php 
            foreach ($product_details as $p) {
                    
        ?>
        <tr>
          <td><?php echo $p->pname; ?></td>
          <td><?php echo $p->color_id; ?></td>
          <td><?php echo $p->category_id; ?></td>
          <td><?php echo $p->size_id; ?></td>
          <td>₹ <?php echo $p->price; ?></td>
        </tr>
        <?php } ?>
      
      </table>
    </div>
    
    <br>

  </div>

@endsection