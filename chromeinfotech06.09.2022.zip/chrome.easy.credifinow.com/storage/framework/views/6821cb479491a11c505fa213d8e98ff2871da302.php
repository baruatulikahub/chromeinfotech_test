
<?php $__env->startSection('content'); ?>

  <div class="st-blog-wrap st-section" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <article class="post">
          	<header class="entry-header">
          	    <div class="post-details-wrap-outer">
          			<div class="post-details-wrap">
          				<h2 class="entry-title">Gold loan is your key to fastest cash</h2>
          				<p class="h4-font">Get your loan disbursed in minutes, at interest rates starting from  0.49% only</p>
          			</div>
          		</div>
          		<div class="">
          			<img src="<?php echo e(URL::asset('public/front/assets/img/light-img/gold-loan-banner.png')); ?>" alt="demo">
          		</div>
          	</header>
          </article>
        </div>
        <aside class="col-lg-4">
          <div class="st-sidebar st-right-sidebar">
            <div class="widget widget_categories">
              <h2 class="widget-title">Basic Details</h2>
              <div class="credit_card_box marg20t banner-box-shadow pad20t">
              <div class="row">
                  <div class="col-lg-8 ml-auto mr-auto">
                      <?php if(Session::has('regmsg')): ?>                 
                          <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                               <strong><?php echo e(Session::get('regmsg')); ?></strong>
                          </div>
                          <?php echo e(Session::forget('message')); ?>

                          <?php echo e(Session::forget('regmsg')); ?>

                      <?php endif; ?>
                  </div>
              </div>
              <div class="comment-respond">
          		<form method="post" class="comment-form" action="<?php echo e(route('gold_loan_registration')); ?>">
                        <?php echo csrf_field(); ?>
                        
          		        <p class="comment-form-author text">
          				    <input name="fname" type="text" placeholder="First &amp; Last Name (as per PAN card)*" required="">
          			    </p>
          	
              			<p class="comment-form-email text">
              				<input name="email" type="email" placeholder="E-mail Address*" required="">
              			</p>
              			
              			<p class="comment-form-url text">
              			    <label style="color: #1caffd;">10 digit mobile number</label>
              				<input id="url" name="mobile" type="tel" maxlength="10" placeholder="Phone Number*" required="">
              			</p>

              			<p class="comment-form-author text">
          				    <input name="pincode" type="text" placeholder="Current residence pincode" required="">
          			    </p>
          			    
          			    <p class="comment-form-email text">
          			        <label style="color: #1caffd;">Required Loan Amount</label>
              				<input name="amount" type="text" placeholder="Required Loan Amount" value="₹ 0" required="">
              			</p>
              			
              			<p class="comment-form-url text">
              				<input id="url" name="quantity" type="text" maxlength="10" placeholder="Jewellery Quantity (min 10gm.)" required="">
              			</p>
              			
              			<p class="comment-form-author text">
              			    <label style="color: #1caffd;">Employment Type</label>
              			    <select class="form-control" name="employment">
                  				    <option>--- Select Employment Type ---</option>
                  				    <option value="Salaried">Salaried</option>
                  				    <option value="Self Employed">Self Employed</option>
                  			</select>
          			    </p>
          			    
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1"><span>Proceed</span></button>
              			</p>
          			    
          		</form>
          	  </div>
          	  </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
  
  <div class="pg-footer">
    <footer class="footer">
      
      <div class="footer-content">
        <div class="footer-content-column">
          
          <div class="footer-menu">
            <h2 class="footer-menu-name"> Personal Loans</h2>
            <ul id="menu-get-started" class="footer-menu-list">
              <?php
                    foreach($personal_loan_bank_details as $a) { 
                    $urll = route('personal_loan_',['name'=>''.$a->name.'']);
              ?>
                                    
              <li class="menu-item menu-item-type-post_type menu-item-object-product">
                <a href="<?php echo $urll; ?>" title="<?php echo $a->name; ?> Personal Loan"><?php echo $a->name; ?> Personal Loan</a>
              </li>
              
              <?php }  ?>
              
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">ICICI Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Capital First Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Bajaj Finserv Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">ICICI Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Kotak Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Yes Bank Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Small Amount Personal Loan</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-product">-->
              <!--  <a href="#">Personal Loan Balance Transfer</a>-->
              <!--</li>-->
            </ul>
          </div>
        </div>
        <div class="footer-content-column">
          <div class="footer-menu">
            <h2 class="footer-menu-name"> Credit Cards</h2>
            <ul id="menu-company" class="footer-menu-list">
              <?php
                    foreach($personal_credit_card_bank_details as $a) { 
                    $urll = route('credit_card_',['name'=>''.$a->name.''],'_bank');
              ?>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="<?php echo $urll; ?>" title="<?php echo $a->name; ?> Bank Credit Card"><?php echo $a->name; ?> Bank Credit Card</a>
              </li>
              <?php }  ?>
              <!--<li class="menu-item menu-item-type-taxonomy menu-item-object-category">-->
              <!--  <a href="#">Citi Bank Credit Card</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-post_type menu-item-object-page">-->
              <!--  <a href="#">HDFC Bank Credit Card</a>-->
              <!--</li>-->
              <!--<li class="menu-item menu-item-type-taxonomy menu-item-object-category">-->
              <!--  <a href="#">ICICI Bank Credit Card</a>-->
              <!--</li>-->
            </ul>
          </div>
       
        </div>
        <div class="footer-content-column">
          <div class="footer-menu">
            <h2 class="footer-menu-name"> Company</h2>
            <ul id="menu-quick-links" class="footer-menu-list">
              <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" rel="noopener noreferrer" href="#">About Us</a>
              </li>
              <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" rel="noopener noreferrer" href="<?php echo e(route('terms_conditions')); ?>">Terms & Conditions</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="<?php echo e(route('privacy_policy')); ?>">Privacy Policy</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="<?php echo e(route('contact_us')); ?>">Contact Us</a>
              </li>
              
            </ul>
          </div>
        </div>
        <div class="footer-content-column">
          <div class="footer-call-to-action">
            <h2 class="footer-call-to-action-title"> Trending Pages</h2>

            <ul id="menu-quick-links" class="footer-menu-list">
              <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" rel="noopener noreferrer" href="<?php echo e(route('credit_report')); ?>">Credit Report</a>
              </li>
              <li class="menu-item menu-item-type-custom menu-item-object-custom">
                <a target="_blank" rel="noopener noreferrer" href="<?php echo e(route('emi_calculator')); ?>">Emi Calculator</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="#">IFSC Code</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="#">Blog</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page">
                <a href="<?php echo e(route('faqs')); ?>">FAQ’s</a>
              </li>
            </ul>
            
          </div>
          
        </div>
        
      </div>
      
    </footer>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/gold_loan.blade.php ENDPATH**/ ?>