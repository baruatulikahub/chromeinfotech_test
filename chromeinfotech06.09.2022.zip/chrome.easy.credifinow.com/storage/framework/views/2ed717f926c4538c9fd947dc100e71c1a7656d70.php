
<?php $__env->startSection('content'); ?>

  <br>
 
  <div class="section gray padding-top-100">
    <div class="container">
      <div class="row">
        <div class="col-xl-12"> 
          <div class="utf-section-headline-item centered margin-top-0 margin-bottom-40">
              
            <span>My Portal | Designed in Laravel</span>
			<h3>Employee & Admin</h3>
			<a href="<?php echo e(route('signin')); ?>"><span>Sign In <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a>
            
          </div>
        </div>
	
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/index.blade.php ENDPATH**/ ?>