
<?php $__env->startSection('content'); ?>

<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Source+Sans+Pro" rel="stylesheet">

<div class="content" style="margin-top:10px;">
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you !</h1>
      <p>Your loan application is now successfully registered!  </p>
      <p>Our team will get back to you shortly.  </p>
      <button class="go-home">
      <a href="<?php echo e(route('index')); ?>">go home</a>
      </button>
    </div>
    <div class="footer-like">
      <p>If you require any further information,
       <a href="#"> feel free to contact us.</a>
      </p>
    </div>
</div>
</div>



<br>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/thank_you.blade.php ENDPATH**/ ?>