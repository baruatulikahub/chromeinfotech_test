
<?php $__env->startSection('content'); ?>
  <!-- Header Container / End -->

  <br><br><br><br>
  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-xl-6 offset-xl-3">

        <div class="row">
          <div class="col-lg-8 ml-auto mr-auto">
              <?php if(Session::has('regmsg')): ?>                 
                  <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                       <strong><?php echo e(Session::get('regmsg')); ?></strong>
                  </div>
                  <?php echo e(Session::forget('message')); ?>

                  <?php echo e(Session::forget('regmsg')); ?>

              <?php endif; ?>
          </div>
        </div>
        
        <div class="utf-login-register-page-aera"> 
          <div class="utf-welcome-text-item">
             <h3>Create your Account!</h3>
             <span>Already Have an Account? <a href="<?php echo e(route('signin')); ?>" style="color:blue">Sign In!</a></span> 
		  </div>
          <form method="post" id="utf-register-account-form" action="<?php echo e(route('user_registration')); ?>">
            <?php echo csrf_field(); ?>
          
          <div class="row">
              <div class="col-md-3">
                <label for="start" style="margin-top: 10px;">User Name:*</label>
              </div>
              <div class="col-md-9">
              <input type="text" class="utf-with-border" name="user_name" id="name" placeholder="User Name" required/>
                <?php if($errors->has('user_name')): ?>
                    <strong class="text-danger"><?php echo e($errors->first('user_name')); ?></strong>                                  
                <?php endif; ?>
              </div>
          </div>
      
          
          <div class="row">
            <div class="col-md-3">
                <label for="start" style="margin-top: 10px;">Email Address:*</label>
            </div>
            <div class="col-md-9">
            <input type="email" class="utf-with-border" name="email" id="email" placeholder="Email Address" required/>
            <?php if($errors->has('email')): ?>
                <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>                                  
            <?php endif; ?>
            </div>
          </div>
          
          <div class="row" title="Should be at least 8 characters long" data-tippy-placement="bottom">
            <div class="col-md-3">
                <label for="start" style="margin-top: 10px;">Password:*</label>
            </div>
            <div class="col-md-9">
            <input type="password" class="utf-with-border" name="password" id="password-register" placeholder="Password" required/>
            <!--<span toggle="#password-register" class="fa fa-eye-slash field-icon toggle-password"></span>-->
             <?php if($errors->has('password')): ?>
                <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>                                  
            <?php endif; ?>
            </div>
          </div>

          <div class="row"  data-tippy-placement="bottom">
            <div class="col-md-3">
                <label for="start" style="margin-top: 10px;">User Type:*</label>
            </div>
            <div class="col-md-9">
            <select name="user_type" id="role" required>
              <option value="">Choose Role</option>
              <option value="Admin">Admin</option>
              <option value="Employee">Employee</option>
              
            </select>
             <?php if($errors->has('user_type')): ?>
                <strong class="text-danger"><?php echo e($errors->first('user_type')); ?></strong>                                  
            <?php endif; ?>
            </div>
          </div>

        </form>
          <button class="margin-top-10 button full-width utf-button-sliding-icon ripple-effect" type="submit" form="utf-register-account-form">Register <i class="fa fa-arrow-right"></i></button>
          
          
        </div>
      </div>
    </div>
  </div>
  
  
  <br><br>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
  
  <script>
      $(".toggle-password").click(function() {

      $(this).toggleClass("fa-eye fa-eye-slash");
      var input = $($(this).attr("toggle"));
      if (input.attr("type") == "password") {
        input.attr("type", "text");
      } else {
        input.attr("type", "password");
      }
    });
  </script>
  
  
  <!-- Subscribe Block Start -->
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/register.blade.php ENDPATH**/ ?>