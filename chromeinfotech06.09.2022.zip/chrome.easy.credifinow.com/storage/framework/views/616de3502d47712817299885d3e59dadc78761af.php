
<?php $__env->startSection('content'); ?>
    
    <!-- Header -->
    <div class="header  pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0"></h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Credit Card Tables</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Credit Card Users</li>
                </ol>
              </nav>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
       <div class="row">
          <div class="col-lg-12 ml-auto mr-auto">
              <?php if(Session::has('jobseekermsg')): ?>                 
                  <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                       <strong><?php echo e(Session::get('jobseekermsg')); ?></strong>
                  </div>
                  <?php echo e(Session::forget('message')); ?>

                  <?php echo e(Session::forget('jobseekermsg')); ?>

              <?php endif; ?>
          </div>
        </div>
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Credit Card Users List </h3>
              <span data-href="<?php echo e(route('export-creditcard')); ?>" id="export" class="btn btn-success btn-sm" onclick="exportTasks(event.target);" style="float: right;">
                  <i class="fa fa-download"></i> Export
              </span>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="budget">Full Name </th>
                    <th scope="col" class="sort" data-sort="budget">Mobile </th>
                    <th scope="col" class="sort" data-sort="budget">Email </th>
                    <th scope="col" class="sort" data-sort="budget">Gender </th>
                    <th scope="col" class="sort" data-sort="budget">DOB </th>
                    <th scope="col" class="sort" data-sort="budget">Pincode </th>
                    <th scope="col" class="sort" data-sort="budget">Pan Number </th>
                    <th scope="col" class="sort" data-sort="budget">Company </th>
                    <th scope="col" class="sort" data-sort="budget">Income </th>
                    <th scope="col" class="sort" data-sort="budget">Employment </th>
                    <th scope="col" class="sort" data-sort="budget">Do you have an existing credit card? </th>
                    <th scope="col" class="sort" data-sort="budget">Card Name </th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody class="list">
                  <?php 
                    foreach ($credit_card_user_listdetails as $u) {
                  ?>
                    <tr>
                 
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->fname; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->mobile; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->email; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->gender; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->dob; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->pincode; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->pannumber; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->company; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->income; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->employment; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->existing; ?></span>
                        </span>
                      </td>
                      
                      <td>
                        <span class="badge badge-dot mr-4">
                          <span class="status"><?php echo $u->cardname; ?></span>
                        </span>
                      </td>
                  
                      <td class="">
                        <div class="dropdown">
                          <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="javascript:void();" data-toggle="modal" data-target="#myeditModal<?php echo $u->id; ?>" >Edit</a>
                          </div>
                        </div>
                      </td>
                      
                    </tr>

                    
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- Card footer -->
            <div class="card-footer py-4">
              <nav aria-label="...">
                <ul class="pagination justify-content-end mb-0">
                  
                  <?php echo $credit_card_user_listdetails->links("pagination::bootstrap-4"); ?> 
                  
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/credit_carduser_lists.blade.php ENDPATH**/ ?>