
<?php $__env->startSection('content'); ?>
  <!-- Main content -->
  
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
         
            </div>
            <div class="col-lg-6 col-5 text-right">
             
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('loginerrmsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('loginerrmsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('loginerrmsg')); ?>

                <?php endif; ?>
            </div>
        </div>
          <!-- Card stats -->
          <div class="row">
            
            <div class="col-xl-3 col-md-6">
              <div class="card card-stats">
                <!-- Card body -->
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Personal Loan users</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo e($personal_loans); ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                        <i class="ni ni-money-coins"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
              <div class="card card-stats">
                <!-- Card body -->
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Business Loan users</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo e($business_loans); ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                        <i class="ni ni-chart-pie-35"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
              <div class="card card-stats">
                <!-- Card body -->
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Gold Loan users</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo e($gold_loans); ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                        <i class="ni ni-active-40"></i>
                      </div>
                    </div>
                  </div>
                 
                </div>
              </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
              <div class="card card-stats">
                <!-- Card body -->
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Total Visitors</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo e($total_visitor); ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                        <i class="ni ni-chart-bar-32"></i>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
    
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>