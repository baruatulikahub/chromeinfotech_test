
<?php $__env->startSection('content'); ?>
  <!-- Main content -->

    <!-- Header -->
    <div class="header pb-6 d-flex align-items-center" style="min-height: 150px; background-size: cover; background-position: center top;">
      
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
        
      <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
               <?php if(Session::has('resourcesmsg')): ?>                
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                       <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> 
                         <strong><?php echo e(Session::get('resourcesmsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('resourcesmsg')); ?>

                <?php endif; ?>
            </div>
      </div>   
      
      <div class="row">
        
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            
            <div class="card-body">
              <form method="post" action="<?php echo e(route('submit_blog_details')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h6 class="heading-small text-muted mb-4">Blog Details</h6>
                <div class="pl-lg-4">
                  <div class="row">
                    
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Added By</label>
                        <input type="text" id="input-username" name="blogger" class="form-control" placeholder="Added By (Name)">
                        <?php if($errors->has('blogger')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('blogger')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Heading</label>
                        <input type="text" id="input-username" name="heading" class="form-control" placeholder="Heading">
                        <?php if($errors->has('heading')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('heading')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Posted Date</label>
                        <input type="text" id="input-username" name="mdate" class="form-control" placeholder="22 May 2020">
                        <?php if($errors->has('mdate')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('mdate')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-first-name"> Upload image</label>
                        <input type="file" class="form-control" name="blog_image" id="image" accept="image/*">
                        
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Description</label>
                        <textarea type="text" class="ckeditor" id="input-username" name="description" class="form-control" placeholder="Description" rows="4" cols="60"></textarea>
                      </div>
                    </div>
                    
                    
                  </div>
                 
                </div>

                <div class="col-sm-4">
                    <div class="form-group bmd-form-group">
                        <button type="submit" class="btn btn-success btn-block">Submit</button>
                    </div>
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
    </div>  

<?php $__env->stopSection(); ?>
 
  
<?php echo $__env->make('blogger.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/blogger/blogger_add_blog.blade.php ENDPATH**/ ?>