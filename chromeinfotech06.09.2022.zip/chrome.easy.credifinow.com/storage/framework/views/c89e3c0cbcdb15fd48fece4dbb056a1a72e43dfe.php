
<?php $__env->startSection('content'); ?>


<div style="margin-top: 65px;">
    <form name="plshortform">
        <section class="light-grey-bg pt-5 pb-md-5 pl-page">
            <div class="container">
                <div class="animation-element row">
                    <div class="col-md-12">
                        <div class="bottom-fadein mb-4 text-center">
                            
                                    <h1 class="col-12 p-0 mb-md-5 mb-4 mob-heading mt-4" style="color: #6262a0;">
                                        <?php echo e($newString); ?><span><b style="color: #FFB72E; font-weight: 700;"></b></span>
                                    </h1>
                            
                            <h3 class="pl-0 pr-0 pb-0 mt-4">
                                Get the lowest Personal loan interest rates starting from 10.25% per annum.
                            </h3>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </form>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
            <div class="row">
                  <div class="col-lg-8 ml-auto mr-auto">
                      <?php if(Session::has('regmsg')): ?>                 
                          <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                               <strong><?php echo e(Session::get('regmsg')); ?></strong>
                          </div>
                          <?php echo e(Session::forget('message')); ?>

                          <?php echo e(Session::forget('regmsg')); ?>

                      <?php endif; ?>
                  </div>
            </div>
            <div class="comment-respond">
                  		<h2 class="comment-reply-title">Check Loan Eligibility</h2>
                  		<p>Let's Get Started Please Provide Your Basic Details</p>
                  		<form method="post" class="comment-form" action="<?php echo e(route('personal_loan_registration')); ?>">
                  		     <?php echo csrf_field(); ?>
                  			<p class="comment-form-comment">
                  			    <label for="dob">Full Name (As per PAN Card)</label>
                  				<input name="fname" type="text" placeholder="Full Name (As per PAN Card)*" required="">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label for="gender">Gender</label>
                  				<select class="form-control" name="gender">
                  				    <option>--- Select Gender Type ---</option>
                  				    <option name="gender" value="Male">Male</option>
                  				    <option name="gender" value="Female">Female</option>
                  				</select>
                  			</p>
                  			<p class="comment-form-email">
                  			    <label for="dob">Mobile Number</label>
                  				<input name="mobile" type="tel" maxlength="10" placeholder="Mobile Number*" required="">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label for="dob">Email Address</label>
                  				<input name="email" type="email" placeholder="Email Address*" required="">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label for="dob">Date of Birth as per your PAN</label>
                  				<input name="dob" type="date" placeholder="Date of Birth as per your PAN" required="">
                  			</p>
                  			<p class="comment-form-email">
                  			    <label for="dob">Enter your 10 digit PAN Number!</label>
                  				<input name="pannumber" type="text" placeholder="10 digit PAN number" required="">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label>Current Company Name</label>
                  				<input name="company" type="text" placeholder="Enter Company Name">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label>Current Residence Pincode</label>
                  				<input name="pincode" type="number" placeholder="Enter your Residence Pincode">
                  			</p>
                  			<p class="comment-form-email">
                  			    <label>Monthly in-hand Salary</label>
                  				<input name="income" type="text" placeholder="Enter your Income">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label>Employment Type</label>
                  				<select class="form-control" name="employment">
                  				    <option>--- Select Employment Type ---</option>
                  				    <option value="Salaried">Salaried</option>
                  				    <option value="Self Employed">Self Employed</option>
                  				    <option value="Self Employed (Dr./CA)">Self Employed (Dr./CA)</option>
                  				</select>
                  			</p>
                  			<p class="form-submit">
                  				<button type="submit" class="st-btn st-style1 st-size1 st-color1"><span>Verify Now</span> <i class="fa fa-arrow-right"></i></button>
                  			</p>
                  		</form>
            </div>
        </div>
      </div>
    </div>
</div>

<section class="light-grey-bg section-padding">
            <div class="container text-left">
                <div>
                    <p class="heading-bold mob-heading">
                        Personal Loans in Kolkata
                    </p>
                </div>
                <div>The Personal loan in Kolkata is one of the most popular financing options. This city has many lenders including top banks and non-banking financial companies (NBFCs) that provide best-in-class personal loans at best interest rates starting from 10.25% with flexible tenure and easy EMIs.<br><br>  
                
                <b>The most common reasons for applying for a Personal loan in Kolkata</b>
                    
                <br> • A Personal loan is obtained for various purposes such as paying off medical bills, home renovation, wedding expenses, personal durable goods, travel expenses, or any other financial emergencies.<br>      
                • If you want to pay off multiple unpaid loans by opting for debt consolidation or Personal loan balance transfer.<br><br>  
                <b>Special features:</b><br>      • Loan Amount Eligibility: Rs 25000- Rs 25 Lakh<br>      • Easy and simple loan application<br>      • Flexible loan Tenure- 1- 5 years<br>      • Low-interest rate loans with several attractive features<br>      • Minimal documentation <br>      • Easy EMIs<br><br>  
                Eligibility criteria to apply for a Personal loan in Kolkata<br>  
                <b>Nationality:</b>  Must be the resident of India<br> 
                <b>Age</b> – Minimum age is 21 years, and the maximum is 60 years<br>  
                <b>Credit Score:</b> You should have a good credit score, 700 or above<br>  
                <b>Monthly Income requirement:</b>  Rs 20,000 per month<br>  
                <b>Work Experience</b><br><br>  
                <b>Salaried</b><br>  
                Employed at the current company for at least 6/12 months<br><br>  
                <b>Self-Employed</b><br>      • Business tenure of at least 3 years (continuous)<br>      • ITR of last 3 years<br><br>  You can also check your loan eligibility by visiting our website. Moreover, we have an efficient personal loan EMI calculator which will help you get an idea of how much loan amount you should borrow. Further, you can also benefit from our free credit report service before applying for a loan which gives an in-depth analysis of your credit history.<br><br>  
                The documents required to apply for a Personal loan in Kolkata<br>  
                Salaried and Self-employed<br>  Identity &amp; Age Proof: Aadhaar Card, PAN Card, Birth Certificate, Passport, Voter ID, etc.<br>  Filled personal loan application with photograph<br>  Residence proof - Passport driving license, Voter ID, post-paid/landline bill, utility bills (electricity/water/gas)<br><br>  
                <b>Income Proof for Salaried</b><br>      • Salary Slips of last 3 months<br>      • Form 16 or Income Tax Returns of last 3 years<br><br> 
                <b>Income proof for self-employed</b><br>      • Last 3 years Income Tax Returns with computation of Income<br>      • Last 3 years CA Certified / Audited Balance Sheet and Profit &amp; Loss Account<br><br>    
                How Loans can help in getting a Personal loan in Kolkata<br>  Loans is a one-stop solution for all your financial needs. We try to provide you with the best services that are hassle-free and quick in nature. For personal loans in Kolkata, we provide you with a comparative analysis of what different banks are offering and help you in picking up the best.<br><br>  
                Here are the main benefits of availing of Personal loan in Kolkata<br>      • Convenience<br>      • 100% transparency<br>      • Real time customer support <br>      • We get you the lowest interest rate loan offers from multiple Banks and NBFCs<br>      • Compare offers online<br>      • We handle everything for you ranging from documentation to disbursal. <br><br>  Our experienced financial team takes care of your credit needs and finds a good personal loan offer for you. We evaluate your profile and match them against the eligibility criteria of various financial institutions. After the careful analysis of available offers, we pick the best proposal for you<br>  Instead of visiting a bank, natives of Kolkata can take advantage of the online services of FinTech companies like Loans. Our services are completely free, and you can get some of the best personal loan offers in Kolkata.
                <p></p>
                </div>
            </div>
</section>


<section class="section-padding">
            <div class="container">
                <div class="col-md-12 col-12 text-center heading-bold mob-heading mb-5">Basic Eligibility Criteria</div>
                
                <div class="row mt-5">
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">1</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Good Credit <br>Score
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">2</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Above 21 years of <br>age
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">3</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Salaried <br>professional
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">4</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Resident of <br>India
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">5</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Valid Bank<br>Account
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">6</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            PAN Card and Voter<br>ID Card/Driving License
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">7</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Bank Statements for<br>the last three months
                        </p>
                    </div>
                    <div class="col-md-3 col-6 text-center pb-md-0 pb-5 pt-md-5">
                        <div class="eligibility-point">8</div>
                        <p class="mb-0 font16 mt-5 font-medium text-dark">
                            Salary Slip for last<br>three months
                        </p>
                    </div>
                </div>
            </div>
</section>

<section class="light-grey-bg section-padding">
            <div class="container text-left">
                <div>
                    <p class="heading-bold mob-heading mb-5">
                        Frequently Ask Questions
                    </p>
                </div>
                <p class="mb-0 font-medium">
                    Q. How much can I borrow and for how long?
                </p>
                <p>A. You can get personal loans starting from Rs. 25,000 up to Rs.25 lakhs for 1 to 5 years.</p>

                <p class="mb-0 font-medium">
                    Q. Can I repay my loan early?
                </p>
                <p>A. Yes, you can pre-pay your loan as and when you want.</p>


                <p class="mb-0 font-medium">
                    Q. How does Loans assess my credit worthiness and how long does this take?
                </p>
                <p>A. Each consumer wishing to borrow on the Loans portal will need to go through a rigorous verification and credit assessment process. The assessment is based on information collected from various data sources like the application form, credit bureaus, bank statements, pay slips, verification reports, social media, etc. The above process is automated and happens within seconds. Hence, you can get an approval shortly after you submit your application.</p>



                <p class="mb-0 font-medium">Q. Why was my application rejected?</p>

                <p>A. The reason your application was rejected was because your credit profile did not match the criteria stipulated in the Loans policy at the time. However, Loans might be able to approve your application at a later date, if by then your credit file has improved or there have been changes in the Loans credit policy.</p>

                <p class="mb-0 font-medium">Q.What is my repayment schedule?</p>

                <p>A. Repayment of the loan will happen monthly on an EMI (equated monthly installment) basis where the amount will be calculated based on amortizing balance. One or two of the installments might be different which will depend on the timing of the loan.</p>

                <p class="mb-0 font-medium">Q. What happens in the case of a missed payment or non-payment by a borrower?</p>
                <p>A. If the monthly payment for a borrower is delayed for any reason, a penalty fee and penal interest might be charged to the borrower. The borrower’s credit file will also get impacted which will restrict him / her to get credit in the future. Legal action may also be taken against the borrower.</p>

                <p class="mb-0 font-medium">Q. What information is shared with the lenders browsing through the profiles?</p>
                <p>A. Lenders will have the ability to view detailed profiles of the borrowers, information like financial information, employment information, etc. The personal information of the borrower remains protected as per our privacy policy.</p>


                <p class="mb-0 font-medium">Q. How do I alter my loan request?</p>
                <p>A. Loan requests can only be cancelled prior to loan disbursal. In case you want to make any changes to your request please reach out to support@Loans.com. The support team will help you in making the modifications.</p>

                <p class="mb-0 font-medium">Q. How can I make monthly payments?</p>
                <p>A. You can pay your EMIs using electronic transfer of funds, ECS.</p>

                <p class="mb-0 font-medium">Q. How will you disburse the loan amount?</p>
                <p>A. Soon after the loan is approved, the funds will be transferred right into your bank account.</p>
            </div>



</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/personal_loan_kolkata.blade.php ENDPATH**/ ?>