
<?php $__env->startSection('content'); ?>
  <!-- Main content -->
  
    <!-- Header -->
    <!-- Header -->
    <div class="header pb-6 d-flex align-items-center" style="min-height: 150px; background-size: cover; background-position: center top;">
      
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
         <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('termsconditionsmsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('termsconditionsmsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('termsconditionsmsg')); ?>

                <?php endif; ?>
            </div>
        </div>
      <div class="row">
        
        <div class="col-xl-12 order-xl-1">
          <div class="card">
          
            <div class="card-body">
              <form method="post" action="<?php echo e(route('submit_termsconditions')); ?>" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                <h6 class="heading-small text-muted mb-4">Terms & Conditions Details</h6>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Heading</label>
                        <input type="text" id="input-username" name="heading" class="form-control" placeholder="Heading">
                        <?php if($errors->has('heading')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('heading')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Sub-Heading</label>
                        <input type="text" id="input-username" name="sub_heading" class="form-control" placeholder="Sub-Heading">
                        <?php if($errors->has('sub_heading')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('sub_heading')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Description</label>
                        <textarea type="text" id="input-username" name="description" class="form-control ckeditor" placeholder="Description"></textarea>
                        <?php if($errors->has('description')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('description')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    
                  </div>
                 
                </div>

                <div class="col-sm-4">
                    <div class="form-group bmd-form-group">
                        <button type="submit" class="btn btn-success btn-block">Submit</button>
                    </div>
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
    </div>  

<?php $__env->stopSection(); ?>
  <!-- Argon Scripts -->
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/add_termsconditions.blade.php ENDPATH**/ ?>