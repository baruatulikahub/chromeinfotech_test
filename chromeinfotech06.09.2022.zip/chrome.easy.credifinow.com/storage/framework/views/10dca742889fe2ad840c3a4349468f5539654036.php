
<?php $__env->startSection('content'); ?>

<div class="st-blog-wrap st-section" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <article class="post">
          	<header class="entry-header">
          	    <div class="post-details-wrap-outer">
          			<div class="post-details-wrap">
          			    <h2 class="widget-title">Personal Loan <span><b style="color: #FFB72E; font-weight: 700;">EMI</b></span> Calculator </h2>
          			    <div class="credit_card_box marg20t banner-box-shadow pad20t">
          				<div class="col col-main">
                              <h2>Enter Loan Data</h2>
                              <label for="amount" class="label" style="font-weight: 700;">Input loan amount</label>
                              <div class="input-wrapper">
                                <span class="input-addon"><b>INR</b></span>
                                <input id="amount" class="input-field" type="text" value="100,000" style="background: #e9eaf1;">
                              </div>
                              <label for="apr" class="label" style="font-weight: 700;">Input Interest Rate</label>
                              <div class="input-wrapper">
                                <input id="apr" class="input-field" type="text" value="5" style="background: #e9eaf1;">
                                <span class="input-addon">%</span>
                              </div>
                              <label for="years" class="label" style="font-weight: 700;">Input Tenure</label>
                              <div class="input-wrapper">
                                <input id="years" class="input-field" type="text" value="20" style="background: #e9eaf1;;">
                                <span class="input-addon">years</span>
                              </div>
                              <p class="form-submit">
                  				<button type="submit" onclick="calculate();" class="st-btn st-style1 st-size1 st-color1"><span>Calculate</span> <i class="fa fa-arrow-right"></i></button>
                  			  </p>
                             
                         </div>
                        </div>
          			</div>
          		</div>
          		
          	</header>
          </article>
        </div>
        <aside class="col-lg-4">
          <div class="st-sidebar st-right-sidebar">
            <div class="widget widget_categories">
              <h2 class="widget-title">EMI Calculated</h2>
              <div class="credit_card_box marg20t banner-box-shadow pad20t">
           
              <div class="comment-respond">
          		<div class="col">
                      <h2>Payments</h2>
                      <div class="output-wrapper">
                        <p class="label" style="font-weight: 700;">Monthly payment</p>
                        <p class="output-value">INR<span id="payment"></span></p>
                      </div>
                      <div class="output-wrapper">
                        <p class="label" style="font-weight: 700;">Total payments</p>
                        <p class="output-value">INR<span id="total"></span></p>
                      </div>
                      <div class="output-wrapper">
                        <p class="label" style="font-weight: 700;">Total interest payments</p>
                        <p class="output-value">INR<span id="totalinterest"></span></p>
                      </div>
                </div>
          	  </div>
          	  </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
  
<div class="col-sm-12 pad10t marg10t">
    <div class="container">
        <h2>Personal Loan EMI Calculator</h2>
        <h4>Personal Loan EMI</h4>
        <p>EMI is known as Equated Monthly Installments. It is the fixed amount of money that borrowers pay every month, on a fixed date to the lender to repay the personal loan taken.</p>
        <h3>Components of Personal Loan EMI</h3>
        <ul>
            <li>Repayment towards the Principal amount</li>
            <li>Repayment towards the  Interest amount</li>
        </ul>
    </div>
</div>

<div class="pad20t sm-pad0 credit-report ">
    <div class="container">
        <p>Whenever you pay EMI, the interest amount is first paid and then the principal amount. Every month, interest is calculated on the outstanding principal amount.</p>
        <h4>Factors that affect the personal loan equated monthly installments( EMI)</h4>
        <ol>
            <li>
                <h4>Loan amount:</h4> <p>
                    Monthly installments and the loan amount are directly related to each other.  Higher is the loan amount, higher will be your EMIs.
                </p>
            </li>
            <li>
                <h4>Interest Rate: </h4><p>
                    The interest rate is a percentage of the amount charged by the lender based on your principal amount of loan. If the interest rate is higher, the EMI will also be.
                </p>
            </li>
        </ol>
        <h4>Factors which affects the interest rates on a personal loan:</h4>
        <ul>
            <li><strong> Credit score</strong> </li>
        </ul>
        <p>
            A credit score plays an important role in deciding the interest rate of a personal loan. In fact, a score above 750 or above can give you the power to negotiate on the given interest rate. The credit score is a numeric expression that helps in assessing your financial standing. There are numerous factors that build your credit score which are:
        </p>
        <ul>
            <li>Payment History (35%)</li>
            <li> Credit amount owed (30%)</li>
            <li>Length of credit history(15%)</li>
            <li>Types of credit(10%)</li>
            <li> New Credit (10%)</li>
        </ul>
        <ul><li><strong>Credit Payment Track Records</strong></li></ul>
        <p>
            Your credit history is not the same as your credit score. A credit score is the numeric expression of your financial standing wherein credit history is a part of it. Credit history is the past record of your credit performances and can give an idea of you as a customer. The credit history helps you to assess the credibility of the applicant.
        </p>
        <ul>
            <li>
                <strong> Relationship with the lender</strong>
            </li>
        </ul>
        <p>  A good relationship with the lender can give you the chance of getting the best interest rates on your personal loan. This is because the lender knows your integrity and credibility and would know the risks involved. Please note the relationship with the applicant should be informal. For example, the chances of getting the best interest rate with a lender where you have a salary account is higher than with a new lender.</p>
        <ul><li> <strong>Negotiation Power</strong></li></ul>
        <p>The power of negotiation comes if you have a good credit profile. Moreover, you should be able to convince the lender about your credibility.</p>
        <ul> <li><strong>Employer</strong></li></ul>
        <p>
            Your employer is another important factor that is considered when deciding your personal loan interest rate. The reputation of the employer and the number of years you’ve been associated with them contributes to determining the interest rate. For example, if you work with a highly reputed and established firm, the chances of you getting a low-interest rate are higher.
        </p>
        <ul> <li><strong>Income</strong></li></ul>
        <p>
            Individuals with higher income and job stability are likely to get a low-interest personal loan. This is because a consistent income gives the lender the much-needed trust that the loan will be repaid.
        </p>
        <ul><li><strong>Loan Tenure:</strong> </li></ul>
        <p>
            The loan tenure or the duration for which the loan is sanctioned is another factor that comes into play. There is an inverse relationship between the loan tenure and the interest rate. The longer the loan tenure, the lower the interest rate and vice-versa. Moreover, the longer your long period is, the costlier your loan will be. This also depends on the type of interest.
        </p>
        <h4> What is a Personal Loan EMI Calculator?</h4>
        <p>
            A Personal Loan EMI calculator is an online tool that helps you to get the exact EMI amount based on details such as principal amount, tenure and rate of interest.
        </p>
        <h4>Learn here the process to calculate Personal Loan EMI</h4>
        <p>
            There are mainly two ways to calculate Personal Loan EMI, one is manually and other with the help of Personal Loan EMI calculator
        </p>
        <h4> Manual Process- Using Formula</h4>
        <p>
            To calculate the EMI, one must compulsorily follow the EMI calculation formula. Given below is the formula to measure your EMI accurately:
            E = [P x R x (1+R) ^ N] / [(1+ R) ^ N – 1] wherein,
            E stands for Equated Monthly Installment
            P stands for Principal loan amount
            R stands for Rate of interest
            N stands for the number of months
            When making use of the Personal Loan EMI Calculator
        </p>
        <h4> It is a three-step process</h4>
        <h4><strong> Step 1</strong> </h4>
        <p>
            Use the slider for selecting the desired loan amount according to your financial need.
        </p>
        <h4><strong> Step 2</strong> </h4>
        <p>Fill the interest rate offered by lenders. Do not change the value as per your preference.</p>
        <h4><strong> Step 3</strong> </h4>
        <p>    After choosing the interest rate, make use of the slider to choose the tenure of your loan. Higher is the tenure, lower will be the EMI value.</p>
        <h4> Note :</h4><p> There is no rocket science in calculating personal loan EMI, all is required is to submit accurate information to get the right amount.</p>
        <h4> Overview of results</h4>
        <p>
            The "EMI calculator displays" the EMI to be paid, along with a detailed repayment table with a break-up of the total amount payable (Loan Amount + Interest Payable + Processing Fee) for the tenure.
        </p>
        <ul><li><h4> EMI Calculators shows the result in the form of Graphic Representation:</h4></li></ul> <p>   It will give you the percentage break up of how much will be the principal amount and interest to be paid in each EMI in the form of a pie chart.</p>
        <ul><li><h4>EMI Calculator shows result in the form of Repayment Table:</h4></li></ul><p>
            The repayment table illustrates details related to your loan repayment that how much amount you need to pay out each month.
        </p>
        <h4>
            Main elements of the repayment table are:
        </h4>
        <h4> Principal Paid:</h4><p> This is the portion of your monthly payment that is applied towards the loan principal which will keep increasing each month as the loan matures.</p>
        <h4>Interest Paid: </h4> <p>This is the portion of your monthly payment that is applied towards the interest that will keep reducing each successive month as the personal loan matures.</p>
        <h4>  Total Payment:</h4> <p>  It is the total of the principal and interest paid</p>
        <h4> Outstanding Loan Balance:</h4> <p> The ending balance of any given period corresponds to the principal amount that is owed to the lender at the end of that period.</p>
        <h4> Features and Benefits of Personal Loan EMI Calculator</h4>
        <h4><strong>Features</strong></h4>
        <ol>
            <li> A personal loan EMI calculator helps you calculate the amount you need to pay as EMIs.</li>
            <li>By calculating the EMIs, you can plan your budget and spending accordingly.</li>
            <li>
                You can know the total amount to be paid and the total interest payable. This will help you determine the loan tenure that suits you as per your budget.
            </li>
        </ol>
        <h4>Benefits</h4>
        <h4><strong>Easy to access and use:</strong></h4><p>
            It is the simplest way to evaluate your loan in terms of interest. Anyone can use it as there is no rocket science in this. All you need to provide details related to personal loans such as loan amount, interest rate and tenure. Result will be shown in seconds.
        </p>
        <h4><strong> Give accurate results:</strong></h4><p> There are chances of mistakes when you do the mathematical calculation manually to find out personal loan EMI which may lead to choosing the wrong loan offer. But with the help of Personal Loan EMI Calculator, you get a chance to do multiple variations with accurate results every single time.</p>
        <h4><strong>  Helps in choosing the best loan offers: </strong></h4><p> When you input various lender offers on personal loan EMI Calculator, you get an instant idea of what your EMI will be with different lenders. After comparing all the loan offers, you can easily decide the best loan offer.</p>
        <h4><strong>  Free of cost :</strong></h4><p> On our website, you can use the EMI calculator as many times, and it will not cost you anything. Personal loan EMI calculator is available 24X7 for the convenience of the borrower.</p>
        <h4><strong> Gives you more information</strong></h4>
        <p> Some calculators not just give you information about your personal loan EMIs, but also the processing fee associated with it, a graphic representation of the loan and an amortization table too. This gives a complete understanding of your personal loan.</p>

    </div>

</div>

<script>
    function calculate() {

  var amount = document.getElementById("amount");
  var apr = document.getElementById("apr");
  var years = document.getElementById("years");
  var zipcode = document.getElementById("zipcode");
  var payment = document.getElementById("payment");
  var total = document.getElementById("total");
  var totalinterest = document.getElementById("totalinterest");
  

  var principal = parseFloat(amount.value.replace(/,/g, ''));
  var rate = parseFloat(apr.value) / 100 / 12;
  var payments = parseFloat(years.value) * 12;
  

  var x = Math.pow(1 + rate, payments);
  var monthly = (principal * x * rate) / (x - 1);
  

  if (isFinite(monthly)) {
 
    payment.innerHTML = formatNumber(monthly, 2);
    total.innerHTML = formatNumber(monthly * payments, 2);
    totalinterest.innerHTML = formatNumber((monthly * payments) - principal, 2);
    

    chart(principal, rate, monthly, payments)
  }
  else {

    payment.innerHTML = "";
    total.innerHTML = "";
    totalinterest.innerHTML = "";
    chart();  // With no arguments, clears the chart
  }
}
</script>

<script>
    function chart(principal, rate, monthly, payments) {
  var graph = document.getElementById("graph");
  graph.width = graph.width; // Magic to clear and reset the canvas element
  
  // If we're called with no arguments, 
  // or if the browser does not support graphics
  // in a <canvas> element, then just return now.
  if (arguments.length === 0 || !graph.getContext) return;
  
  // Get the "context" object for the <canvas>
  // that defines the API
  // All drawing is done with this object
  var g = graph.getContext("2d");
  
  var width = graph.width, height = graph.height; // Get canvas size
  
  // These functions convert payment numbers
  // and dollar amounts to pixels
  function paymentToX(n) {
    return n * width/payments;
  }
  function amountToY(a) {
    return height - (a * height / (monthly * payments * 1.05));
  }
  
  // Payments are a straight line from (0,0)
  // to (payments, monthly * payments)
  g.moveTo(paymentToX(0), amountToY(0)); // Start at lower left
  g.lineTo(paymentToX(payments), // Draw to upper right
           amountToY(monthly * payments));
  g.lineTo(paymentToX(payments), amountToY(0)); // Down to lower right
  g.closePath(); 	// And back to start
  g.fillStyle = "#72AAD0";	// Light blue
  g.fill();	// Fill the triangle
  
  // Cumulative equity is non-linear and trickier to chart
  var equity = 0;
  g.beginPath();
  g.moveTo(paymentToX(0), amountToY(0));	// Start at lower left
  for (var p = 1; p <= payments; p++) {
    // For each payment, figure out how much is interest
    var thisMonthsInterest = (principal - equity) * rate;
    equity += (monthly - thisMonthsInterest);	// The rest goes to equity
    g.lineTo(paymentToX(p), amountToY(equity));	// Line to this point
  }
  g.lineTo(paymentToX(payments), amountToY(0));	// Line back to X axis
  g.closePath();	// And back to starting point
  g.fillStyle = "#40FD65";
  g.fill(); // Fill area under curve
  
  // Loop again, as above, but chart loan balance as a black line
  var bal = principal;
  g.beginPath();
  g.moveTo(paymentToX(0), amountToY(bal));
  for (var p = 1; p <= payments; p++) {
    var thisMonthsInterest = bal*rate;
    bal -= (monthly - thisMonthsInterest);	// The rest goes to equity
    g.lineTo(paymentToX(p), amountToY(bal));	// Draw line to this point
  }
  
  g.lineWidth = 2;
  g.strokeStyle = "#444"
  g.stroke();	
  

  g.textAlign = "center";		
  g.fillStyle = "#444";
  g.font = "0.6em 'Open Sans'";
  var y = amountToY(0);		
  for (var year=1; year*12 <= payments; year++) { 
    var x = paymentToX(year * 12);	
    g.fillRect(x - 0.5, y - 3, 1, 3);	
    if (year === 1) g.fillText("Year", x, y - 5);	
    if (year % 5 === 0 && year * 12 !== payments) 
      g.fillText(String(year), x, y - 5);
  }
  

  g.textAlign = "right";	
  g.textBaseline = "middle"	
  var ticks = [monthly * payments, principal];	
  var rightEdge = paymentToX(payments);		// X coordinate of Y axis
  for (var i=0; i < ticks.length; i++) {	// For each of the 2 points
    var y = amountToY(ticks[i]);		// Compute y position of tick
    g.fillRect(rightEdge - 3, y - 0.5, 3, 1);	// Draw the tick mark
    g.fillText(String(formatNumber(ticks[i]), 2), rightEdge - 5, y); 		// And label it
  }
}

function formatNumber (num, decimals) {
    return num.toFixed(decimals).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
    // http://blog.tompawlak.org/number-currency-formatting-javascript
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/emi_calculator.blade.php ENDPATH**/ ?>