
<?php $__env->startSection('content'); ?>


<div style="margin-top: 65px;">
    <form name="plshortform">
        <section class="light-grey-bg pt-5 pb-md-5 pl-page">
            <div class="container">
                <div class="animation-element row">
                    <div class="col-md-12">
                        <div class="bottom-fadein mb-4 text-center">
                     
                            <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                                     
                                <h1 class="col-12 p-0 mb-md-5 mb-4 mob-heading mt-4" style="color: #6262a0;">
                                    Personal Loan in <span><b style="color: #FFB72E; font-weight: 700;"><?php echo e($p->name); ?></b> Bank</span>
                                </h1>
                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <!--<h3 class="pl-0 pr-0 pb-0 mt-4">-->
                            <!--    Get the lowest Personal loan interest rates starting from 10.25% per annum.-->
                            <!--</h3>-->
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </form>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
            <div class="row">
                  <div class="col-lg-8 ml-auto mr-auto">
                      <?php if(Session::has('regmsg')): ?>                 
                          <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                               <strong><?php echo e(Session::get('regmsg')); ?></strong>
                          </div>
                          <?php echo e(Session::forget('message')); ?>

                          <?php echo e(Session::forget('regmsg')); ?>

                      <?php endif; ?>
                  </div>
            </div>
            <div class="comment-respond">
                  		<h2 class="comment-reply-title">Check Loan Eligibility</h2>
                  		<p>Let's Get Started Please Provide Your Basic Details</p>
                  		<form method="post" class="comment-form" action="<?php echo e(route('personal_loan_registration')); ?>">
                  		     <?php echo csrf_field(); ?>
                  			<p class="comment-form-comment">
                  			    <label for="dob">Full Name (As per PAN Card)</label>
                  				<input name="fname" type="text" placeholder="Full Name (As per PAN Card)*" required="">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label for="gender">Gender</label>
                  				<select class="form-control" name="gender">
                  				    <option>--- Select Gender Type ---</option>
                  				    <option name="gender" value="Male">Male</option>
                  				    <option name="gender" value="Female">Female</option>
                  				</select>
                  			</p>
                  			<p class="comment-form-email">
                  			    <label for="dob">Mobile Number</label>
                  				<input name="mobile" type="tel" maxlength="10" placeholder="Mobile Number*" required="">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label for="dob">Email Address</label>
                  				<input name="email" type="email" placeholder="Email Address*" required="">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label for="dob">Date of Birth as per your PAN</label>
                  				<input name="dob" type="date" placeholder="Date of Birth as per your PAN" required="">
                  			</p>
                  			<p class="comment-form-email">
                  			    <label for="dob">Enter your 10 digit PAN Number!</label>
                  				<input name="pannumber" type="text" placeholder="10 digit PAN number" required="">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label>Current Company Name</label>
                  				<input name="company" type="text" placeholder="Enter Company Name">
                  			</p>
                  			<p class="comment-form-author">
                  			    <label>Current Residence Pincode</label>
                  				<input name="pincode" type="number" placeholder="Enter your Residence Pincode">
                  			</p>
                  			<p class="comment-form-email">
                  			    <label>Monthly in-hand Salary</label>
                  				<input name="income" type="text" placeholder="Enter your Income">
                  			</p>
                  			<p class="comment-form-url">
                  			    <label>Employment Type</label>
                  				<select class="form-control" name="employment">
                  				    <option>--- Select Employment Type ---</option>
                  				    <option value="Salaried">Salaried</option>
                  				    <option value="Self Employed">Self Employed</option>
                  				    <option value="Self Employed (Dr./CA)">Self Employed (Dr./CA)</option>
                  				</select>
                  			</p>
                  			<p class="form-submit">
                  				<button type="submit" class="st-btn st-style1 st-size1 st-color1"><span>Apply Now</span> <i class="fa fa-arrow-right"></i></button>
                  			</p>
                  		</form>
            </div>
        </div>
      </div>
    </div>
</div>

<br><br>

<section class="lightest-blue-bg section-padding">
            <div class="container">
                <div>
                    <div class="animation-element row align-items-end in-view">                  
                    <div class="col-md-12">                  
                    <div class="bottom-fadein heading-bold text-center">Why Choose 
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    Bank Personal Loan?</div>                      
                    <h3 class="bottom-fadein mt-4 text-center mb-5">You can benefit from the attractive rate of interest and several other product features. Here are a few reasons for choosing 
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    Bank for a personal loan.</h3>                  
                    </div>                  
                    <div class="col-lg-7 col-md-12 mt-md-5">                      
                        <div class="col-lg-12 col-md-10 offset-lg-0 offset-md-1 col-12 pl-lg-0">                          
                            <ul class="ul-bankwise-list">                            
                                <li>Affordable and Flexible Interest Rates</li>                            
                                <li>Special interest rates for women borrowers</li>                            
                                <li>Fast loan approval</li>                            
                                <li>Easy documentation process and 100% transparency</li>                            
                                <li>Maximum loan up to Rs. 25 lakhs for salaried individuals</li>                            
                                <li>Flexible repayment options, ranging from 12 to 60 months</li>                            
                                <li>Zero hidden charges and low processing fee</li>                            
                                <li>Convenient repayment options</li>                            
                                <li>Fast disbursal with money in your account within 2 days </li>                          
                            </ul>                          
                            <div class="clearfix"></div>                      
                        </div>                  
                    </div>                  
                    <div class="col-md-5 col-12 room-image d-lg-block d-none mt-md-5 pb-5">                      
                       <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/hero-img.png')); ?>" alt="Our Partners" class="main-img img-fluid">                  
                    </div>                  
                    <div class="clearfix"></div
                    div>
                </div>
            </div>
            
            </div>
</section>

<section class="section-padding">
            <div class="container">
                 
 <div class="col-md-12 text-center heading-bold mob-heading mb-5">Documents Required for 
 <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <?php echo e($p->name); ?> 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
 Bank First Personal Loan
</div>
<p class="text-center mb-5"></p>
<div class="row mt-4">
   <div class="col-md-6 mt-4">
      <div class="row">
         <div class="col-sm-2 col-2">
            <div class="eligibility-point">1</div>
         </div>
         <div class="col-sm-9 col-9 pl-md-0 pr-0">
            <p class="font-medium mb-0">Complete online loan application

</p>
            <p>Fill it up online within two minutes

</p>
         </div>
      </div>
   </div>
   <div class="col-md-6 mt-4">
      <div class="row">
         <div class="col-sm-2 col-2">
            <div class="eligibility-point">2</div>
         </div>
         <div class="col-sm-9 col-9 pl-md-0 pr-0">
            <p class="font-medium mb-0">ID proof

</p>
            <p>Aadhar Card/Voter Id Card/Passport/Driving License

</p>
         </div>
      </div>
   </div>
   <div class="col-md-6 mt-4">
      <div class="row">
         <div class="col-sm-2 col-2">
            <div class="eligibility-point">3</div>
         </div>
         <div class="col-sm-9 col-9 pl-md-0 pr-0">
            <p class="font-medium mb-0">Salary proof

</p>
            <p>Salary slip of the last 3 months with Form 16

</p>
         </div>
      </div>
   </div>
   <div class="col-md-6 mt-4">
      <div class="row">
         <div class="col-sm-2 col-2">
            <div class="eligibility-point">4</div>
         </div>
         <div class="col-sm-9 col-9 pl-md-0 pr-0">
            <p class="font-medium mb-0">Bank statement</p>
            <p>Bank statement of last 3 months or bank passbook of 6 months

</p>
         </div>
      </div>
   </div>
   <div class="col-md-6 mt-4">
      <div class="row">
         <div class="col-sm-2 col-2">
            <div class="eligibility-point">5</div>
         </div>
         <div class="col-sm-9 col-9 pl-md-0 pr-0">
            <p class="font-medium mb-0">Address proof

</p>
            <p>Aadhar Card/Voter Id Card/Passport/Driving License

</p>
         </div>
      </div>
   </div>
</div>
 
            </div>
        </section>
        
<section class="lightest-blue-bg section-padding">
            <div class="container">
                <div class="col-md-12 text-center heading-bold mob-heading mb-5">Why Should You Apply for 
                <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                Bank First Personal Loans at IndiaLends?</div>              
                    <p class="text-center mb-5">
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                      <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  Bank has collaborated exclusively with IndiaLends, an online marketplace which offers low-interest personal loans best suited for your needs. If you are seeking a Personal Loan with 
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> Bank, 
                    you can simply fill up an online loan application form after checking your 
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    Bank Personal Loan Eligibility. Moreover, you can use an online Personal Loan EMI calculator available at our website to calculate your affordability.</p>                                         
                <div class="row mt-4">                  
                  <div class="col-md-6 mt-4">                  
                   <div class="row">                  
                    <div class="col-sm-2 col-2">
                        <div class="eligibility-point">1</div>
                    </div>                  
                    <div class="col-sm-9 col-9 pl-md-0 pr-0">                      
                        <p class="font-medium mb-0">Personalised Loan Offers</p>                      
                        <p>At IndiaLends, you can receive personalised loan offers and best deals at the best rate of interest. This is due to a tie-up with 
                        <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php echo e($p->name); ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> Bank, 
                        which helps you get the best deal on your personal loan as per your profile.</p>                      
                    </div>                      
                   </div>                  
                  </div>                  
                  <div class="col-md-6 mt-4">                  
                    <div class="row">                  
                        <div class="col-sm-2 col-2">
                            <div class="eligibility-point">2</div>
                        </div>                  
                        <div class="col-sm-9 col-9 pl-md-0 pr-0">                    
                        <p class="font-medium mb-0">Instant Approval</p>                    
                        <p>You will get an instant approval on your personal loan after you fill in an easy online application form.</p>                      
                        </div>                      
                    </div>                  
                  </div>                  
                <div class="col-md-6 mt-4">                  
                <div class="row">                  
                <div class="col-sm-2 col-2">
                    <div class="eligibility-point">3</div>
                </div>                  
                <div class="col-sm-9 col-9 pl-md-0 pr-0">                      
                   <p class="font-medium mb-0">Cash within 2 days</p>                      
                   <p>Soon after the loan is approved, the funds are transferred right into the borrower’s bank account within two working days. Thus, we need no room for delay.</p>                      
                   </div>                      
                   </div>                  
                   </div>                  
                   <div class="col-md-6 mt-4">                  
                   <div class="row">                  
                   <div class="col-sm-2 col-2"><div class="eligibility-point">4</div>
                   </div>                  
                   <div class="col-sm-9 col-9 pl-md-0 pr-0">                    
                   <p class="font-medium mb-0">Real Time Tracking Facility</p>                    
                   <p>After submission of your loan application at IndiaLends, you can track your application online and moreover, will receive updates of your submitted application form using both email and SMS.</p>                      
                   </div>                      
                   </div>                  
                   </div>                 
                   <div class="col-md-6 mt-4">                 
                   <div class="row">                 
                   <div class="col-sm-2 col-2">
                       <div class="eligibility-point">5</div>
                       </div>                  
                       <div class="col-sm-9 col-9 pl-md-0 pr-0">                    
                           <p class="font-medium mb-0">Dedicated Customer Support</p>                    
                           <p>IndiaLends has a dedicated customer support team and helpline which is always ready to help with any grievances or questions from loan applicants.</p>                      
                       </div>                     
                </div>                  
                       </div>              
                       </div>
            </div>

</section>


<section class="section-padding">
            <div class="container">
                
                <div class="col-md-12 col-10 offset-md-0 offset-1 text-center heading-bold mob-heading mb-5">How to Apply for 
                <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                Personal Loans at IndiaLends?</div>
                    <p class="text-center">At IndiaLends, applying for a 
                    <?php $__currentLoopData = $allbank_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php echo e($p->name); ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    Personal Loan is a simple process.</p>
                    <br>
                    <div class="works-line"></div>
                    <div class="row mt-4">
                       <div class="col-md-4 col-12 text-center pb-md-0">
                          <div class="works-point">1</div>
                          <h2 class="mt-5 mb-4">Registration</h2>
                          <p class="mb-0"> Fill up an online loan application form </p>
                       </div>
                       <div class="d-md-none d-lg-none col-12 text-center py-5"><span class="mob-works-line">&nbsp;</span></div>
                       <div class="col-md-4 col-12 text-center pb-md-0">
                          <div class="works-point">2</div>
                          <h2 class="mt-5 mb-4">Quick Verification</h2>
                          <p class="mb-0"> We will review your application and give you a decision within minutes</p>
                       </div>
                       <div class="d-md-none d-lg-none col-12 text-center py-5"><span class="mob-works-line">&nbsp;</span></div>
                       <div class="col-md-4 col-12 text-center pb-md-0">
                          <div class="works-point">3</div>
                          <h2 class="mt-5 mb-4">Loan Disbursal</h2>
                          <p class="mb-0"> You will be receiving your Cash within few days </p>
                       </div>
                    </div>
            </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/personal_loan_.blade.php ENDPATH**/ ?>