<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>CredifiNow - Please Login Here!</title>
  <!-- Favicon -->
  <link rel="icon" href="<?php echo e(URL::asset('public/front/assets/img/logo/favicon.png')); ?>" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/admin/assets/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/admin/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" type="text/css">
  <!-- Argon CSS -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/admin/assets/css/argon.css?v=1.2.0')); ?>" type="text/css">
</head>

<body class="bg-default">
  <!-- Main content -->
  <br><br>
  <div class="main-content" style="margin-top: 0px;">
    <!-- Header -->
    <div class="header">
      <div class="container">
        <div class="header-body text-center mb-7">
          <div class="row justify-content-center">
            <div class="col-md-12">
              <img src="<?php echo e(URL::asset('public/front/assets/img/logo/Credifinow__logo.png')); ?>" class="img-fluid">
              
            </div>
          </div>
        </div>
      </div>
      
    </div>
    <br><br>

    <div class="container mt--8 pb-5">
      <div class="row justify-content-center">
        <div class="col-lg-8 col-md-8">
          <div class="card bg-secondary border-0 mb-0">
           
            <div class="card-body px-lg-5 py-lg-5">
              <div class="text-center text-muted mb-4">
                <p class="text-lead text-white" style="color: #161515!important;">Blogger Panel <br>sign in with credentials</p>
              </div>

              <div class="row">
                <div class="col-lg-8 ml-auto mr-auto">
                    <?php if(Session::has('loginerrmsg')): ?>                 
                        <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                             <strong><?php echo e(Session::get('loginerrmsg')); ?></strong>
                        </div>
                        <?php echo e(Session::forget('message')); ?>

                        <?php echo e(Session::forget('loginerrmsg')); ?>

                    <?php endif; ?>
                </div>
              </div>

            <form method="POST" action="<?php echo e(route('login_verification')); ?>" role="form">
                  <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                    </div>
                    <input class="form-control" name="email" placeholder="Email" type="email">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group input-group-merge input-group-alternative">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                    </div>
                    <input class="form-control" name="password" id="myInput" placeholder="Password" type="password">
                  </div>
                </div>
                <div class="custom-control custom-control-alternative custom-checkbox">
                  <input class="custom-control-input" id="customCheckLogin" type="checkbox" onclick="myFunction()">
                  <label class="custom-control-label" for="customCheckLogin">
                    <span class="text-muted">Show Password</span>
                  </label>
                </div>
                <div class="text-center">
                  <button type="submit" class="btn btn-dark my-4">Sign in</button>
                </div>
                <center>
                <a href="<?php echo e(route('adminindex')); ?>" target="_blank" class="open-popup btn btn-main btn-sm">Back To Admin Panel</a>
                </center>
              </form>
            </div>
          </div>
      
        </div>
      </div>
    </div>

  </div>
  <!-- Footer -->

  <!-- Core -->
  <script src="<?php echo e(URL::asset('public/admin/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/admin/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/admin/assets/vendor/js-cookie/js.cookie.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/admin/assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/admin/assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
  <!-- Argon JS -->
  <script src="<?php echo e(URL::asset('public/admin/assets/js/argon.js?v=1.2.0')); ?>"></script>
  <script type="text/javascript">
            function myFunction() {
              var x = document.getElementById("myInput");
              if (x.type === "password") {
                x.type = "text";
              } else {
                x.type = "password";
              }
            }
        </script>
</body>

</html><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/bloggerpanel.blade.php ENDPATH**/ ?>