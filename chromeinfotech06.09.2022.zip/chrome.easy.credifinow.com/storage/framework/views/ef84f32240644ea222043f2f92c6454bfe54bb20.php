
<?php $__env->startSection('content'); ?>


<?php 
    foreach ($size_details as $s) {
?>
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 600px;">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
                <form method="post" action="<?php echo e(route('update_size_details')); ?>" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled" id="user_purpose">
                                                          <label class="form-control-label" for="input-username">Size</label>
                                                          <select name="sort"  class="form-control" required>
                          
                                                              <?php 
                                                                foreach ($size_details as $s) {
                                                             
                                                              ?>
                                                                <option value="<?php echo $s->id; ?>"><?php echo $s->sort; ?></option>
                                                              <?php } ?>
                                                          </select>
                                                            <?php if($errors->has('sort')): ?>
                                                              <strong class="text-danger"><?php echo e($errors->first('sort')); ?></strong>                                   
                                                            <?php endif; ?>
           
                                                        </div>
                                                      </div>

                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled">
                                                          <label class="form-control-label" for="input-username">Size Code </label>
                                                          <input type="hidden" class="form-control" name="update" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                                          <input type="text" name="code" id="input-username" class="form-control" Value="<?php echo $s->code?>" placeholder="Size Code">
                                                          <?php if($errors->has('code')): ?>
                                                            <strong class="text-danger"><?php echo e($errors->first('code')); ?></strong>                                   
                                                          <?php endif; ?>
                                                        </div>
                                                      </div>
                
                                                      <div class="col-sm-12">
                                                        <div class="form-group bmd-form-group">
                                                            <button type="submit" class="btn btn-success btn-block">Update</button>
                                                        </div>
                                                      </div>
                
                                                    </div>
                                                </form>
        </aside> 	
      </div>
      
    </div>
    
  </div>
  
<?php } ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/chrome.easy.credifinow.com/resources/views/front/edit_size_details.blade.php ENDPATH**/ ?>