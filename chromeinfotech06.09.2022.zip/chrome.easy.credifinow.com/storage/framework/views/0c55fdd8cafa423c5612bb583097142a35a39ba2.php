<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
  <!-- Meta Tags -->
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="author" content="laralink" />
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <!-- Page Title -->
  <title>Instant & easy Personal Loan providers Online - Limty</title>
  <!-- Favicon Icon -->
  <link rel="icon" href="<?php echo e(URL::asset('public/front/assets/img/logo/favicon.png')); ?>" />
  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/owlCarousel.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/fontawesome.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/flaticon.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/animate.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('public/front/assets/css/style.css')); ?>" />
</head>

<body>
  <header class="st-header st-style1 st-sticky-menu">
    <div class="st-main-header">
      <div class="container">
        <div class="st-main-header-in">
          <div class="st-site-branding">
            <a href="<?php echo e(route('index')); ?>" class="st-logo-link" target="_blank"><img src="<?php echo e(URL::asset('public/front/assets/img/logo/Credifinow__logo.png')); ?>" alt="demo"></a>
          </div>
     
          <div class="st-nav-wrap st-fade-down">
            <div class="st-nav-toggle st-style1">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </div>
            <nav class="st-nav st-desktop-nav">
              <ul class="st-nav-list onepage-nav">
           
                <li><a href="<?php echo e(route('personal_loan')); ?>" target="_blank" class="smooth-scroll">Personal Loan</a></li>
                <li><a href="<?php echo e(route('business_loan')); ?>" target="_blank" class="smooth-scroll">Business Loan</a></li>
                <li><a href="<?php echo e(route('gold_loan')); ?>" target="_blank" class="smooth-scroll">Gold Loan</a></li>
                <li class="st-has-children"><a href="#home" class="smooth-scroll">Credit Cards</a>
                  <ul>
                    <!--<li><a href="<?php echo e(route('apply_credit_card')); ?>">Apply Credit Cards</a></li>-->
                    <?php
                        foreach($personal_credit_card_bank_details as $a) { 
                        $urll = route('credit_card_',['name'=>''.$a->name.''],'_bank');
                    ?>
                                     
                        <li><a href="<?php echo $urll; ?>" title="<?php echo $a->name; ?> Bank Credit Card"><?php echo $a->name; ?> Bank Credit Card</a> </li>
                                    
                    <?php }  ?>
                    <!--<li><a href="#">Axis Bank Credit Card</a>-->
                    <!--<li><a href="#">Indusind Bank Credit Card</a></li>-->
                    <!--<li><a href="#">Citi Bank Credit Card</a></li>-->
                    <!--<li><a href="#">SBI Credit Card</a></li>-->
                    <!--<li><a href="#">YES BANK Credit Card</a></li>-->
                    <!--<li><a href="#">HDFC Bank Credit Card</a></li>-->
                    <!--<li><a href="#">ICICI Bank Credit Card</a></li>-->
                    
                  </ul>
                </li>
                <li><a href="<?php echo e(route('credit_report')); ?>" class="smooth-scroll">Credit Report</a></li>
                <li><a href="<?php echo e(route('emi_calculator')); ?>" class="smooth-scroll btn btn-outline-primary">EMI Calculator</a></li>
                
              </ul>
            </nav><!-- .st-nav -->
          </div><!-- .st-nav-wrap -->
        </div>
      </div>
    </div>
  </header>
  
  <?php echo $__env->yieldContent('content'); ?>
  
  <!-- Start Footer Seciton -->

  <footer class="st-site-footer st-style1 st-sticky-footer st-footer">
    <div class="st-main-footer text-center">
      <div class="container">
        <div class="st-footer-logo">
          <img src="<?php echo e(URL::asset('public/front/assets/img/logo/Credifinow__logo.png')); ?>" alt="demo">
        </div>
        <div class="st-footer-text">We understand that it is better to morph virally than to embrace intuitively.<br>
          We will matrix the power of schemas to redefine.</div>
        <div class="st-footer-social">
          <ul class="st-footer-social-btn st-flex st-mp0">
            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="st-copyright text-center">
        <div class="st-copyright-text">© Copyright 2022. All Rights Reserved</div>
    </div>
    <div class="container">
        <div class="border-bottom align-items-center py-4 font14">
                            <div class="pb-4">
                                <div class="row m-0 citywise-links clearfix">
                                    <span class="font-medium">Personal Loans City Wise:&nbsp;</span>
                                    <?php
                                        foreach($personal_loan_city_details as $a) { 
                                     
                                        $urll = route('personal_loan_in',['name'=>''.$a->name.'']);
                                    ?>
                                     
                                        <a href="<?php echo $urll; ?>" title="Personal Loan in <?php echo $a->name; ?>">Personal Loan in <?php echo $a->name; ?></a> &nbsp;|&nbsp;
                                    
                                    <?php }  ?>
                                    <!--<a href="/personal-loan-Hyderabad" title="Personal Loan in Hyderabad">Personal Loan in Hyderabad</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Chennai" title="Personal Loan in Chennai">Personal Loan in Chennai</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Mumbai" title="Personal Loan in Mumbai">Personal Loan in Mumbai</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Delhi" title="Personal Loan in Delhi">Personal Loan in Delhi</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Pune" title="Personal Loan in Pune">Personal Loan in Pune</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Bangalore" title="Personal Loan in Bangalore">Personal Loan in Bangalore</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Jaipur" title="Personal Loan in Jaipur">Personal Loan in Jaipur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Ahmedabad" title="Personal Loan in Ahmedabad">Personal Loan in Ahmedabad</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Hubli" title="Personal Loan in Hubli">Personal Loan in Hubli</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Coimbatore" title="Personal Loan in Coimbatore">Personal Loan in Coimbatore</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Surat" title="Personal Loan in Surat">Personal Loan in Surat</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Nagpur" title="Personal Loan in Nagpur">Personal Loan in Nagpur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Indore" title="Personal Loan in Indore">Personal Loan in Indore</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Vijayawada" title="Personal Loan in Vijayawada">Personal Loan in Vijayawada</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Baroda" title="Personal Loan in Baroda">Personal Loan in Baroda</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Kochi" title="Personal Loan in Kochi">Personal Loan in Kochi</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Gwalior" title="Personal Loan in Gwalior">Personal Loan in Gwalior</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Varanasi" title="Personal Loan in Varanasi">Personal Loan in Varanasi</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Patna" title="Personal Loan in Patna">Personal Loan in Patna</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-dehradun" title="Personal Loan in Dehradun">Personal Loan in Dehradun</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Chandigarh" title="Personal Loan in Chandigarh">Personal Loan in Chandigarh</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Mangalore" title="Personal Loan in Mangalore">Personal Loan in Mangalore</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Lucknow" title="Personal Loan in Lucknow">Personal Loan in Lucknow</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Mysore" title="Personal Loan in Mysore">Personal Loan in Mysore</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Trivandrum" title="Personal Loan in Trivandrum">Personal Loan in Trivandrum</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Jamshedpur" title="Personal Loan in Jamshedpur">Personal Loan in Jamshedpur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Kanpur" title="Personal Loan in Kanpur">Personal Loan in Kanpur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Kota" title="Personal Loan in Kota">Personal Loan in Kota</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Visakhapatnam" title="Personal Loan in Visakhapatnam">Personal Loan in Visakhapatnam</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Raipur" title="Personal Loan in Raipur">Personal Loan in Raipur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Bhopal" title="Personal Loan in Bhopal">Personal Loan in Bhopal</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Jodhpur" title="Personal Loan in Jodhpur">Personal Loan in Jodhpur</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-Cuttack" title="Personal Loan in Cuttack">Personal Loan in Cuttack</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-bhubaneswar" title="Personal Loan in Bhubaneswar">Personal Loan in Bhubaneswar</a>-->
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="pb-4">
                                <div class="row m-0 citywise-links">
                                    <span class="font-medium">Personal Loans Bank Wise:&nbsp;</span>
                                    <?php
                                        foreach($personal_loan_bank_details as $a) { 
                                     
                                        $urll = route('personal_loan_',['name'=>''.$a->name.'']);
                                    ?>
                                     
                                        <a href="<?php echo $urll; ?>" title="<?php echo $a->name; ?> Personal Loan"><?php echo $a->name; ?> Personal Loan </a> &nbsp;|&nbsp;
                                    
                                    <?php }  ?>
                                    <!--<a href="/hdfc-personal-loan" title="HDFC Personal Loan">HDFC Personal Loan</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/idfc-first-personal-loan" title="IDFC First Personal Loan">IDFC First Personal Loan</a>&nbsp;|&nbsp;-->
                                    <!--<a href="/bajaj-personal-loan" title="Bajaj Finserv Personal Loan">Bajaj Finserv Personal Loan</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/icici-personal-loan" title="ICICI Personal Loan">ICICI Personal Loan</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/kotak-personal-loan" title="Kotak Personal Loan">Kotak Personal Loan</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/yes-bank-personal-loan" title="Yes Bank Personal Loan">Yes Bank Personal Loan</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/personal-loan-balance-transfer" title="Personal Loan Balance Transfer">Personal Loan Balance Transfer</a> &nbsp;|&nbsp;-->
                                    <!--<a href="/small-amount-personal-loan" title="Small Amount Personal Loan">Small Amount Personal Loan</a>-->
                                </div>
                            </div>
                            <div class="clearfix"></div>
    
                            <div class="row m-0 citywise-links pb-4">
                                <span class="font-medium">Credit Score:&nbsp;</span>
                                <a href="#" title="Cibil Score for Car Loan">Cibil Score for Car Loan</a> &nbsp;|&nbsp;
                                <a href="#" title="Cibil Score Customer Care">Cibil Score Customer Care</a> &nbsp;|&nbsp;
                                <a href="#" title="Cibil Score for Credit Card">Cibil Score for Credit Card</a> &nbsp;|&nbsp;
                                <a href="#" title="Cibil Score for Personal Loan">Cibil Score for Personal Loan</a> &nbsp;|&nbsp;
                                <a href="#" title="Cibil Credit Report">Cibil Credit Report</a> &nbsp;|&nbsp;
                                <a href="#" title="Practices that leads to Bad Credit Score">Practices that leads to Bad Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Loan settlement and your Credit Score">Loan settlement and your Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Equifax Credit Report">Equifax Credit Report</a> &nbsp;|&nbsp;
                                <a href="#" title="Credit Bureaus in India">Credit Bureaus in India</a> &nbsp;|&nbsp;
                                <a href="#" title="Improve your Credit Score">Improve your Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Achieve Good Credit Score">Achieve Good Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Experian Credit Report">Experian Credit Report</a> &nbsp;|&nbsp;
                                <a href="#" title="Myths about Credit Score">Myths about Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Highmark Credit Score">Highmark Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Repair Faulty Credit Report">Repair Faulty Credit Report</a>&nbsp;|&nbsp;
                                <a href="#" title="Resolve Cibil Dispute">Resolve Cibil Dispute</a>&nbsp;|&nbsp;
                                <a href="#" title="Read Cibil Report">Read Cibil Report</a>&nbsp;|&nbsp;
                                <a href="#" title="Cibil Score Benefits">Cibil Score Benefits</a>&nbsp;|&nbsp;
                                <a href="#" title="Correlation between credit rating and debts">Correlation between credit rating and debts</a> &nbsp;|&nbsp;
                                <a href="#" title="Minimum payment affect your Credit Score">Minimum payment affect your Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="How is your Credit Score calculated">How is your Credit Score calculated</a> &nbsp;|&nbsp;
                                <a href="#" title="How to read Credit Report">How to read Credit Report</a> &nbsp;|&nbsp;
                                <a href="#" title="How your Credit Score is used">How your Credit Score is used</a> &nbsp;|&nbsp;
                                <a href="#" title="Impact on late payment on Credit Score">Impact on late payment on Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Importance of Credit Score">Importance of Credit Score</a> &nbsp;|&nbsp;
                                <a href="#" title="Reason to check Credit Report regularly">Reason to check Credit Report regularly</a>&nbsp;|&nbsp;
                                <a href="#" title="Steps to check Credit Report">Steps to check Credit Report</a>&nbsp;|&nbsp;
                                <a href="#" title="Steps to rectify your Credit Report">Steps to rectify your Credit Report</a>&nbsp;|&nbsp;
                                <a href="#" title="Things you won't find in credit report">Things you won't find in credit report</a>&nbsp;|&nbsp;
                                <a href="#" title="Can a Credit Card Improve Your Credit Score?">Can a Credit Card Improve Your Credit Score?</a>&nbsp;|&nbsp;
                                <a href="#" title="Credit Monitoring">Credit Monitoring</a>&nbsp;|&nbsp;
                                <a href="#" title="Credit Score Matters at Retirement">Credit Score Matters at Retirement</a>&nbsp;|&nbsp;
                                <a href="#" title="Major Factors That Affect Your Credit Score">Major Factors That Affect Your Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="Credit Report Checklist">Credit Report Checklist</a>&nbsp;|&nbsp;
                                <a href="#" title="Reasons for Loan Rejection Other Than Credit Score">Reasons for Loan Rejection Other Than Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="Loan Settlement Can Ruin Your Credit Score">Loan Settlement Can Ruin Your Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="Does a name change affect your Credit Score?">Does a name change affect your Credit Score?</a>&nbsp;|&nbsp;
                                <a href="#" title="Effects of PAN Card on Credit Score">Effects of PAN Card on Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="The Link Between MCLR and Credit Score">The Link Between MCLR and Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="Applying for a Home Loan? Improve your Credit Score">Applying for a Home Loan? Improve your Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="How to Remove Your Name from CIBIL’s Defaulter List">How to Remove Your Name from CIBIL’s Defaulter List</a>&nbsp;|&nbsp;
                                <a href="#" title="How Can Customers Check their Credit History">How Can Customers Check their Credit History</a>&nbsp;|&nbsp;
                                <a href="#" title="Payment History - How it Affects Your Credit Score">Payment History - How it Affects Your Credit Score</a>&nbsp;|&nbsp;
                                <a href="#" title="Who issues Credit Ratings or Credit Scores">Who issues Credit Ratings or Credit Scores</a>&nbsp;|&nbsp;
                                <a href="#" title="Credit Report for Business Loan">Credit Report for Business Loan</a>&nbsp;|&nbsp;
                                <a href="#" title="Can your employment get affected by your credit score">Can your employment get affected by your credit score</a>&nbsp;|&nbsp;
                                <a href="#" title="How Long It Take To Improve Credit Score">How Long It Take To Improve Credit Score</a>
                            </div>
        </div>
    </div>
  </footer>
  
  <!-- End Footer Seciton -->
  
  <script>
      let question = document.querySelectorAll(".question");

        question.forEach(question => {
          question.addEventListener("click", event => {
            const active = document.querySelector(".question.active");
            if(active && active !== question ) {
              active.classList.toggle("active");
              active.nextElementSibling.style.maxHeight = 0;
            }
            question.classList.toggle("active");
            const answer = question.nextElementSibling;
            if(question.classList.contains("active")){
              answer.style.maxHeight = answer.scrollHeight + "px";
            } else {
              answer.style.maxHeight = 0;
            }
          })
        })

  </script>
  
  <script>
       $(document).ready(function(){
            $('#exampleModal').modal('show');
        }); 
  </script>
  

  <!-- Scripts -->
  <script src="<?php echo e(URL::asset('public/front/assets/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/mailchimp.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/owlCarousel.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/tamjid-counter.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/wow.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('public/front/assets/js/main.js')); ?>"></script>
  
</body>
</html><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/layoutother.blade.php ENDPATH**/ ?>