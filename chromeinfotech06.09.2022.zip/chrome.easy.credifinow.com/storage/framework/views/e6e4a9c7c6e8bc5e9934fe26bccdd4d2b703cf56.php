
<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <!-- Header -->
    <div class="header  pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0"></h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Banner Tables</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Banner</li>
                </ol>
              </nav>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('bannermsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('bannermsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('bannermsg')); ?>

                <?php endif; ?>
            </div>
        </div>
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">Client List </h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <!-- <th scope="col" class="sort" data-sort="name">Banner Priority</th> -->
                    <th scope="col" class="sort" data-sort="name">Client Name</th>
                    <th scope="col" class="sort" data-sort="budget">Client Image</th>
                   
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody class="list">
                  <?php 
                    foreach ($client_details as $b) {
                  ?>
                    <tr>

                      <!-- <td scope="row">
                        <div class="media align-items-center">
                         
                          <div class="media-body">
                            <span class="name mb-0 text-sm"><?php echo $b->id; ?></span>
                          </div>
                        </div>
                      </td> -->

                      <td scope="row">
                        <div class="media align-items-center">
                         
                          <div class="media-body">
                            <span class="name mb-0 text-sm"><?php echo $b->title; ?></span>
                          </div>
                        </div>
                      </td>

                       <td scope="row">
                        <div class="media align-items-center">
                          <a href="#" class="avatar rounded-circle mr-3">
                            <img alt="Image placeholder" src="<?php echo URL::asset('public/upload/client_image/'.$b->client_image.'') ?>">
                          </a>
                          
                        </div>
                      </td>
                      
                      
                      
                      <td class="">
                        <div class="dropdown">
                          <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v"></i>
                          </a>

                          <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="javascript:void();" data-toggle="modal" data-target="#myeditModal<?php echo $b->id; ?>" >Edit</a>
                            <a class="dropdown-item" onclick="alert('Are You Sure To Delete This?')" href="<?php echo route('delete_client_details',['id'=>''.$b->id.'']) ?>" >Delete</a>
                          </div>

                        </div>
                      </td>
                    </tr>

                    <div class="modal" id="myeditModal<?php echo $b->id; ?>">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Update Web Banner Deatils</h4>
                                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">&nbsp;&times;&nbsp;</button>
                            </div>
                            <!-- Modal body -->
                             <div class="modal-body">
                                <form method="post" action="<?php echo e(route('update_client_details')); ?>" enctype="multipart/form-data">
                                      <?php echo csrf_field(); ?>
                                      <div class="row">

                                        <!-- <div class="col-md-6">  
                                          <div class="form-group bmd-form-group is-filled">
                                            <label>Banner Priority</label>
                                            <input type="hidden" class="form-control" name="update" value="<?php echo $b->id; ?>" autocomplete="off" required="" >
                                            <input type="text" name="id" class="form-control" required="" value="<?php echo $b->id; ?>">
                                            <?php if($errors->has('id')): ?>
                                            <strong class="text-danger"><?php echo e($errors->first('id')); ?></strong>                                  
                                            <?php endif; ?>
                                          </div>
                                        </div> -->

                                        
                                        <div class="col-md-6">  
                                          <div class="form-group bmd-form-group is-filled">
                                            <label>Client Name</label>
                                            <input type="hidden" class="form-control" name="update" value="<?php echo $b->id; ?>" autocomplete="off" required="" >
                                            <input type="text" name="title" class="form-control" required="" value="<?php echo $b->title; ?>">
                                            <?php if($errors->has('title')): ?>
                                            <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>                                  
                                            <?php endif; ?>
                                          </div>
                                        </div>

                                        <div class="col-md-12">
                                        <div class="form-group bmd-form-group is-filled">
                                            <label class="bmd-label-floating">Choose Client Image</label>
                                            <input type="hidden" class="form-control" name="update" value="<?php echo $b->id; ?>" autocomplete="off" required="" >
                                            <input type="file" class="form-control" name="client_image" accept="image/*"  autocomplete="off" >
                                            <input type="hidden" class="form-control" name="client_image_old" value="<?php echo $b->client_image; ?>"  autocomplete="off" >
                                            <img class="img-fluid img-thumbnail" src="<?php echo URL::asset('public/upload/client_image/'.$b->client_image.'') ?>" style="height:30px;width:40px;">
                                            <?php if($errors->has('client_image')): ?>
                                            <strong class="text-danger"><?php echo e($errors->first('client_image')); ?></strong>                                  
                                            <?php endif; ?>
                                        </div>
                                      </div>
                                       

                                       
                                        
                                        <div class="col-sm-4">
                                          <div class="form-group bmd-form-group">
                                              <button type="submit" class="btn btn-success btn-block">Update</button>
                                          </div>
                                        </div>

                                      </div>
                                  </form>
                             </div>                                               
                        </div>
                      </div>
                    </div>

                  <?php } ?>
                  
                </tbody>
              </table>
            </div>
            <!-- Card footer -->
            <div class="card-footer py-4">
              <nav aria-label="...">
                <ul class="pagination justify-content-end mb-0">
                  <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">
                      <i class="fas fa-angle-left"></i>
                      <span class="sr-only">Previous</span>
                    </a>
                  </li>
                  <li class="page-item active">
                    <a class="page-link" href="#">1</a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      <i class="fas fa-angle-right"></i>
                      <span class="sr-only">Next</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/client_list.blade.php ENDPATH**/ ?>