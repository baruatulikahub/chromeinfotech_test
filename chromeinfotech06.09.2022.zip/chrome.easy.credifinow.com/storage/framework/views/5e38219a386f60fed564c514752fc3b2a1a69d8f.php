
<?php $__env->startSection('content'); ?>

  <!--<div id="css-only-modals">-->
  <!--  	<input id="modal1" class="css-only-modal-check" type="checkbox" checked/>-->
  <!--  	<div class="css-only-modal">-->
  <!--  		<label for="modal1" class="css-only-modal-close"><i class="fa fa-times fa-2x"></i></label>-->
  <!--  		<h2>Apply Now</h2>-->
  <!--  		<hr />-->
    
  <!--           <div class="comment-respond">-->
  <!--        		<form method="post" class="comment-form" action="<?php echo e(route('apply_loan_registration')); ?>">-->
  <!--        		    <?php echo csrf_field(); ?>-->
  <!--        		        <p class="comment-form-author text">-->
  <!--        				    <input name="fname" type="text" placeholder="First &amp; Last Name (as per PAN card)*" required="">-->
  <!--        			    </p>-->
  <!--            			<p class="comment-form-email text-email">-->
  <!--            				<input name="email" type="email" placeholder="E-mail Address*" required="">-->
  <!--            			</p>-->
  <!--            			<p class="comment-form-url text-phone">-->
  <!--            				<input id="url" name="mobile" type="tel" maxlength="10" placeholder="10 digit mobile number*" required="">-->
  <!--            			</p>-->
  <!--            			<p class="comment-form-author text">-->
  <!--        				    <input name="address" type="text" placeholder="Current residence address, pincode" required="">-->
  <!--        			    </p>-->
  <!--        			    <p class="comment-form-author text">-->
  <!--            			    <select class="form-control" name="loantype">-->
  <!--                			   <option>--- Select Loan Type ---</option>-->
  <!--                			   <option name="loantype" value="Personal Loan">Personal Loan</option>-->
  <!--                			   <option name="loantype" value="Business Loan">Business Loan</option>-->
  <!--                			   <option name="loantype" value="Gold Loan">Gold Loan</option>-->
  <!--                			</select>-->
  <!--        			    </p>-->
  <!--        			    <p class="comment-form-email text-amt">-->
  <!--        			        <label style="color: #1caffd;">Required Loan Amount</label>-->
  <!--            				<input name="amount" type="text" placeholder="Required Loan Amount" value="₹ 0" required="">-->
  <!--            			</p>-->
              			
  <!--        			    <p class="form-submit">-->
  <!--            				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="padding: 0.6em 2.2em;"><span>Send</span></button>-->
  <!--            			</p>-->
  <!--        		</form>-->
  <!--        	 </div>-->
    		<!--<label for="modal1" class="css-only-modal-btn btn btn-primary btn-lg">Okay</label>-->
  <!--  	</div>-->
  <!--      <div id="screen-shade"></div>-->
  <!--</div>-->
  
  <div class="st-content" >
    <!-- Start Hero Slider -->
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx">
        <div class="col-lg-8"> 
        <div class="container">
          <div class="st-hero-text st-style1">
            <h2 class="st-hero-title"> We are offering loans and debt consolidation <br/>services at an affordable interest rate</h2>
            <div class="st-hero-subtitle">
              We work directly with banks, credit unions and <br />
              other lending institutions to offer competitive solutions.
            </div>
            <div class="st-btn-group st-style1">
              <a href="#" class="st-btn st-style1 st-color1">Learn More</a>
              <!--<a href="https://www.youtube.com/embed/jRcfE2xxSAw?autoplay=1" class="st-btn st-style2 st-video-open"><i class="flaticon-multimedia"></i> Watch Video</a>-->
            </div>
          </div>
        </div>
        </div>
        
      
        <aside class="col-lg-4 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>Check Business Loan Eligibility in 2 mins</b></div>
                <br>
          		<form method="post" class="comment-form" action="<?php echo e(route('apply_loan_registration')); ?>">
          		    <?php echo csrf_field(); ?>
          		        <p class="comment-form-author text">
          				    <input name="fname" type="text" pattern="[a-zA-Z'-'\s]*" placeholder="First &amp; Last Name (as per PAN card)*" required="">
          			    </p>
              			<p class="comment-form-email" style="width: 49.3333%">
              				<input name="email" type="email" placeholder="E-mail Address*" required="">
              			</p>
              			<p class="comment-form-url" style="width: 47.3333%">
              				<input name="mobile" type="tel" maxlength="10" placeholder="10 digit mobile number*" required="">
              			</p>
              			<p class="comment-form-author text">
          				    <input name="address" type="text" placeholder="Current residence address" required="">
          			    </p>
          			    <p class="comment-form-author text">
          			        <select name="state" class="form-control" required="">
          			            <option>--- Select State ---</option>
                                <option name="state" value="Andhra Pradesh">Andhra Pradesh</option>
                                <option name="state" value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                <option name="state" value="Arunachal Pradesh">Arunachal Pradesh</option>
                                <option name="state" value="Assam">Assam</option>
                                <option name="state" value="Bihar">Bihar</option>
                                <option name="state" value="Chandigarh">Chandigarh</option>
                                <option name="state" value="Chhattisgarh">Chhattisgarh</option>
                                <option name="state" value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                <option name="state" value="Daman and Diu">Daman and Diu</option>
                                <option name="state" value="Delhi">Delhi</option>
                                <option name="state" value="Lakshadweep">Lakshadweep</option>
                                <option name="state" value="Puducherry">Puducherry</option>
                                <option name="state" value="Goa">Goa</option>
                                <option name="state" value="Gujarat">Gujarat</option>
                                <option name="state" value="Haryana">Haryana</option>
                                <option name="state" value="Himachal Pradesh">Himachal Pradesh</option>
                                <option name="state" value="Jammu and Kashmir">Jammu and Kashmir</option>
                                <option name="state" value="Jharkhand">Jharkhand</option>
                                <option name="state" value="Karnataka">Karnataka</option>
                                <option name="state" value="Kerala">Kerala</option>
                                <option name="state" value="Madhya Pradesh">Madhya Pradesh</option>
                                <option name="state" value="Maharashtra">Maharashtra</option>
                                <option name="state" value="Manipur">Manipur</option>
                                <option name="state" value="Meghalaya">Meghalaya</option>
                                <option name="state" value="Mizoram">Mizoram</option>
                                <option name="state" value="Nagaland">Nagaland</option>
                                <option name="state" value="Odisha">Odisha</option>
                                <option name="state" value="Punjab">Punjab</option>
                                <option name="state" value="Rajasthan">Rajasthan</option>
                                <option name="state" value="Sikkim">Sikkim</option>
                                <option name="state" value="Tamil Nadu">Tamil Nadu</option>
                                <option name="state" value="Telangana">Telangana</option>
                                <option name="state" value="Tripura">Tripura</option>
                                <option name="state" value="Uttar Pradesh">Uttar Pradesh</option>
                                <option name="state" value="Uttarakhand">Uttarakhand</option>
                                <option name="state" value="West Bengal">West Bengal</option>
                            </select>
          			    </p>
          			    <p class="comment-form-author text">
          				    <input name="pincode" type="text" pattern="^[0-9]{6}$" maxlength="6" placeholder="Current residence pincode" required="">
          			    </p>
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="vendorpreference" required="">
                  			   <option>--- Select Vendor Preferences ---</option>
                  			   <option name="vendorpreference" value="Lendingkart">Lendingkart</option>
                  			   <option name="vendorpreference" value="Bajaj Finance">Bajaj Finance</option>
                  			   <option name="vendorpreference" value="Dhani Loan">Dhani Loan</option>
                  			   <option name="vendorpreference" value="Credit Enable">Credit Enable</option>
                  			</select>
          			    </p>
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="loantype" required="">
                  			   <option>--- Select Loan Type ---</option>
                  			   <option name="loantype" value="Personal Loan">Personal Loan</option>
                  			   <option name="loantype" value="Business Loan">Business Loan</option>
                  			   <option name="loantype" value="Gold Loan">Gold Loan</option>
                  			</select>
          			    </p>
          			    <p class="comment-form-email text-amt" style="width: 96.3333%;">
          			        <label style="color: #1caffd;">Required Loan Amount</label>
              				<input name="amount" type="text" placeholder="Required Loan Amount" value="0" required="">
              			</p>
              			
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Apply Now <i class="fa fa-arrow-right push-right"></i></span></button>
              			</p>
          		</form>
          		
        </aside> 	
      </div>
      <div class="st-hero-slide st-style1 st-flex">
        <div class="col-lg-8">
        <div class="container">
          <div class="st-hero-text st-style1">
            <h2 class="st-hero-title">Simple, & hassle-free Personal Loan<br />companies and other financial institutions </h2>
            <div class="st-hero-subtitle">
             Limty help you find the lowest interest rates <br />by working on your behalf with multiple banks NBFCs 
              
            </div>
            <div class="st-btn-group st-style1">
              <a href="#" class="st-btn st-style1 st-color1">Learn More</a>
              <!--<a href="https://www.youtube.com/embed/jRcfE2xxSAw?autoplay=1" class="st-btn st-style2 st-video-open"><i class="flaticon-multimedia"></i> Watch Video</a>-->
            </div>
          </div>
        </div>
        </div>
        <aside class="col-lg-4 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>Check Business Loan Eligibility in 2 mins</b></div>
                <br>
          		<form method="post" class="comment-form" action="<?php echo e(route('apply_loan_registration')); ?>">
          		    <?php echo csrf_field(); ?>
          		        <p class="comment-form-author text">
          				    <input name="fname" type="text" pattern="[a-zA-Z'-'\s]*" placeholder="First &amp; Last Name (as per PAN card)*" required="">
          			    </p>
              			<p class="comment-form-email" style="width: 49.3333%">
              				<input name="email" type="email" placeholder="E-mail Address*" required="">
              			</p>
              			<p class="comment-form-url" style="width: 47.3333%">
              				<input name="mobile" type="tel" maxlength="10" placeholder="10 digit mobile number*" required="">
              			</p>
              			<p class="comment-form-author text">
          				    <input name="address" type="text" placeholder="Current residence address" required="">
          			    </p>
          			    <p class="comment-form-author text">
          			        <select name="state" class="form-control" required="">
          			            <option>--- Select State ---</option>
                                <option name="state" value="Andhra Pradesh">Andhra Pradesh</option>
                                <option name="state" value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                <option name="state" value="Arunachal Pradesh">Arunachal Pradesh</option>
                                <option name="state" value="Assam">Assam</option>
                                <option name="state" value="Bihar">Bihar</option>
                                <option name="state" value="Chandigarh">Chandigarh</option>
                                <option name="state" value="Chhattisgarh">Chhattisgarh</option>
                                <option name="state" value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                <option name="state" value="Daman and Diu">Daman and Diu</option>
                                <option name="state" value="Delhi">Delhi</option>
                                <option name="state" value="Lakshadweep">Lakshadweep</option>
                                <option name="state" value="Puducherry">Puducherry</option>
                                <option name="state" value="Goa">Goa</option>
                                <option name="state" value="Gujarat">Gujarat</option>
                                <option name="state" value="Haryana">Haryana</option>
                                <option name="state" value="Himachal Pradesh">Himachal Pradesh</option>
                                <option name="state" value="Jammu and Kashmir">Jammu and Kashmir</option>
                                <option name="state" value="Jharkhand">Jharkhand</option>
                                <option name="state" value="Karnataka">Karnataka</option>
                                <option name="state" value="Kerala">Kerala</option>
                                <option name="state" value="Madhya Pradesh">Madhya Pradesh</option>
                                <option name="state" value="Maharashtra">Maharashtra</option>
                                <option name="state" value="Manipur">Manipur</option>
                                <option name="state" value="Meghalaya">Meghalaya</option>
                                <option name="state" value="Mizoram">Mizoram</option>
                                <option name="state" value="Nagaland">Nagaland</option>
                                <option name="state" value="Odisha">Odisha</option>
                                <option name="state" value="Punjab">Punjab</option>
                                <option name="state" value="Rajasthan">Rajasthan</option>
                                <option name="state" value="Sikkim">Sikkim</option>
                                <option name="state" value="Tamil Nadu">Tamil Nadu</option>
                                <option name="state" value="Telangana">Telangana</option>
                                <option name="state" value="Tripura">Tripura</option>
                                <option name="state" value="Uttar Pradesh">Uttar Pradesh</option>
                                <option name="state" value="Uttarakhand">Uttarakhand</option>
                                <option name="state" value="West Bengal">West Bengal</option>
                            </select>
          			    </p>
          			    <p class="comment-form-author text">
          				    <input name="pincode" type="text" pattern="^[0-9]{6}$" maxlength="6" placeholder="Current residence pincode" required="">
          			    </p>
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="vendorpreference" required="">
                  			   <option>--- Select Vendor Preferences ---</option>
                  			   <option name="vendorpreference" value="Lendingkart">Lendingkart</option>
                  			   <option name="vendorpreference" value="Bajaj Finance">Bajaj Finance</option>
                  			   <option name="vendorpreference" value="Dhani Loan">Dhani Loan</option>
                  			   <option name="vendorpreference" value="Credit Enable">Credit Enable</option>
                  			</select>
          			    </p>
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="loantype" required="">
                  			   <option>--- Select Loan Type ---</option>
                  			   <option name="loantype" value="Personal Loan">Personal Loan</option>
                  			   <option name="loantype" value="Business Loan">Business Loan</option>
                  			   <option name="loantype" value="Gold Loan">Gold Loan</option>
                  			</select>
          			    </p>
          			    <p class="comment-form-email text-amt" style="width: 96.3333%;">
          			        <label style="color: #1caffd;">Required Loan Amount</label>
              				<input name="amount" type="text" placeholder="Required Loan Amount" value="0" required="">
              			</p>
              			
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Apply Now <i class="fa fa-arrow-right push-right"></i></span></button>
              			</p>
          		</form>
        </aside> 
      </div>
    </div>
    <!-- End Hero Slider -->
    
        <!-- Start Icon Box -->
    <section class="st-section-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="st-iconbox st-style1 text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <div class="st-iconbox-icon">
                <i class="flaticon-focus"></i>
              </div>
              <h3 class="st-iconbox-title">Grow your Business With Us</h3>
              <div class="st-iconbox-text">
                 We offer you a fast, secure and no-collateral business loan. We are bankers who believe in helping businesses succeed, not by giving loans with conditions, but by working alongside them to find solutions.
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="st-iconbox st-style1 text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
              <div class="st-iconbox-icon">
                <i class="flaticon-career"></i>
              </div>
              <h3 class="st-iconbox-title">Why us?</h3>
              <div class="st-iconbox-text">
                By providing you with a line of credit, we get you the funding you need to start or continue building your business. Whether you need to get started or are looking for funding to quickly expand your current operations, we’re here to help!
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="st-iconbox st-style1 text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
              <div class="st-iconbox-icon">
                <i class="flaticon-career-1"></i>
              </div>
              <h3 class="st-iconbox-title">Who We are?</h3>
              <div class="st-iconbox-text">
                Limty is an online platform that provides customers with financial products and services, such as personal loans, unsecured loans, installment loans and credit cards.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Icon Box -->
    
    <!-- Start Skill Section -->
    <section class="st-skill-wrap st-section-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="st-vertical-middle">
              <div class="st-vertical-middle-in wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.2s">
                <div class="st-skill-img text-center">
                  <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/skill-img.png')); ?>" alt="demo">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="st-section-heading st-style2 st-type2">
              <h2>Simple, & hassle-free Personal Loan</h2>
              <p>we help you find the lowest interest rates by working on your behalf with multiple banks NBFCs</p>
            </div>
            
            <a href="<?php echo e(route('personal_loan')); ?>" class="st-btn st-style1 st-size1 st-color2">Get Started</a>
            <!--<div class="st-progressbar-wrap">-->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Web Development</h3>-->
            <!--      <div class="st-progressbar-percentage">90%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="90">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Web Design</h3>-->
            <!--      <div class="st-progressbar-percentage">95%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="95">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">HTML / CSS</h3>-->
            <!--      <div class="st-progressbar-percentage">85%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="85">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">WordPress</h3>-->
            <!--      <div class="st-progressbar-percentage">80%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="80">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Photoshop</h3>-->
            <!--      <div class="st-progressbar-percentage">95%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="95">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--</div>-->
          </div>
        </div>
      </div>
    </section>
    <!-- End Skill Section -->
    
    <br>


    <!-- Start CTA Section -->
    <section class="st-cta-wrap st-gray-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 offset-lg-1">
            <div class="st-cta text-center st-section">
              <h2 class="st-cta-title">Save more by choosing the right credit card.</h2>
              <div class="st-cta-text">Personalised card offers curated from a list of 40+ credit cards</div>
              <div class="st-cta-btn">
                <a href="<?php echo e(route('personal_loan')); ?>" class="st-btn st-style1 st-size1 st-color1">Get Started</a>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="st-vertical-middle">
              <div class="st-vertical-middle-in st-flex">
                <div class="st-cta-img wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s">
                  <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/cta-img.png')); ?>" alt="demo">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End CTA Section -->
    
    <section class="st-skill-wrap st-section-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="st-vertical-middle">
              <div class="st-vertical-middle-in wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.2s">
                <div class="st-skill-img text-center">
                  <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/testimonial-img.png')); ?>" alt="demo">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="st-section-heading st-style2 st-type2">
              <h2>Gold loan is your key to fastest cash</h2>
              <p>Get your loan disbursed in minutes, at interest rates starting from 0.89% only</p>
            </div>
            
            <a href="<?php echo e(route('personal_loan')); ?>" class="st-btn st-style1 st-size1 st-color2">Get Started</a>
            <!--<div class="st-progressbar-wrap">-->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Web Development</h3>-->
            <!--      <div class="st-progressbar-percentage">90%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="90">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Web Design</h3>-->
            <!--      <div class="st-progressbar-percentage">95%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="95">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">HTML / CSS</h3>-->
            <!--      <div class="st-progressbar-percentage">85%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="85">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">WordPress</h3>-->
            <!--      <div class="st-progressbar-percentage">80%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="80">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--  <div class="st-single-progressbar">-->
            <!--    <div class="st-progressbar-meta">-->
            <!--      <h3 class="st-progressbar-title">Photoshop</h3>-->
            <!--      <div class="st-progressbar-percentage">95%</div>-->
            <!--    </div>-->
            <!--    <div class="st-progressbar" data-progress-percentage="95">-->
            <!--      <div class="st-progressbar-in wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s"></div>-->
            <!--    </div>-->
            <!--  </div><!-- .st-single-progressbar -->
            <!--</div>-->
          </div>
        </div>
      </div>
    </section>
    

    <!-- Start About Section -->
    <div class="st-about-wrap st-section-top" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="st-vertical-middle">
              <div class="st-vertical-middle-in">
                <div class="st-about-img wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.2s"><img src="<?php echo e(URL::asset('public/front/assets/img/light-img/about-img1.png')); ?>" alt="demo"></div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="st-section-heading st-style1">
              <h3>Personal Loans starting 10.75%</h3>
              <h2>Personal Loan – Low interest rate personal loans From More than 100+ Lendors</h2>
            </div>
            <div class="st-about-text">
              <p>  When you need a personal loan, your options are limitless. There are many lenders, underwriting criteria, repayment options and more to choose from. The only decision that you have to make is whether you want an overdraft facility or not. Overdraft facilities can be arranged if you have a credit score of 720 or above but will not help if your credit score is lower than this rating.</p>
              <ul class="tr-list">
                <li> personal loan can help you mitigate the immediate debt crisis</li>
                <li>Inastant Unsecured Loan</li>
                <li>Low Credit Score No Worries Apply with us.</li>
                <li>Get Instant Credit</li>
              </ul>
              <a href="<?php echo e(route('personal_loan')); ?>" class="st-btn st-style1 st-size1 st-color2">Get More Info!</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End About Section -->
    
    <!-- Start Service Section -->
    <section class="st-service-section st-section-top" id="service">
      <div class="container">
        <div class="st-section-heading st-style2 text-center">
          <h2>Fast and Secure Processing</h2>
          <div class="st-seperator">
            <div class="st-seperator-left-bar wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
            <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/seperator-icon.png')); ?>" alt="demo" class="st-seperator-icon">
            <div class="st-seperator-right-bar wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
          </div>
          <p> Limty is a company that helps millions of people access financial products that are relevant and available to them. </br>We do it by working with the best and biggest loan providers in the banking & financial world.</p>
        </div>
      </div>
      <div class="st-owl-controler3-hover">
        <div class="container">
          <div class="st-service-carousel owl-carousel st-style2 st-owl-controler3">
            <div class="st-image-box st-style1 text-center wow fadeIn" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <a href="#" class="st-image">
                  <!--<img src="assets/img/light-img/service1.png" alt="demo">-->
              </a>
              <div class="st-image-box-info">
                <h3 class="st-image-box-title"><a href="#">Personalised Offers</a></h3>
                <div class="st-image-box-text"> Get your loan approved within 24 hours. Get customized offers for all types of loans, at interest rates starting 10.75% for a tenure ranging from 1 year to 5 years.</div>
              </div>
            </div>
            <div class="st-image-box st-style1 text-center wow fadeIn" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <a href="#" class="st-image">
                  <!--<img src="assets/img/light-img/service1.png" alt="demo">-->
              </a>
              <div class="st-image-box-info">
                <h3 class="st-image-box-title"><a href="#">Line of Credit</a></h3>
                <div class="st-image-box-text">  Limty has made it easy for the first-time borrowers. We offer Loans starting at Rs 15000 and going up to 2 Lakh.</div>
              </div>
            </div>
            <div class="st-image-box st-style1 text-center wow fadeIn" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <a href="#" class="st-image">
                  <!--<img src="assets/img/light-img/service1.png" alt="demo">-->
              </a>
              <div class="st-image-box-info">
                <h3 class="st-image-box-title"><a href="#">Lowest Interest Rate</a></h3>
                <div class="st-image-box-text">Get lowest interest rates as low as 10.75% onwards on your personal loan</div>
              </div>
            </div>
            <div class="st-image-box st-style1 text-center wow fadeIn" data-wow-duration="0.8s" data-wow-delay="0.25s">
              <a href="#" class="st-image">
                  <!--<img src="assets/img/light-img/service2.png" alt="demo">-->
              </a>
              <div class="st-image-box-info">
                <h3 class="st-image-box-title"><a href="#">Lighting Disbursals</a></h3>
                <div class="st-image-box-text"> Get your loan funded in 24 hours with minimal documentation. We provide a simple and easy solution for anyone seeking fast and reliable cash liquidity that can be used for any purpose.</div>
              </div>
            </div>
            <div class="st-image-box st-style1 text-center wow fadeIn" data-wow-duration="0.8s" data-wow-delay="0.3s">
              <a href="#" class="st-image">
                  <!--<img src="assets/img/light-img/service3.png" alt="demo">-->
              </a>
              <div class="st-image-box-info">
                <h3 class="st-image-box-title"><a href="#">Safe & Secure</a></h3>
                <div class="st-image-box-text"> We know that the privacy and security of your personal information is extremely important to you, and we are committed to protecting it. Our privacy policy provides an overview of how we collect, use and manage information when you engage with us.</div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
      
    </section>
    <!-- End Service Section -->
    <br><br>
    
    <section class="light-grey-bg section-padding">
        <div class="container">
            <div class="animation-element row align-items-end in-view">
                <div class="col-lg-12 col-md-12">
                    <div class="new-home-heading text-center">Our Partners</div>
                    <h3 class="bottom-fadein mt-4 text-center partner-content">
                        We collaborate with the best and biggest in the banking
                       and financial <br class="d-none d-sm-block">world to get you relevant products at great rates
                    </h3>
                    <ul class="partner-ul">
                        <li>
                          <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner1.png')); ?>" class="img-fluid d-none d-sm-block">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner1-small.png')); ?>" class="img-fluid d-sm-none">
                          </div>
                        </li>
                        <li class="mr-none">
                            <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner2.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li>
                            <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner3.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li class="mr-none">
                            <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner4.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li class="mr-sm-0">
                            <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner5.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        
                    </ul>
                    <ul class="partner-ul mt-0">
                        <li>
                            <div class="partner-container">
                              <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner6.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li class="mr-none">
                            <div class="partner-container">
                                <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner7.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li>
                            <div class="partner-container">
                                <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner8.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li class="mr-none">
                            <div class="partner-container">
                                <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner9.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                        <li class="mr-0 d-none d-sm-block">
                            <div class="partner-container">
                                <img src="<?php echo e(URL::asset('public/front/assets/img/clients/partner10.png')); ?>" class="img-fluid">
                            </div>
                        </li>
                    </ul>
                    
                </div>

            </div>
        </div>
    </section>

    <!-- Start Project Section -->
    <div class="st-project-wrap st-section-top" id="portfolio">
      <div class="container">
        <div class="st-section-heading st-style2 text-center">
          <h2>How does CREDIFINOW work?</h2>
          <div class="st-seperator">
            <div class="st-seperator-left-bar wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
            <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/seperator-icon.png')); ?>" alt="demo" class="st-seperator-icon">
            <div class="st-seperator-right-bar wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
          </div>
          <p>We are humbled that our work has been recognised</p>
        </div>
      </div>
      <div class="st-project st-project-carousel owl-carousel st-style1 st-owl-controler1">
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Personal Loan Interest Rate</a></h2>
                <div class="st-blog-text"> We offer the most competitive loan interest rates in the industry. Our goal is to help you buy a home or refinance your existing mortgage at a rate that's right for you. We can tailor make a loan specially just for you - while still offering the same great rates on our standard loans.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Personal Loan Tenure</a></h2>
                <div class="st-blog-text">The loan tenure of a personal loan starts from 12 months EMI  and goes up to a maximum of 60 months EMI. It is up to the borrower, he or she can choose the tenure as per the affordability and loan requirement, be it short term or long term. The major effect of repayment tenure will be reflected on your equated monthly instalment and the total interest payable. Choosing the longer tenure would mean that you will be paying a higher interest over the loan eventually. Opting for a longer tenure would also mean that you will be paying a higher interest over the loan duration period.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Documents required to apply for a Personal loan</a></h2>
                <div class="st-blog-text">A loan applicant at the time of filing a loan application has to provide the financial institutions including banks and NBFCs a certain document like identity proof, address proof, PAN Card, Aadhaar Card, Salary slips, latest bank statements. The financial institution verifies the documents to get the complete picture and then will proceed further. After verification of all documents, the loan disbursement is taken place.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Personal Loan With Zero Pre-Payment Fee</a></h2>
                <div class="st-blog-text">Most banks or financial institutions will allow you part prepayment the principal on your loan before the maturity date. Part prepayment is only done once a year, and requires that you are able to pay down at least 25% of your outstanding principal balance before the maturity date. Typically, most lenders will charge 2.5% + GST on any prepayment amount that is over 25% of the principal due.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Low-Interest Personal Loan</a></h2>
                <div class="st-blog-text">Lmity has collaborated with the top financial providers to offer you the lowest possible interest rates. Here, interest rates start from 10.75% and goes up to 25% based on your creditworthiness. We will also try to help you in getting the lowest possible interest rate.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Personal Loan From Banks</a></h2>
                <div class="st-blog-text">Limty  is an online B2B lending company which offers loan at competitive rates to the individuals and businesses. We partner with the big banks, NBFCs and other credit providers like Hero FinServ, HDFC Bank and a host of other financial institutions to offer you a wide range of interest rates that suit your budget and requirements.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Private Financing</a></h2>
                <div class="st-blog-text">RBI regulated entities offer good personal loan options to the credit-risk individuals. This is because these companies follow a transparent process in terms of collection perspectives, offering tenure and interest rates. To ensure that you are getting a fair deal while borrowing money from RBI regulated entity, always choose a reliable company with a good track record.</div>
                
              </div>
        </div>
        
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">New To Credit Loans</a></h2>
                <div class="st-blog-text"> Limty is a unique financial solutions provider and an umbrella of microfinance companies, which has been working with communities around India to bring bank-based credit to millions of people. Our mission is to improve the quality of life for individuals and families in India by improving access to bank-based lending.</div>
                
              </div>
        </div>
        
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Reasons for Personal Loan application Rejections</a></h2>
                <div class="st-blog-text"> Most of the Personal loan application rejection is due to bad credit history or lack of enough income proof. So, to get approved for the personal loan, you need to have good credit score or previous bank statements with all the details. Limty is a company having financial expertise and offering affordable personal loan options to its customers.</div>
                
              </div>
        </div>
        
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Banks and NBFCs Partners of Limty</a></h2>
                <div class="st-blog-text"> The Limty has collaborated with the top banks and financial institutions who are offering the best-in-class loan offers. These are HDFC Bank, ICICI Bank, Kotak Bank, IDFC First Bank, Bajaj FinServ, RBL Bank, YES Bank, Fullerton, Clix Capital, and Tata Capital.</div>
                
              </div>
        </div>
        <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 0.8s; animation-delay: 0.2s; animation-name: fadeInUp;">
              <div class="st-blog-info">
                
                <h2 class="st-blog-title"><a href="#">Credit Report</a></h2>
                <div class="st-blog-text"> This is a full detailed and accurate credit report of the loan seeker. It contains information about the individual’s financial history like repayment history, amount of loan, tenure of loan and open date, close date, etc. This report will be useful for individual who wants to apply for any credit facility such as personal loans, home loans, gold loans or car loans etc. It also comes handy for individuals who are planning to buy a property and want to take the help of mortgage lenders.</div>
                
              </div>
        </div>
        
        
      </div>
    </div>
    <!-- End Project Section -->
    <br>

    <!-- Start Testimonial Section -->
    <section class="st-testimonial-wrap st-section st-gray-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="st-testimonial-right-img st-flex wow fadeInLeft" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/d-app.png')); ?>" alt="demo">
            </div>
          </div>
          <div class="col-lg-6">
            <div class="st-vertical-middle">
              <div class="st-vertical-middle-in">
                <div class="st-section-heading st-style1">
                  <h3>Our Happy Customers</h3>
                  <h2>What they say about us</h2>
                </div>
                <div class="st-testimonial-slider owl-carousel st-owl-controler4">
                  <div class="st-single-testimonial">
                    <div class="st-testimonial-quote st-flex"><i class="fas fa-quote-right"></i></div>
                    <div class="st-testimonial-text">“Excellent app!! A perfect to manage all your expenses, and also very efficient for fast loan approvals! ”</div>
                    <div class="st-testimonial-meta">
                      <h3>4.5/5</h3>
                      <p>Pramit Roy</p>
                    </div>
                  </div>
                  <div class="st-single-testimonial">
                    <div class="st-testimonial-quote st-flex"><i class="fas fa-quote-right"></i></div>
                    <div class="st-testimonial-text">“Good Application to check your Credit score for the current month and that too free of cost and also get some offer from banks in which you are eligible. Nice app overall. ”</div>
                    <div class="st-testimonial-meta">
                      <h3>4.5/5</h3>
                      <p>Abhinav Bansal</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Testimonial Section -->

    <!-- Start News Letter Section -->
    <section class="st-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="st-newsletter-wrap">
              <div class="st-left-newsletter">
                <div class="st-section-heading st-style1 st-type1">
                  <h3>Just a moment</h3>
                  <h2>Subscribe to our newsletter</h2>
                </div>
                <div class="st-newsletter">
                  <div class="st-newsletter-text">Subscribe to our Newsletter. We'll send email notifications everytime we release new Template.</div>
                  <form class="mailchimp st-subscribe-form" action="https://storerepublic.us12.list-manage.com/subscribe/post?u=d227d8d335060b093084903d0&amp;id=9ba078ceb0">
                    <input type="email" name="subscribe" id="subscriber-email" placeholder="Enter your Email">
                    <button type="submit" id="subscribe-button" class="st-newsletter-btn"><i class="flaticon-plane"></i></button>
                    <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
                    <h5 class="subscription-success"> .</h5>
                    <h5 class="subscription-error"> .</h5>
                    <label class="subscription-label" for="subscriber-email"></label>
                  </form>
                </div>
              </div>
              <div class="st-right-newsletter">
                <div class="st-newsletter-img wow fadeInRight" data-wow-duration="0.8s" data-wow-delay="0.2s">
                  <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/news-letter-img.png')); ?>" alt="demo">
                  <div class="st-bard-animation">
                    <div class="st-bard-animation1"><img src="<?php echo e(URL::asset('public/front/assets/img/light-img/bard1.png')); ?>" alt="demo"></div>
                    <div class="st-bard-animation2"><img src="<?php echo e(URL::asset('public/front/assets/img/light-img/bard2.png')); ?>" alt="demo"></div>
                    <div class="st-bard-animation3"><img src="<?php echo e(URL::asset('public/front/assets/img/light-img/bard3.png')); ?>" alt="demo"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End News Letter Section -->
    
    <!-- Start Blog Section -->
    <section class="st-blog-wrap st-section" id="blog">
      <div class="container">
        <div class="st-section-heading st-style2 text-center">
          <h2>Latest News</h2>
          <div class="st-seperator">
            <div class="st-seperator-left-bar wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
            <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/seperator-icon.png')); ?>" alt="demo" class="st-seperator-icon">
            <div class="st-seperator-right-bar wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
          </div>
          <p>Recent Article | News and blogs are common sources for feeds.</p>
        </div>
      </div>
      <div class="container">
        <div class="row">
            
          <?php 
				foreach ($latest_blog as $w) {
		  ?>
		  
          <div class="col-lg-4">
            <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <div class="st-zoom">
                <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>" class="st-blog-thumb st-bg st-zoom-in" data-src="<?php echo URL::asset('public/upload/blog_image/'.$w->blog_image.'') ?>"></a>
              </div>
              <div class="st-blog-info" style="height: 200px;">
                <div class="st-blog-label">By <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>"><?php echo $w->blogger; ?></a></div>
                <h2 class="st-blog-title"><a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>"><?php echo $w->heading; ?></a></h2>
                <div class="st-blog-text">
                    <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>">
                      <?php echo $w = substr(($w->description), 0,100);  ?>...
                    </a>
                </div>
                
              </div>
            </div>
          </div>
          
          <?php } ?>
          
        </div>
      </div>
    </section>
    <!-- End Blog Section -->
    
    <!-- Start Contact Section -->
    <section class="st-contact-wrap st-gray-bg st-section" id="contact" style="margin-bottom: 0px;">
      <div class="container">
        <div class="st-section-heading st-style2 text-center">
          <h2>Contact Us</h2>
          <div class="st-seperator">
            <div class="st-seperator-left-bar wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
            <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/seperator-icon.png')); ?>" alt="demo" class="st-seperator-icon">
            <div class="st-seperator-right-bar wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
          </div>
          <p>News websites and blogs are common sources for web feeds, but feeds are also <br>used to deliver structured</p>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div id="cf-msg"></div>
            <form method="post" action="<?php echo e(route('apply_contact_us')); ?>" class="st-contact-form">
                <?php echo csrf_field(); ?>
              <input type="text" placeholder="Full Name" id="name" name="name">
              <input type="email" placeholder="Email Address" id="email" name="email">
              <input type="text" placeholder="Subject" id="subject" name="subject">
              <textarea cols="30" rows="10" placeholder="Your Message" id="msg" name="message"></textarea>
              <button class="st-btn st-style1 st-size1 st-color1" type="submit" id="submit" name="submit">Send Message</button>
            </form>
          </div>
          <div class="col-lg-6">
            <div class="st-contact-info st-style1">
              <div class="st-contact-info-in">
                <h3 class="st-contact-info-title">Contact Info</h3>
                <div class="st-contact-info-text">Contact is the most important part of businessess. If you need any information about our business, contact the information provided below</div>
                <h3 class="st-contact-info-title">Corporate Office</h3>
                <ul>
                  <li><i class="fas fa-map-signs"></i>111 Camino Del Rio Suite 300 San Diego</li>
                  <li><i class="fas fa-phone"></i>+00 222- 333 -7889</li>
                  <li><i class="fas fa-envelope"></i><a href="#">support@limty.com</a></li>
                  <li><i class="fas fa-globe"></i><a href="#">www.limty.com</a></li>
                </ul>
              </div>
              <div class="st-svg-animation1">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="590px" height="436px">
                  <defs>
                    <filter filterUnits="userSpaceOnUse" id="Filter_0" x="0px" y="0px" width="590px" height="436px"  >
                        <feOffset in="SourceAlpha" dx="0" dy="5" />
                        <feGaussianBlur result="blurOut" stdDeviation="3.162" />
                        <feFlood flood-color="rgb(106, 106, 106)" result="floodOut" />
                        <feComposite operator="atop" in="floodOut" in2="blurOut" />
                        <feComponentTransfer><feFuncA type="linear" slope="0.15"/></feComponentTransfer>
                        <feMerge>
                        <feMergeNode/>
                        <feMergeNode in="SourceGraphic"/>
                      </feMerge>
                    </filter>
                  </defs>
                  <g filter="url(#Filter_0)">
                    <path fill-rule="evenodd"  fill="rgb(255, 255, 255)" d="M359.506,400.811 C311.350,416.741 266.303,427.200 215.885,416.924 C166.065,406.770 119.155,382.030 83.358,345.883 C32.880,294.910 5.320,222.074 9.403,150.433 C11.889,106.817 27.202,61.676 61.083,34.027 C101.026,1.428 158.043,-0.486 208.701,8.960 C259.358,18.407 308.226,37.556 359.592,41.763 C414.001,46.218 473.787,34.861 519.488,64.652 C532.722,73.279 543.780,84.912 553.231,97.563 C563.583,111.419 572.219,126.797 576.587,143.532 C584.814,175.056 577.226,208.904 563.417,238.444 C538.267,292.240 493.162,335.144 441.630,364.721 C415.638,379.639 387.934,391.407 359.506,400.811 Z"/>
                  </g>
                </svg>
              </div><!-- .st-svg-animation1 -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Contact Section -->

    
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/index.blade.php ENDPATH**/ ?>