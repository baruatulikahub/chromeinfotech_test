
<?php $__env->startSection('content'); ?>



<br><br><br>
<section class="light-grey-bg section-padding   bg-light-white">
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-12 text-center">
                <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/location.svg')); ?>" class="choose-points-icon" style="width: 48px;height: 79px;">
                <p class="col-12 p-0 mb-2 new-home-heading" style="font-size: 40px;line-height: 60px; font-weight: 700; color: #3C374D;">
                    Credifinow
                </p>
                <p class="mb-2 font16">301, Durga Chambers, Off Link Road, Fun Republic Lane, Andheri West, Mumbai - 400053.</p>
            </div>
            <div class="col-md-6 col-12 text-center pb-md-0 pb-5 mt-5">
                <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/mail-envelope.svg')); ?>" class="mail-icon" style="width: 48px;height: 79px;">
                <p class="mt-3 mb-0 font16">Send us mail at</p>
                <a href="mailto:support@credifinow.com">support@credifinow.com</a>
            </div>
            <div class="col-md-6 col-12 text-center pb-md-0 pb-5 mt-5">
                <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/mail-envelope.svg')); ?>" class="mail-icon" style="width: 48px;height: 79px;">
                <p class="mt-3 mb-0 font16">For credit report related issues mail us at</p>
                <a href="mailto:score@credifinow.com">score@credifinow.com</a>
            </div>
        </div>
    </div>
</section>

<div class="st-map-wrap">
      <div class="st-map-bar st-flex">
        <div class="st-map-bar-img">
          <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/map-icon-img.png')); ?>" alt="demo">
          <div class="st-map-bar-icon"><i class="fas fa-map-marker-alt"></i></div>
        </div>
      </div>
      <div class="st-map-wrpa">
        <div class="st-google-map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d15077.830133775558!2d72.8243078790885!3d19.13143954289655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s301%2C%20Durga%20Chambers%2C%20Off%20Link%20Road%2C%20Fun%20Republic%20Lane%2C%20Andheri%20West%2C%20Mumbai%20-%20400053!5e0!3m2!1sen!2sin!4v1658992904435!5m2!1sen!2sin" allowfullscreen="" ></iframe>
          
        </div>
      </div>
</div>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/contact_us.blade.php ENDPATH**/ ?>