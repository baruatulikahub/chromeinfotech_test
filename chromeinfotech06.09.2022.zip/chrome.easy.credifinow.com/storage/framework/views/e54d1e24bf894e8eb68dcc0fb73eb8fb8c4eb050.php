<!doctype html>
<html class="no-js" lang="en">
    <body>
        <section>
            <div class="container">
                <div class="section_heading align-center">
                    <h2> <span>Hi <?php echo e($fname); ?>,</span> </h2>
                </div><!-- /Section Heading -->
                
                <div class="row promo_wrapper">
                    <div class="col-md-4 col-sm-6 sm-padding">
                        <div class="promo_content align-center">
                            <h5>Thank you for registering! <br>
                             Your personal loan application is now successfully registered!</h5>
                            <h4>Regards,</h4>
                            <h3>Limty</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>       
    </body>
</html><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/personal_loan_mail.blade.php ENDPATH**/ ?>