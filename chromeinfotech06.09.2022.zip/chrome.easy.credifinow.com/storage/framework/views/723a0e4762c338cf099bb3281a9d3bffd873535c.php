
<?php $__env->startSection('content'); ?>
    
    <!-- Header -->
    <div class="header  pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0"></h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">User Tables</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Users</li>
                </ol>
              </nav>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
       <div class="row">
          <div class="col-lg-12 ml-auto mr-auto">
              <?php if(Session::has('usermsg')): ?>                 
                  <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                       <strong><?php echo e(Session::get('usermsg')); ?></strong>
                  </div>
                  <?php echo e(Session::forget('message')); ?>

                  <?php echo e(Session::forget('usermsg')); ?>

              <?php endif; ?>
          </div>
        </div>
      <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <h3 class="mb-0">User List </h3>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="budget">User Name </th>
                    <th scope="col" class="sort" data-sort="budget">Email </th>
                    <th scope="col" class="sort" data-sort="budget">Password </th>
                    <th scope="col">Status</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                  </tr>
                </thead>
                <tbody class="list">
                  <?php 
                    foreach ($user_details as $u) {
                  ?>
                    <tr>
                      <td scope="row">
                        <div class="media align-items-center">
                          <div class="media-body">
                            <span class="name mb-0 text-sm"><?php echo $u->user_name; ?></span>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <i class="bg-warning"></i>
                          <span class="status"><?php echo $u->email; ?></span>
                        </span>
                      </td>
                      <td>
                        <span class="badge badge-dot mr-4">
                          <i class="bg-success"></i>
                          <span class="status"><?php echo $u->show_password; ?></span>
                        </span>
                      </td>
                      
                      <td>
                        <?php if($u->status == 'Active'){ ?>
                            <a class="btn btn-success btn-sm" href="<?php echo route('login_status',['User_id'=>''.$u->User_id.'']) ?>"><i class="fa fa-show"></i>Active</a>
                        <?php } else{?>
                            <a class="btn btn-danger btn-sm" href="<?php echo route('login_status',['User_id'=>''.$u->User_id.'']) ?>"><i class="fa fa-show"></i>In Active</a>
                        <?php } ?>                                            
                      </td>
                 
                      <td class="">
                        <div class="dropdown">
                          <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-edit"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            <a class="dropdown-item" href="javascript:void();" data-toggle="modal" data-target="#myeditModal<?php echo $u->User_id; ?>" >Edit</a>
                            
                          </div>
                        </div>
                      </td>
                      <td class="">
                        <div class="dropdown">
                          <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-trash"></i>
                          </a>
                          <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                            
                            <a class="dropdown-item" onclick="alert('Are You Sure To Delete This?')" href="<?php echo route('delete_user_details',['User_id'=>''.$u->User_id.'']) ?>" >Delete</a>
                          </div>
                        </div>
                      </td>
                    </tr>


                    <div class="modal" id="myeditModal<?php echo $u->User_id; ?>">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Update User Details</h4>
                                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">&nbsp;&times;&nbsp;</button>
                            </div>
                            <!-- Modal body -->
                             <div class="modal-body">
                                <form method="post" action="<?php echo e(route('update_user_details')); ?>" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <div class="row">


                                    <div class="col-md-12">  
                                      <div class="form-group bmd-form-group is-filled">
                                        <label>User Name</label>
                                        <input type="hidden" class="form-control" name="update" value="<?php echo $u->User_id; ?>" autocomplete="off" required="" >
                                        <input type="text" name="user_name" class="form-control" required="" value="<?php echo $u->user_name; ?>">
                                        <?php if($errors->has('user_name')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('user_name')); ?></strong>                                  
                                        <?php endif; ?>
                                      </div>
                                    </div>

                                    <div class="col-md-12">  
                                      <div class="form-group bmd-form-group is-filled">
                                        <label>Email</label>
                                        <input type="hidden" class="form-control" name="update" value="<?php echo $u->User_id; ?>" autocomplete="off" required="" >
                                        <input type="email" name="email" class="form-control" required="" value="<?php echo $u->email; ?>">
                                        <?php if($errors->has('email')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>                                  
                                        <?php endif; ?>
                                      </div>
                                    </div>

                                    <div class="col-md-12">  
                                      <div class="form-group bmd-form-group is-filled">
                                        <label>Password</label>
                                        <input type="hidden" class="form-control" name="update" value="<?php echo $u->User_id; ?>" autocomplete="off" required="" >
                                        <input type="text" name="password" class="form-control" required="" value="<?php echo $u->show_password; ?>">
                                        <?php if($errors->has('password')): ?>
                                        <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>                                  
                                        <?php endif; ?>
                                      </div>
                                    </div>

                                   
                                  <div class="col-sm-12">
                                    <div class="form-group bmd-form-group">
                                        <button type="submit" class="btn btn-success btn-block">Update</button>
                                    </div>
                                  </div>

                                  </div>
                              </form>
                             </div>                                               
                        </div>
                      </div>
                    </div>

                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- Card footer -->
  
          </div>
        </div>
      </div>
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/admin/user_list.blade.php ENDPATH**/ ?>