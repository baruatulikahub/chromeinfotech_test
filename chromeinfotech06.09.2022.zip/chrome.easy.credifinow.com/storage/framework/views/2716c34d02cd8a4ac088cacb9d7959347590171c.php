
<?php $__env->startSection('content'); ?>

<br><br><br><br><br>

<section class="light-grey-bg section-padding">
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-6 col-12 text-center ">
                <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/about-us-01.png')); ?>" class="w-100">
            </div>
            <div class="col-md-6 col-12 text-left pb-md-0 pb-5 mt-5">
                <p class="col-12 p-0 mb-5 new-home-heading  ContentHeader">
                    Who are we?
                </p>
                <p class="mb-5" style="font-size: 15px;">
                    CredifiNow is a financial technology start-up based in Delhi-NCR. The company was founded by former UK’s Capital One banker Gaurav Chopra who has more than 15 years of domain expertise in driving innovation in digital finance, credit analytics and mobile payments in the Indian and global markets. We aim to make financial products affordable and easily accessible to the person when needs financial assistance at the most.
                    Our team is equipped with experienced and qualified finance professionals associated from the top-notch institutions such as IIT, LBS, IIM, Stephen's, LSE, and various global banks.
                </p>

            </div>

        </div>
    </div>
</section>




<section class="light-grey-bg section-padding">
    <div class="container">
        <div class="row mt-5 mb-4">
            <div class="col-md-6 col-12 text-center pb-md-0 pb-5 mt-5 order-md-2">
                <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/about-us-02.png')); ?>" class="w-100">
            </div>
            <div class="col-md-6 col-12 text-left pb-md-0 pb-5 mt-5">
                <p class="col-12 p-0 mb-5 new-home-heading ContentHeader">
                    What do we do?
                </p>
                <p class="mb-5" style="font-size: 15px;">
                    We are an online platform that provides our customers with financial products and services such as personal loans, line of credit, credit cards, and gold loans. We connect borrowers with lenders to help them get the best deal possible.
                    We are currently working with 50+ partners which includes of major PSU, private sector banks, and NBFCs.
                    We also provide value-added services to our customers such as free credit score check for maintaining their financial well-being, big-data analytics, credit risk assessment, and automated work-flows for loan origination and management services. The company also offers an open-API model for banks and NBFCs to partner with them through a plug-n-play approach.
                </p>
            </div>

        </div>
    </div>
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/about_us.blade.php ENDPATH**/ ?>