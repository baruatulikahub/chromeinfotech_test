
<?php $__env->startSection('content'); ?>

  
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 470px;">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
          		<form method="post" class="comment-form" action="<?php echo e(route('apply_size_registration')); ?>">
          		    <?php echo csrf_field(); ?>
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="sort" required="">
                  			   <option>--- Select Size ---</option>
                  			   <option name="sort" value="XS">XS</option>
                  			   <option name="sort" value="S">S</option>
                  			   <option name="sort" value="M">M</option>
                  			   <option name="sort" value="L">L</option>
                  			   <option name="sort" value="XL">XL</option>
                  			   <option name="sort" value="XXL">XXL</option>
                  			   <option name="sort" value="Free Size">Free Size</option>
                  			</select>
          			    </p>
          			    <p class="comment-form-author text">
              			    <input name="code" type="text" placeholder="Code*" required="">
          			    </p>
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Save <i class="fa fa-arrow-right push-right"></i></span></button>
              			</p>
          		</form>
          		
        </aside> 	
      </div>
      
    </div>
    
    <div>   
        <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('sizemsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('sizemsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('sizemsg')); ?>

                <?php endif; ?>
            </div>
        </div>
              <table id="memberProfile">
                
                <tr>
                  <td><strong>Sl No.</strong></td>
                  <td><strong>Size</strong></td>
                  <td><strong>Size Code</strong></td>
                  <td><strong>Edit</strong></td>
                  <td><strong>Delete</strong></td>
                </tr>
                <?php 
                    foreach ($size_details as $s) {
                ?>
                <tr>
                  <td><?php echo $s->id; ?></td>
                  <td><?php echo $s->sort; ?></td>
                  <td><?php echo $s->code; ?></td>
                  <td class="">

                    <a class="dropdown-item" href="<?php echo route('edit_size_details',['id'=>''.$s->id.'']) ?>" data-toggle="modal" data-target="#" >Edit <i class="fa fa-pencil" aria-hidden="true"></i></a>
                  </td>
                  <td class="">
                    <a class="dropdown-item" onclick="alert('Are You Sure To Delete This?')" href="<?php echo route('delete_size_details',['id'=>''.$s->id.'']) ?>" >Delete <i class="fa fa-trash" aria-hidden="true"></i></a>
                  </td>
                </tr>
                
                <div class="modal" id="myModal<?php echo $s->id; ?>">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                           Modal Header 
                          <div class="modal-header">
                              <h4 class="modal-title">Update Job Deatils</h4>
                              <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">&nbsp;&times;&nbsp;</button>
                          </div>
                           Modal body 
                           <div class="modal-body">
                              <form method="post" action="<?php echo e(route('update_size_details')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        
                                      <div class="col-md-6">  
                                        <div class="form-group bmd-form-group is-filled" id="user_purpose">
                                          <label class="form-control-label" for="input-username">Size</label>
                                          <input type="hidden" class="form-control" name="update" id="update_id" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                          <input type="text" name="sort" id="input-username" class="form-control" Value="<?php echo $s->sort ?>" placeholder="Size">
                                          <?php if($errors->has('sort')): ?>
                                            <strong class="text-danger"><?php echo e($errors->first('sort')); ?></strong>                                   
                                          <?php endif; ?>
                                        </div>
                                      </div>

                                      <div class="col-md-6">  
                                        <div class="form-group bmd-form-group is-filled">
                                          <label class="form-control-label" for="input-username">Size Code </label>
                                          <input type="hidden" class="form-control" name="update" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                          <input type="text" name="code" id="input-username" class="form-control" Value="<?php echo $s->code?>" placeholder="Size Code">
                                          <?php if($errors->has('code')): ?>
                                            <strong class="text-danger"><?php echo e($errors->first('code')); ?></strong>                                   
                                          <?php endif; ?>
                                        </div>
                                      </div>

                                      <div class="col-sm-4">
                                        <div class="form-group bmd-form-group">
                                            <button type="submit" class="btn btn-success btn-block">Update</button>
                                        </div>
                                      </div>

                                    </div>
                                </form>
                           </div>                                               
                      </div>
                    </div>
                </div>

                <?php } ?>
              
              </table>
    </div>
    <br>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/chrome.easy.credifinow.com/resources/views/front/sizes.blade.php ENDPATH**/ ?>