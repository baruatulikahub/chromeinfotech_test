<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="author" content="">
<meta name="theme-color" content="#ff8a00">
<meta name="description" content="Job Portal">
<meta name="keywords" content="Employment, Naukri, Shine, Indeed, Job Posting, Job Provider">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>:: Tulika Test - PWC ::</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--  Favicon -->
<link rel="shortcut icon" href="#">
<!-- CSS -->
<link rel="stylesheet" href="<?php echo e(URL::asset('public/front/css/bootstrap-grid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/front/css/icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/front/css/style.css')); ?>">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap" rel="stylesheet">   


</head>
<body>

<!-- Wrapper -->
<div id="wrapper"> 
  <!-- Header Container -->
  <header id="utf-header-container-block"> 
    <div id="header">
      <div class="container"> 
        
        
        <div class="utf-right-side"> 
          <?php 
            if(empty(Session::get('user_login_id'))){
          ?>
		          <div class="utf-header-widget-item"> <a href="<?php echo e(route('signin')); ?>" class="log-in-button"><i class="fa fa-sign-in"></i> <span>Sign In</span></a> </div>	

          <?php
            }else { 
              foreach ($user_details as $u) {
              
          ?>
    	  <div class="utf-header-widget-item"> 
            <div class="utf-header-notifications user-menu">
                <div class="utf-header-notifications-trigger user-profile-title">
                    <a href="#" style="color: #333;">
                     <i class="fa fa-user"></i>
                     <div class="user-name">Hi, <?php echo $u->user_name?></div> 
                    </a>
                </div>

                <?php 
                  if($u->user_type == 'Admin'){
                ?>
                <div class="utf-header-notifications-dropdown-block">
                    <ul class="utf-user-menu-dropdown-nav">
                      <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard </a></li>
                      <li><a href="<?php echo e(route('user_list')); ?>"><i class="fa fa-user-circle"></i> User List</a></li>
                      <li><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i>Logout</a></li>
                    </ul>
                </div>
                <?php }elseif($u->user_type == 'Employee'){ ?>
                <div class="utf-header-notifications-dropdown-block">
                    <ul class="utf-user-menu-dropdown-nav">
                      <li><a href="<?php echo e(route('my_profile')); ?>"><i class="fa fa-user-circle"></i> My Profile</a></li>
                      <li><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i>Logout</a></li>
                    </ul>
                </div>
                <?php }else{ ?>
                <div class="utf-header-notifications-dropdown-block">
                </div>
                <?php } ?>
            </div>
          </div>
          <?php } } ?>
          <span class="mmenu-trigger">
			<button class="hamburger utf-hamburger-collapse-item" type="button"> 
    			<span class="utf-hamburger-box-item"> 
    			    <span class="utf-hamburger-inner-item"></span> 
    			</span> 
			</button>
          </span> 
		</div>
      </div>
    </div>
  </header>
  <div class="clearfix"></div>
  <!-- Header Container / End -->
  
   <?php echo $__env->yieldContent('content'); ?>
  
</div>
<!-- Wrapper / End --> 

<!-- Scripts --> 
<script src="<?php echo e(URL::asset('public/front/js/jquery-3.3.1.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/jquery-migrate-3.0.0.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/mmenu.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/tippy.all.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/simplebar.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/bootstrap-slider.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/bootstrap-select.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/snackbar.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/clipboard.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/counterup.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/magnific-popup.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/slick.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('public/front/js/typed.js')); ?>"></script>
<script src="<?php echo e(URL::asset('public/front/js/custom_jquery.js')); ?>"></script> 

<script src="<?php echo e(URL::asset('public/admin/ckeditor/ckeditor.js')); ?>" type="text/javascript"></script>
<!-- Scripts --> 
<script> CKEDITOR.replace( 'responsibilities' );</script>
<script> CKEDITOR.replace( 'description' );</script>
<script> CKEDITOR.replace( 'course_description' );</script>

<script>
if ($('.utf-intro-banner-search-form-block')[0]) {
	setTimeout(function(){ 
		$(".pac-container").prependTo(".utf-intro-search-field-item.with-autocomplete");
	}, 300);
}
</script> 
<script>
var typed = new Typed('.typed-words', {
	strings: ["Web Designer."," Graphic Designer."," Logo Designer."," Sales Marketing."],
	typeSpeed: 80,
	backSpeed: 80,
	backDelay: 4000,
	startDelay: 1000,
	loop: true,
	showCursor: true
});
</script>

<script type="text/javascript">

    $(document).ready(function () {
    $('.registration-form fieldset:first-child').fadeIn('slow');

    $('.registration-form input[type="text"]').on('focus', function () {
        $(this).removeClass('input-error');
    });

    // next step
    $('.registration-form .btn-next').on('click', function () {
        var parent_fieldset = $(this).parents('fieldset');
        var next_step = true;

        parent_fieldset.find('input[type="text"],input[type="email"]').each(function () {
            if ($(this).val() == "") {
                $(this).addClass('input-error');
                next_step = false;
            } else {
                $(this).removeClass('input-error');
            }
        });

        if (next_step) {
            parent_fieldset.fadeOut(400, function () {
                $(this).next().fadeIn();
            });
        }

    });

    // previous step
    $('.registration-form .btn-previous').on('click', function () {
        $(this).parents('fieldset').fadeOut(400, function () {
            $(this).prev().fadeIn();
        });
    });

    // submit
    $('.registration-form').on('submit', function (e) {

        $(this).find('input[type="text"],input[type="email"]').each(function () {
            if ($(this).val() == "") {
                e.preventDefault();
                $(this).addClass('input-error');
            } else {
                $(this).removeClass('input-error');
            }
        });

    });

   
});
</script>

<script>
    $(document).ready(function() {
        var i=1;
        $('.add').on('click', function() {
            var task = $("#task").val();
            i++;  
            $('#dynamic_field').append('<div id="row'+i+'" class="dynamic-added"><div class="utf-no-border margin-bottom-20 row"><div class="col-8"><h3>Education</h3><br><span style="color:red">Required field</span></div><div class="col-2"><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></div></div><div class="utf-no-border margin-bottom-20"><input type="text" class="utf-with-border" name="university[]" id="task" placeholder="University" required/></div><div class="utf-no-border"><input type="text" class="utf-with-border" name="clg_name[]" id="task" placeholder="Collage Name" required/></div><div><input type="text" class="utf-with-border" name="degree[]" id="task" placeholder="Degree" required/></div><div><input type="text" class="utf-with-border" name="percentage[]" id="task" placeholder="Percentage" required/></div><div><input type="text" class="utf-with-border" name="passing_year[]" id="task" placeholder="Passing Year" required/></div></div>');  
            
            $(document).on('click', '.btn_remove', function(){  
                   var button_id = $(this).attr("id");   
                   $('#row'+button_id+'').remove();  
              });

            var ddlYears = $(".ddlYears");
            var currentYear = (new Date()).getFullYear();
            for (var i = 1950; i <= currentYear; i++) {
                var option = $("<option />");
                option.html(i);
                option.val(i);
                ddlYears.append(option);
            }

            var ddlmonth = $(".ddlmonth");
            var monthName = ["January","February","March","April","May","June","July","August","September","October","November","December"];
            for (var i =  0 ; i < monthName.length; i++) {
                var option = $("<option />");
                option.html(monthName[i]);
                option.val(monthName[i]);
                ddlmonth.append(option);
            }
        });  
    });
</script>

<script>
    $(document).ready(function() {
        var i=1;
        $('.addSkills').on('click', function() {
            var task = $("#taskSkill").val();
            i++;  
            $('#dynamic_skill_field').append('<div id="row'+i+'" class="dynamic-added"><div class="row"><div class="col-8"><div class="utf-no-border"><input type="text" class="utf-with-border" name="emailaddress" id="taskSkill" placeholder="Skills" required/></div></div><div class="col-2"><div><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></div></div>');  
            
            $(document).on('click', '.btn_remove', function(){  
                   var button_id = $(this).attr("id");   
                   $('#row'+button_id+'').remove();  
              });
            
        });
    });
</script>



<script type="text/javascript">
    $(function () {
        
        var ddlYears = $(".ddlYears");
 
        var currentYear = (new Date()).getFullYear();
 
        for (var i = 1950; i <= currentYear; i++) {
            var option = $("<option />");
            option.html(i);
            option.val(i);
            ddlYears.append(option);
        }
    });
</script>

<script type="text/javascript">
    $(function () {
        
        var ddlmonth = $(".ddlmonth");
  
        var monthName = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        
        for (var i =  0 ; i < monthName.length; i++) {
            var option = $("<option />");
            option.html(monthName[i]);
            option.val(monthName[i]);
            ddlmonth.append(option);
        }
    });
</script>

<script type="text/javascript">
  $(document).ready(function () {
    $('.courses fieldset:first-child').fadeIn('slow');

    // $('.courses input[type="text"]').on('focus', function () {
    //     $(this).removeClass('input-error');
    // });

    // next step
    $('.courses .btn-next').on('click', function () {
        var parent_fieldset = $(this).parents('fieldset');
        var next_step = true;

        // parent_fieldset.find('input[type="text"],input[type="email"]').each(function () {
        //     if ($(this).val() == "") {
        //         $(this).addClass('input-error');
        //         next_step = false;
        //     } else {
        //         $(this).removeClass('input-error');
        //     }
        // });

        if (next_step) {
            parent_fieldset.fadeOut(400, function () {
                $(this).next().fadeIn();
            });
        }

    });

    // previous step
    $('.courses .btn-previous').on('click', function () {
        $(this).parents('fieldset').fadeOut(400, function () {
            $(this).prev().fadeIn();
        });
    });

    // submit
    // $('.courses').on('submit', function (e) {

    //     $(this).find('input[type="text"],input[type="email"]').each(function () {
    //         if ($(this).val() == "") {
    //             e.preventDefault();
    //             $(this).addClass('input-error');
    //         } else {
    //             $(this).removeClass('input-error');
    //         }
    //     });

    // });

   
});
</script>



<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>


</body>
</html><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/layout.blade.php ENDPATH**/ ?>