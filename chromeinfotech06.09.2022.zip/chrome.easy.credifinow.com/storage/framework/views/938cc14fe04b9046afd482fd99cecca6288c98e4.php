
<?php $__env->startSection('content'); ?>


<!-- Start Blog Section -->
  <div class="st-blog-wrap st-section" id="blog">
    <div class="container">
      <div class="row">
        <?php
            foreach ($blog_details as $w) {
        ?>
        <div class="col-lg-8">
          <article class="post">
          	<header class="entry-header">
          		<div class="post-thumbnail">
          			<img src="<?php echo URL::asset('public/upload/blog_image/'.$w->blog_image.'') ?>" alt="demo">
          		</div>
          		<div class="post-details-wrap-outer">
          			<div class="post-details-wrap">
          				<h2 class="entry-title"><?php echo $w->heading; ?></h2>
          				<div class="byline">
          					<span class="author">
          						<a href="" class=""><i class="fa fa-user"></i>By <?php echo $w->blogger; ?></a>
          					</span>
          					<span class="posted-on"><i class="fa fa-calendar"></i><?php echo $w->mdate; ?></span>
          					
          				</div>
          			</div>
          		</div>
          	</header>
          	<div class="entry-content">
          		<p><?php echo $w->description; ?></p>
          	</div>
          </article>
        </div>
        <?php } ?>
        
        
        <aside class="col-lg-4">
          <div class="st-sidebar st-right-sidebar">
          
            <div class="widget widget_recent_entries">
              <h2 class="widget-title">Recent Post</h2>
              <ul>
                <?php
                    foreach ($latest_blog as $w) {
                ?>
                <li>
                  <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>">
                    <img src="<?php echo URL::asset('public/upload/blog_image/'.$w->blog_image.'') ?>" alt="demo">
                    <div class="r-post-head">
                      <h2><?php echo $w->heading; ?></h2>
                      <span><?php echo $w->mdate; ?></span>
                    </div>
                  </a>
                </li>
                <?php } ?>
              
              </ul>
            </div><!-- .widget -->
         
          </div>
        </aside>
        
      </div>
    </div>
  </div>
  <!-- End Blog Section -->


<?php $__env->stopSection(); ?>






<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/blog_details.blade.php ENDPATH**/ ?>