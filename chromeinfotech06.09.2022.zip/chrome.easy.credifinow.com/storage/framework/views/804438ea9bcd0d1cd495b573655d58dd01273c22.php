
<?php $__env->startSection('content'); ?>

  <div class="st-blog-wrap st-section" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <article class="post">
          	<header class="entry-header">
          	    <div class="post-details-wrap-outer">
          			<div class="post-details-wrap">
          			    <?php $__currentLoopData = $allcreditcard_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          				<h2 class="entry-title"><?php echo e($p->name); ?> Bank Credit Card</h2>
          				<p class="h4-font" style="font-size: 14px;">Apply online for <?php echo e($p->name); ?> Bank Credit Card: Check your <?php echo e($p->name); ?> 
          				Bank Credit Card Eligibility ✓ Offers ✓ Fee charges ✓ Reward Points ✓ Apply Online instantly 
                        </p>
          			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          			</div>
          		</div>
          		<div class="post-thumbnail">
          			<img src="<?php echo e(URL::asset('public/front/assets/img/light-img/user-landing-artwork.svg')); ?>" alt="demo">
          		</div>
          	</header>
          </article>
        </div>
        <aside class="col-lg-4">
          <div class="st-sidebar st-right-sidebar">
            <div class="widget widget_categories">
              <h2 class="widget-title">Check your <?php $__currentLoopData = $allcreditcard_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($p->name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> Bank credit card eligibility</h2>
              <div class="credit_card_box marg20t banner-box-shadow pad20t">
              <div class="row">
                  <div class="col-lg-8 ml-auto mr-auto">
                      <?php if(Session::has('regmsg')): ?>                 
                          <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                               <strong><?php echo e(Session::get('regmsg')); ?></strong>
                          </div>
                          <?php echo e(Session::forget('message')); ?>

                          <?php echo e(Session::forget('regmsg')); ?>

                      <?php endif; ?>
                  </div>
              </div>
              <div class="comment-respond">
          		<form method="post" class="comment-form" action="<?php echo e(route('credit_card_registration')); ?>">
                        <?php echo csrf_field(); ?>
                        
          		        <p class="comment-form-author text">
          				    <input name="fname" type="text" placeholder="First &amp; Last Name (as per PAN card)*" required="">
          			    </p>
          			    
          			    <p class="comment-form-author text">
                  				<select class="form-control" name="gender">
                  				    <option>--- Select Gender Type ---</option>
                  				    <option name="gender" value="Male">Male</option>
                  				    <option name="gender" value="Female">Female</option>
                  				</select>
                  		</p>
          	
              			<p class="comment-form-email text">
              				<input name="email" type="email" placeholder="E-mail Address*" required="">
              			</p>
              			
              			<p class="comment-form-url text">
              				<input id="url" name="mobile" type="tel" maxlength="10" placeholder="10 digit mobile number*" required="">
              			</p>
              			
              			<p class="comment-form-author text">
              			    <label style="color: #1caffd;">Date of Birth</label>
          				    <input name="dob" type="date" placeholder="Date of Birth" required="">
          			    </p>

              			<p class="comment-form-author text">
          				    <input name="pincode" type="number" placeholder="Current residence pincode" required="">
          			    </p>
          			    
          			    <p class="comment-form-author text">
          				    <input name="pannumber" type="text" placeholder="10 digit PAN Number" required="">
          			    </p>
          			    
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="employment">
                  				    <option>--- Select Employment Type ---</option>
                  				    <option value="Salaried">Salaried</option>
                  				    <option value="Self Employed">Self Employed</option>
                  			</select>
          			    </p>
          			    
          			    <p class="comment-form-email text">
              				<input name="company" type="text" placeholder="Current Company Name" required="">
              			</p>
              			
              			<p class="comment-form-email text">
              			    <label style="color: #1caffd;">Monthly in-hand salary</label>
              				<input name="income" type="text" placeholder="Monthly in-hand salary" value="₹ 0" required="">
              			</p>
              			
              			<p class="comment-form-author text">
              			    <select class="form-control" name="existing">
                  				    <option>Do you have an existing credit card?</option>
                  				    <option value="Yes">Yes</option>
                  				    <option value="No">No</option>
                  			</select>
          			    </p>
          			    
          			    <p class="comment-form-author text">
              			    <select class="form-control" name="cardname">
                                    <option value="" selected="">Select Card</option>
                                    <option value="MY Zone Credit Card">MY Zone Credit Card</option>
                                    <option value="Select Credit Card">Select Credit Card</option>
                                    <option value="Flipkart Credit Card">Flipkart Credit Card</option>
                                    <option value="IndianOil Credit Card">IndianOil Credit Card</option>
                                    <option value="Privilege Credit Card">Privilege Credit Card</option>
                                    <option value="Aura Credit Card">Aura Credit Card</option>
                                    <option value="Vistara Credit Card">Vistara Credit Card</option>
                                    <option value="Vistara Signature Credit Card">Vistara Signature Credit Card</option>
                                    <option value="Vistara Infinite Credit Card">Vistara Infinite Credit Card</option>
                  			</select>
          			    </p>

          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="font-size: 12px;"><span>Check Eligibility</span></button>
              			</p>
          			    
          		</form>
          	  </div>
          	  </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  </div>
  
  <div id="foot_cc" class="cards">
        <div class="clearfix"></div>
        <div class="container-fluid">

        <div class="faqs row pad0t">
            <div class="container">
                
                <br><br>
        
                <div class="text-center">
                    <h3 class="marg30b">Frequently Asked Questions</h3>
                    <h4>General Questions</h4>
                </div>
        
                <div id="accordion">
                    <h3 class="accordion-toggle">Q. What is a Credit Card?<span class="arrow arrowUp"></span></h3>
                    <div class="accordion-content default">
                        <p>A. A Credit Card is a plastic card issued by a financial institution which offers a line of credit to the customer to purchase goods/services. This line of credit comes with a limit which allows a customer to consume up to a specific amount, set by the financial institution which has offered the card.</p>
        
                    </div>
        
                    <h3 class="accordion-toggle">Q. How is a Credit Card different from a Debit Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. A Debit Card allows you to withdraw money which has already been deposited in you Bank. Hence, the money that is being used is deducted from your Bank account. However, a Credit Card is a form of Credit which is not related to your Personal bank accounts.</p>
                    </div>
        
        
        
                    <h3 class="accordion-toggle">Q. What are the features of a Credit Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. The features of a Credit Card are:</p>
                        <ol class="list-inside">
                            <li>Credit Cards have <b>universal acceptability</b>.</li>
                            <li>For using a Credit Card, a customer has to pay a fixed sum as annual fees. However, financial</li>
                            <li>Institutions generally waive off the charges if the customer meet a certain criteria in terms of his expenditure behaviour.</li>
                            <li> Credit Cards also come with a Balance Transfer option, allowing the customer to transfer its balance to another card and avail the benefits of cheaper interest rates.</li>
                            <li>Customers can settle the balance with Monthly EMIs.</li>
                            <li>Credit Cards come with a 24/7 service, unlike other card forms.</li>
                            <li>Customers can easily pay off their utility bills using Credit Cards.</li>
                        </ol>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What are the benefits of using a Credit Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. Using a Credit Card comes with a lot of benefits:</p>
                        <ol class="list-inside">
                            <li>Ease in payments while shopping, dining, travelling and settling bills.</li>
                            <li>Timely repayments on Credit Cards help in improving your Credit Score.</li>
                            <li>Access to premium services offered by the financial institution which issued the card.</li>
                            <li>Amazing discounts and cashbacks upon the purchases made using the card.</li>
                            <li>Access to more funds in times of immediate need</li>
                            <li>Expenditure tracking and monitoring using the modules offered.</li>
                        </ol>
                    </div>
        
        
                    <h3 class="accordion-toggle">Q. What is EMI? How is it calculated?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. An equated monthly instalment (EMI) is the amount of money that is paid back to the lender on a monthly basis. It is essentially made up of two parts, the principal amount and the interest on the principal amount equally divided across each month in pre-decided tenure. The EMI is always paid up to the bank or lender on a fixed date each month until the total amount due is paid up during the tenure.</p>
                    </div>
        
        
        
                    <h3 class="accordion-toggle">Q. Why will my Credit Card application be rejected?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>
                            A. If you have a bad Credit Score, have defaulted on repayments or don’t meet the basic criteria, you are likely to get rejected. If you do not meet the bank’s eligibility, you are likely to get rejected as well.
                        </p>
                    </div>
        
        
                    <div class="text-center marg30t">
        
                        <h4>Credit Card Eligibility Questions</h4>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What is the eligibility criteria for Credit Cards?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. Anyone - whether self-employed or salaried professionals — with a regular source of income can apply for a Credit Card. One must be 23 years old at the time of applying. One must also have a good credit history to be eligible for a Credit Card. If you are interested in checking your credit history and learning about your credit worthiness before applying for a Credit Card, <a href="https://indialends.com/free-credit-report" target="_blank" class="anchor-blue text-underline">click here</a>. </p>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What are the documents required for applying for a Credit Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. Financial Institutions generally request for the following documents as identity and address proof. of Credit which is not related to your Personal bank accounts.</p>
        
                        <ol class="list-inside">
                            <li> PAN Card</li>
                            <li>Passport</li>
                            <li> Driving License/Voter ID</li>
                            <li>Aadhar Card</li>
                            <li>Ration Card</li>
                        </ol>
        
        
                    </div>
        
                    <div class="text-center marg30t">
        
                        <h4>Application Process and Fee Questions</h4>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What are the other charges included in the Credit Cards process?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>IndiaLends does not charge its customers any fees for applying for Credit Cards on its platform. However, financial institutions can charge the following fees along with interest payments:</p>
                        <ol class="list-inside">
                            <li><b>Add on Card Fee</b> - The fee charged for applying for another card which shall have all the features of your primary Credit Card. </li>
                            <li><b>Extended Credit Charges</b> - It is a fee charged by financial institutions for extending the customer’s credit limit. </li>
                            <li><b>Cash Withdrawal Charges</b> – The charges paid by the customer to the financial institution for withdrawal of money.</li>
                        </ol>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What are the modes available for Credit Card bill payments?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. Net Banking, NEFT/RTGS Transfers, Debit Cards, Visa Money Transfer, Cash, Cheques, Demand Drafts are some of the ways of making Credit Card Bill Payments.</p>
                    </div>
        
                    <h3 class="accordion-toggle">Q. What factors should I consider while taking a Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
                        <p>A. You need to consider the following factors when you take a Credit Card:</p>
                        <ol class="list-inside">
                            <li> Purpose of the Credit Card</li>
                            <li> Expense behaviour to select the best Reward Scheme</li>
                            <li> Number of Credit Cards you’re currently holding. Ideally, a customer should hold not more than 3 Credit Cards </li>
                            <li>Any active loan/heavy EMI payment</li>
                            <li> Interest Rate on the card</li>
                            <li> Customer Service</li>
                        </ol>
        
                    </div>
        
                    <div class="text-center marg30t">
        
                        <h4>IndiaLends - Specific Questions</h4>
                    </div>
        
                    <h3 class="accordion-toggle">Q. Will I be charged by IndiaLends for services offered?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. No. The services offered by IndiaLends are completely free of charge.</p>
                    </div>
        
                    <h3 class="accordion-toggle">Q. After I submit my application to IndiaLends, what next?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. Once you fill-up our application form, your application will be matched with the best financial institution based on your credit profile, and will be securely sent to them. You will soon be contacted by the lender directly for disbursal.</p>
                    </div>
        
                    <h3 class="accordion-toggle">Q. How do I apply for a Credit Card with IndiaLends?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. You can fill-up our <a href="#top">short application form</a> and get a status update within minutes of applying.</p>
                    </div>
        
                    <h3 class="accordion-toggle">Q. Can I deactivate my Credit Card?<span class="arrow arrowDown"></span></h3>
                    <div class="accordion-content">
        
                        <p>A. Yes, Once you have decided to close your credit card, the first thing you need to do is to contact your card issuing bank and tell them regarding your card cancellation request. They will ask the reason behind your cancellation request to further guide you through the whole credit card cancellation procedure. According to the norms, you will have to send a written communication via email to your concerned bank so that they can verify and cross check the authenticity of the request. Do keep in mind, your cancellation request will only be accepted once your card holds no dues.</p>
                    </div>
        
                </div>
            </div>
        </div>

        </div>

 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/credit_card_.blade.php ENDPATH**/ ?>