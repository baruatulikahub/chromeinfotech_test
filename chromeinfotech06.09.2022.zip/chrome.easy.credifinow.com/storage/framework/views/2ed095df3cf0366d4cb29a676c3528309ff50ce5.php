
<?php $__env->startSection('content'); ?>

<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Source+Sans+Pro" rel="stylesheet">

<div class="content" style="margin-top:10px;">
  <div class="wrapper-1">
    <div class="wrapper-2">
      <h1>Thank you !</h1>
      <p>Your data is successfully registered!  </p>
      <button class="go-home">
      <a href="<?php echo e(route('index')); ?>">go to product page</a>
      </button>
    </div>
</div>
</div>



<br>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/chrome.easy.credifinow.com/resources/views/front/thank_you.blade.php ENDPATH**/ ?>