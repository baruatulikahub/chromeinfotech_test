
<?php $__env->startSection('content'); ?>

  
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 470px;">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
          		<form method="post" class="comment-form" action="<?php echo e(route('apply_color_registration')); ?>">
          		    <?php echo csrf_field(); ?>
          			    <p class="comment-form-author text">
              			    <input name="name" type="text" placeholder="Color Name*" required="">
          			    </p>
          			    <p class="comment-form-author text">
              			    <input name="code" type="text" placeholder="Color Code*" required="">
          			    </p>
          			    <p class="form-submit">
              				<button type="submit" class="st-btn st-style1 st-size1 st-color1" style="#"><span>Save <i class="fa fa-arrow-right push-right"></i></span></button>
              			</p>
          		</form>
          		
        </aside> 	
      </div>
      
    </div>
    
    
    <div>
        <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('colormsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('colormsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('colormsg')); ?>

                <?php endif; ?>
            </div>
        </div>
              <table id="memberProfile">
                
                <tr>
                  <td><strong>Sl No.</strong></td>
                  <td><strong>Color Name</strong></td>
                  <td><strong>Color Code</strong></td>
                  <td><strong>Edit</strong></td>
                  <td><strong>Delete</strong></td>
                </tr>
                <?php 
                    foreach ($color_details as $c) {
                ?>
                <tr>
                  <td><?php echo $c->id; ?></td>
                  <td><?php echo $c->name; ?></td>
                  <td><?php echo $c->code; ?></td>
                  <td class="">

                    <a class="dropdown-item" href="<?php echo route('edit_color_details',['id'=>''.$c->id.'']) ?>" data-toggle="modal" data-target="#" >Edit <i class="fa fa-pencil" aria-hidden="true"></i></a>
                  </td>
                  <td class="">
                    <a class="dropdown-item" onclick="alert('Are You Sure To Delete This?')" href="<?php echo route('delete_color_details',['id'=>''.$c->id.'']) ?>" >Delete <i class="fa fa-trash" aria-hidden="true"></i></a>
                  </td>
                </tr>
                <?php } ?>
              
              </table>
    </div>
    <br>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/chrome.easy.credifinow.com/resources/views/front/colors.blade.php ENDPATH**/ ?>