
<?php $__env->startSection('content'); ?>
  <!-- Header Container / End -->
  
  <br><br><br><br>
  <!-- Page Content -->
  <div class="container">
    <div class="row">
      <div class="col-xl-6 offset-xl-3">
        <div class="row">
          <div class="col-lg-8 ml-auto mr-auto">
              <?php if(Session::has('signinerrmsg')): ?>                 
                  <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                       <strong><?php echo e(Session::get('signinerrmsg')); ?></strong>
                  </div>
                  <?php echo e(Session::forget('message')); ?>

                  <?php echo e(Session::forget('signinerrmsg')); ?>

              <?php endif; ?>
          </div>
        </div>

        <div class="utf-login-register-page-aera"> 
          <div class="utf-welcome-text-item">
            <h3>Customer Login Page</h3>
            <span>Don't Have an Account? <a href="<?php echo e(route('register')); ?>" style="color:blue">Sign Up!</a></span> 
		  </div>
          <form method="post" id="login-form" action="<?php echo e(route('verify_login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="utf-no-border">
              <input type="text" class="utf-with-border" name="email" id="emailaddress" placeholder="Email Address" required/>
              <?php if($errors->has('email')): ?>
                <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>                                  
              <?php endif; ?>
            </div>
            <div class="utf-no-border">
              <input type="password" class="utf-with-border" name="password" id="myInput" placeholder="Password" required/>
              <?php if($errors->has('password')): ?>
                <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>                                  
              <?php endif; ?>
            </div>
			<div class="checkbox margin-top-10">
				<input type="checkbox" id="two-step" onclick="myFunction()">
				<label for="two-step"><span class="checkbox-icon"></span> Show Password</label>
			</div>
            
          </form>
          <button class="button full-width utf-button-sliding-icon ripple-effect margin-top-10" type="submit" form="login-form">Log In <i class="fa fa-arrow-right"></i></button>
          
        </div>
      </div>
    </div>
  </div>
  
  
  <br><br>
  
  
  <script type="text/javascript">
      function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
  </script>
  
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/signin.blade.php ENDPATH**/ ?>