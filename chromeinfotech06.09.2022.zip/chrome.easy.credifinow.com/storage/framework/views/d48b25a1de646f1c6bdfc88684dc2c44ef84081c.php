
<?php $__env->startSection('content'); ?>


<!-- Start Blog Section -->
  <div class="st-blog-wrap st-section" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="st-blog-list">
            <div class="row">
            <?php 
				foreach ($blog_details as $w) {
		    ?>
		    
              <div class="col-lg-6">
                <div class="st-blog st-style1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
                  <div class="st-zoom">
                    <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>" class="st-blog-thumb st-bg st-zoom-in" data-src="<?php echo URL::asset('public/upload/blog_image/'.$w->blog_image.'') ?>"></a>
                  </div>
                  <div class="st-blog-info" style="height: 200px;">
                    <div class="st-blog-label">By <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>"><?php echo $w->blogger; ?></a></div>
                    <h2 class="st-blog-title"><a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>"><?php echo $w->heading; ?></a></h2>
                    <div class="st-blog-text">
                        <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>">
                          <?php echo $w = substr(($w->description), 0,100);  ?>...
                        </a>
                    </div>
                
                  </div>
                </div>
              </div>
              
            <?php } ?>
             
            </div>
          </div>
          
          <br><br>
          
          <div class="row">
              <div class="col-sm-12 col-xs-12">
                <center>
                  <div class="pagination justify-content-center">
                      <?php echo $blog_details->links("pagination::bootstrap-4"); ?> 
                  </div> 
                </center>     
              </div>
          </div>
           
        </div>
        <aside class="col-lg-4">
          <div class="st-sidebar st-right-sidebar">
       
            <div class="widget widget_recent_entries">
              <h2 class="widget-title">Recent Post</h2>
              <ul>
                  
                <?php 
				    foreach ($latest_blog as $w) {
		        ?>
                <li>
                  <a href="<?php echo e(route('blog_details',['heading'=>''.$w->heading.''])); ?>">
                    <img src="<?php echo URL::asset('public/upload/blog_image/'.$w->blog_image.'') ?>" alt="demo">
                    <div class="r-post-head">
                      <h2><?php echo $w->heading; ?></h2>
                      <span><?php echo $w->mdate; ?></span>
                    </div>
                  </a>
                </li>
                <?php } ?>
                
              </ul>
            </div><!-- .widget -->
     
          </div>
        </aside>
      </div>
    </div>
  </div>
  <!-- End Blog Section -->
 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/blogs.blade.php ENDPATH**/ ?>