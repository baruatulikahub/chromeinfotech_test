
<?php $__env->startSection('content'); ?>

<div class="user-profile padding-top-80">

       <div class="row">
          <div class="col-lg-12 ml-auto mr-auto">
              <?php if(Session::has('profilemsg')): ?>                 
                  <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                       <strong><?php echo e(Session::get('profilemsg')); ?></strong>
                  </div>
                  <?php echo e(Session::forget('message')); ?>

                  <?php echo e(Session::forget('profilemsg')); ?>

              <?php endif; ?>
          </div>
      </div>

      <section class="profile padding-top-30">
        <header class="header">
          <?php 
            foreach ($user_details as $u) {
          ?>
          <div class="details">
       
            <h1 class="heading"><?php echo $u->user_name; ?></h1>
    
          </div>
          <?php } ?>
        </header>
      </section>

      <br>
      <?php 
            foreach ($user_details as $u) {
      ?>
          
      <?php 
          if($u->user_type == 'Employee'){
      ?>

      <section class="container pt-top">
        
        <div class="card">
          <div class="card-header">

            <div class="row">
                <div class="col-10"> User Information</div>
                <div class="col-2">
                    <a href="#">
                      <div class="user-name" style="font-weight: 600;color: #666;line-height: 20px;display: inline-block;font-size: 16px;"></div> 
                    </a>
                </div>
            </div>
           
          </div>
          <div class="card-body">
              <h5 class="card-title">Email : <?php echo $u->email; ?></h5>
              <h5 class="card-title">Password : <?php echo $u->show_password; ?></h5>
          </div>
        </div>

      </section>

      
      <?php }else{ ?>
      
      <?php } } ?>
      
      
</div>

<br><br>


 <script type="text/javascript">
$(document).ready(function() {
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.profile-pic').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    $(".file-upload").on('change', function(){
        readURL(this);
    });
    
    $(".upload-button").on('click', function() {
       $(".file-upload").click();
    });
});
</script>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/my_profile.blade.php ENDPATH**/ ?>