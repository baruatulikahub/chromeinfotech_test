
<?php $__env->startSection('content'); ?>

    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex">
        <div class="container">
          <div class="st-hero-text st-style1">
            <h2 class="st-hero-title"> Check your Credit Score & Report <br/>in just 1 minute.</h2>
            <div class="st-hero-subtitle">
              It determines your TouchLess loan and credit line eligibility.
            </div>
            <div class="st-cta-btn">
                <a href="#" class="st-btn st-style1 st-size1 st-color1">Check Your Score</a>
            </div>
          </div>
        </div>
        <div class="st-hero-img"><img src="<?php echo e(URL::asset('public/front/assets/img/light-img/emi-cal2.png')); ?>" alt="demo"></div>
      </div>
    </div>
    
    <div class="why-people row">
        <div class="container text-center">
             <br><br>
            <h2>Why CredifiNow?</h2>
            <!-- <p class="para">CIBIL requires accurate details to ensure accuracy & security. <br />Make sure they match your banking records</p> -->
            <div class="col-sm-12 pad0 marg20t marg20b">
                <div class="col-sm-4 col-xs-12">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/security.png')); ?>" class="security" src="<?php echo e(URL::asset('public/front/assets/img/light-img/security.png')); ?>">
                    <h4>Security</h4>
                    <p>We use 128-bit encryption to protect the transmission of your data to our site.</p>
                </div>
                <div class="col-sm-4 col-xs-12" style="margin-left: 331px; margin-top: -180px;">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/privacy.png')); ?>" class="security" src="<?php echo e(URL::asset('public/front/assets/img/light-img/privacy.png')); ?>">
                    <h4>Privacy</h4>
                    <p>We do not share your personal information with any third parties for their own marketing purposes.</p>
                </div>
                <div class="col-sm-4 col-xs-12" style="margin-left: 710px; margin-top: -180px;">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/free-100.png')); ?>" class="security" src="<?php echo e(URL::asset('public/front/assets/img/light-img/free-100.png')); ?>">
                    <h4>100% Free</h4>
                    <p>IndiaLends services are completely free and we will never charge you for any of our services</p>
                </div>
            </div>
            <a href="<?php echo e(route('personal_loan')); ?>" onclick="#" class="btn btn-blue-border secondary bg-transparent display-inline marg30b sm-marg10b">Get Started</a>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/credit_report.blade.php ENDPATH**/ ?>