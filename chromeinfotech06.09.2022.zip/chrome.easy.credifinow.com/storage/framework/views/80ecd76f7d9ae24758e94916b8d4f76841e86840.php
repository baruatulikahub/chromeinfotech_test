
<?php $__env->startSection('content'); ?>
  <!-- Main content -->
  
    <!-- Header -->
    <!-- Header -->
    <div class="header pb-6 d-flex align-items-center" style="min-height: 150px; background-size: cover; background-position: center top;">
      
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
         <div class="row">
            <div class="col-lg-12 ml-auto mr-auto">
                <?php if(Session::has('bannermsg')): ?>                 
                    <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                         <strong><?php echo e(Session::get('bannermsg')); ?></strong>
                    </div>
                    <?php echo e(Session::forget('message')); ?>

                    <?php echo e(Session::forget('bannermsg')); ?>

                <?php endif; ?>
            </div>
        </div>
      <div class="row">
        <!--<div class="col-xl-4 order-xl-2">-->
        <!--  <div class="card card-profile">-->
        <!--    <img src="assets/img/theme/img-1-1000x600.jpg" alt="Image placeholder" class="card-img-top">-->
        <!--    <div class="row justify-content-center">-->
        <!--      <div class="col-lg-3 order-lg-2">-->
        <!--        <div class="card-profile-image">-->
        <!--          <a href="#">-->
        <!--            <img src="assets/img/theme/team-4.jpg" class="rounded-circle">-->
        <!--          </a>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">-->
        <!--      <div class="d-flex justify-content-between">-->
        <!--        <a href="#" class="btn btn-sm btn-info  mr-4 ">Connect</a>-->
        <!--        <a href="#" class="btn btn-sm btn-default float-right">Message</a>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--    <div class="card-body pt-0">-->
        <!--      <div class="row">-->
        <!--        <div class="col">-->
        <!--          <div class="card-profile-stats d-flex justify-content-center">-->
        <!--            <div>-->
        <!--              <span class="heading">22</span>-->
        <!--              <span class="description">Friends</span>-->
        <!--            </div>-->
        <!--            <div>-->
        <!--              <span class="heading">10</span>-->
        <!--              <span class="description">Photos</span>-->
        <!--            </div>-->
        <!--            <div>-->
        <!--              <span class="heading">89</span>-->
        <!--              <span class="description">Comments</span>-->
        <!--            </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--      </div>-->
        <!--      <div class="text-center">-->
        <!--        <h5 class="h3">-->
        <!--          Jessica Jones<span class="font-weight-light">, 27</span>-->
        <!--        </h5>-->
        <!--        <div class="h5 font-weight-300">-->
        <!--          <i class="ni location_pin mr-2"></i>Bucharest, Romania-->
        <!--        </div>-->
        <!--        <div class="h5 mt-4">-->
        <!--          <i class="ni business_briefcase-24 mr-2"></i>Solution Manager - Creative Tim Officer-->
        <!--        </div>-->
        <!--        <div>-->
        <!--          <i class="ni education_hat mr-2"></i>University of Computer Science-->
        <!--        </div>-->
        <!--      </div>-->
        <!--    </div>-->
        <!--  </div>-->
        <!--</div>-->
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            <!--<div class="card-header">-->
            <!--  <div class="row align-items-center">-->
            <!--    <div class="col-8">-->
            <!--      <h3 class="mb-0">Edit profile </h3>-->
            <!--    </div>-->
                <!--<div class="col-4 text-right">-->
                <!--  <a href="#!" class="btn btn-sm btn-primary">Settings</a>-->
                <!--</div>-->
            <!--  </div>-->
            <!--</div>-->
            <div class="card-body">
              <form method="post" action="<?php echo e(route('submit_client_details')); ?>" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                <h6 class="heading-small text-muted mb-4">Client Details</h6>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Client Name</label>
                        <input type="text" id="input-username" name="title" class="form-control" placeholder="Client Title">
                        <?php if($errors->has('title')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('title')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-first-name"> Client image</label>
                        <input type="file" class="form-control" name="client_image" id="image" accept="image/*">
                        <?php if($errors->has('client_image')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('client_image')); ?></strong>                                   
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                 
                </div>

                <div class="col-sm-4">
                    <div class="form-group bmd-form-group">
                        <button type="submit" class="btn btn-success btn-block">Submit</button>
                    </div>
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
    </div>  

<?php $__env->stopSection(); ?>
  <!-- Argon Scripts -->
  
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/add_client.blade.php ENDPATH**/ ?>