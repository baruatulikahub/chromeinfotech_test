
<?php $__env->startSection('content'); ?>


<?php 
    foreach ($color_details as $s) {
?>
  <div class="st-content" >
    
    <div class="st-hero-slider1 owl-carousel st-owl-controler2" id="home">
      <div class="st-hero-slide st-style1 st-flex st-tw-flx" style="height: 600px;">
        
        <aside class="col-lg-9 extended-card form-card">
                <div class="card-header extended-card-header" id="loaderCardHeader"><b>ChromeInfotech-Interview (Assignment)</b></div>
                <br>
                <form method="post" action="<?php echo e(route('update_color_details')); ?>" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled">
                                                          <label class="form-control-label" for="input-username">Color Name </label>
                                                          <input type="hidden" class="form-control" name="update" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                                          <input type="text" name="name" id="input-username" class="form-control" Value="<?php echo $s->name?>" placeholder="Color Name">
                                                          <?php if($errors->has('name')): ?>
                                                            <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>                                   
                                                          <?php endif; ?>
                                                        </div>
                                                      </div>

                                                      <div class="col-md-12">  
                                                        <div class="form-group bmd-form-group is-filled">
                                                          <label class="form-control-label" for="input-username">Color Code </label>
                                                          <input type="hidden" class="form-control" name="update" value="<?php echo $s->id; ?>" autocomplete="off" required="" >
                                                          <input type="text" name="code" id="input-username" class="form-control" Value="<?php echo $s->code?>" placeholder="Size Code">
                                                          <?php if($errors->has('code')): ?>
                                                            <strong class="text-danger"><?php echo e($errors->first('code')); ?></strong>                                   
                                                          <?php endif; ?>
                                                        </div>
                                                      </div>
                
                                                      <div class="col-sm-12">
                                                        <div class="form-group bmd-form-group">
                                                            <button type="submit" class="btn btn-success btn-block">Update</button>
                                                        </div>
                                                      </div>
                
                                                    </div>
                                                </form>
        </aside> 	
      </div>
      
    </div>
    
  </div>
  
<?php } ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/chrome.easy.credifinow.com/resources/views/front/edit_color_details.blade.php ENDPATH**/ ?>