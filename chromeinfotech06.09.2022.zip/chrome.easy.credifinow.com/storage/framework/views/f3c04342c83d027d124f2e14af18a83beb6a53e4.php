
<?php $__env->startSection('content'); ?>


  <div class="st-blog-wrap" id="blog" style="margin-top:55px;">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
         <div class="white-container bg-white"> 
            <div class="row">
                  <div class="col-lg-8 ml-auto mr-auto">
                      <?php if(Session::has('regmsg')): ?>                 
                          <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                               <strong><?php echo e(Session::get('regmsg')); ?></strong>
                          </div>
                          <?php echo e(Session::forget('message')); ?>

                          <?php echo e(Session::forget('regmsg')); ?>

                      <?php endif; ?>
                  </div>
            </div>
          	<div class="comment-respond">
          		<h2 class="comment-reply-title b-h1">Let’s get started</h2>
          		<p class="b-p1">Generate your loan offer with a few basic details</p>
          		<br>
          		<form method="post" class="comment-form" action="<?php echo e(route('business_loan_registration')); ?>">
          		    <?php echo csrf_field(); ?>
                  			<div class="col-sm-6">
                  			    <label for="dob">Full Name (As per PAN Card)</label>
                  				<input name="fname" type="text" placeholder="Full Name (As per PAN Card)*" required="">
                  			</div>
                  			<div class="col-sm-6">
                  			    <label for="gender">Gender</label>
                  				<select class="form-control" name="gender">
                  				    <option>--- Select Gender Type ---</option>
                  				    <option name="gender" value="Male">Male</option>
                  				    <option name="gender" value="Female">Female</option>
                  				</select>
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label for="dob">Mobile Number</label>
                  				<input name="mobile" type="tel" maxlength="10" placeholder="Mobile Number*" required="">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label for="dob">Email Address</label>
                  				<input name="email" type="email" placeholder="Email Address*" required="">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label for="dob">Date of Birth as per your PAN</label>
                  				<input name="dob" type="date" placeholder="Date of Birth as per your PAN" required="">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label for="dob">Enter your 10 digit PAN Number!</label>
                  				<input name="pannumber" type="text" placeholder="10 digit PAN number" required="">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label>Current Company Name</label>
                  				<input name="company" type="text" placeholder="Enter Company Name">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label>Current Residence Pincode</label>
                  				<input name="pincode" type="number" placeholder="Enter your Residence Pincode">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label>Monthly in-hand Salary</label>
                  				<input name="income" type="number" placeholder="Enter your Income">
                  			</div>
                  			<div class="col-sm-6" style="margin-top: 10px;">
                  			    <label>Employment Type</label>
                  				<select class="form-control" name="employment">
                  				    <option>--- Select Employment Type ---</option>
                  				    <option value="Salaried">Salaried</option>
                  				    <option value="Self Employed">Self Employed</option>
                  				    <option value="Self Employed (Dr./CA)">Self Employed (Dr./CA)</option>
                  				</select>
                  			</div>
                  			<br>
                  			<div class="col-sm-12 text-center mt-5 pb-md-0 pb-5">
                  				<button type="submit" class="st-btn st-style1 st-size1 st-color1"><span>Get Offers</span></button>
                  				<p class="imp-text">By clicking, I agree to the <a href="#" target="_blank" style="color: #1CAFFD;">Terms &amp; Conditions</a> and <a href="#" target="_blank" style="color: #1CAFFD;">Privacy Policy</a> of CredifiNow</p>
                  			</div>
                  		</form>
          	</div>
         </div>
        </div>
      </div>
    </div>
  </div>
  
  <section class="light-grey-bg2 apply-padding">
    <div class="container text-center">
        <span class="apply-now-text">Are you a salaried person? <br class="d-sm-none">Apply for a personal loan.</span>
        <span><button type="button" class="btn btn-primary b-btn apply-b-btn" onclick="window.location = 'personal-loan';">Apply Now</button></span>
    </div>
  </section>
  
   <div class="st-funfact-wrap st-section-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-sm-6">
            <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
              <div class="st-funfact-icon"><i class="flaticon-rate"></i></div>
              <!--<h2 class="st-funfact-number st-counter">999</h2>-->
              <h3 class="st-funfact-title">Business Loan without collateral</h3>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6">
            <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.25s">
              <div class="st-funfact-icon"><i class="fa fa-university"></i></div>
              <!--<h2 class="st-funfact-number st-counter">185</h2>-->
              <h3 class="st-funfact-title">Avail Business Loans sitting at home</h3>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6">
            <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
              <div class="st-funfact-icon"><i class="fas fa-hand-holding-usd"></i></div>
              <!--<h2 class="st-funfact-number st-counter">100</h2>-->
              <h3 class="st-funfact-title">Fast disbursal</h3>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6">
            <div class="st-funfact text-center wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.35s">
              <div class="st-funfact-icon"><i class="flaticon-win"></i></div>
              <!--<h2 class="st-funfact-number st-counter">200</h2>-->
              <h3 class="st-funfact-title">Fair and Transparent</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  
  <br><br>
  <section class="light-grey-bg2 section-padding">
    <div class="container text-center">
        <div>
            <p class="doc-required-text">
                Documents Required for a Business Loan
            </p>
        </div>

        <div class="col-12 p-0 table-responsive text-center business-table">

            <table class="table table-bordered mb-0">
                <tbody>
                    <tr class="highlighted-head">
                        <td class="font-weight-bold"></td>
                        <td class="font-weight-bold">Proprietorship</td>
                        <td class="font-weight-bold position-relative"><span class="cs">Coming Soon</span>Partnership</td>
                        <td class="font-weight-bold position-relative"><span class="cs">Coming Soon</span>Pvt. Ltd. / LLP / One <br>Person Company</td>
                    </tr>
                    <tr class="bg-white">
                        <td class="text-left">Bank statement<br>(12 months)</td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                    </tr>
                    <tr class="grey-head">
                        <td class="text-left ">Business <br>registration proof</td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                    </tr>
                    <tr class="bg-white">
                        <td class="text-left">Proprietor(s) PAN <br>Card Copy</td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                    </tr>
                    <tr class="grey-head">
                        <td class="text-left">Partnership Deed <br>Copy</td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" class="crossed-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" class="crossed-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" data-was-processed="true">
                        </td>
                    </tr>
                    <tr class="bg-white">
                        <td class="text-left">Company PAN Card <br>Copy</td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" class="crossed-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/crossed.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="checked-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                        <td>
                            <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" class="crossed-img lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/checked.png')); ?>" data-was-processed="true">
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-12 text-center pb-md-0 pb-5 p-0">
            <a type="button" class="btn btn-primary b-btn spacing-btn" href="#middle">Fund my business</a>
            <p class="fund-text">Superfast Processing | No Collateral | Fair Interest Rates</p>

            <p class="proof-text mb-0">We accept any of the following as a Business registration proof</p>
            <p class="proof-text mt-0 d-sm-block d-none"><span class="pr-4">1. Business Registration Certificate</span>  <span class="pr-4">2. GST filing</span>   <span class="pr-4">3. Gumastadhara</span>   <span class="pr-4">4. Trade License</span>   <span class="pr-4">5. Drug License</span>  <span class="pr-4">6. TIN</span>   7. VAT registration</p>

            <p class="proof-text mt-0 d-sm-none mt-4">1. Business Registration Certificate</p>
            <p class="proof-text mt-0 d-sm-none">2. GST filinge</p>
            <p class="proof-text mt-0 d-sm-none">3. Gumastadhara</p>
            <p class="proof-text mt-0 d-sm-none">4. Trade License</p>
            <p class="proof-text mt-0 d-sm-none">5. Drug License</p>
            <p class="proof-text mt-0 d-sm-none">6. TIN</p>
            <p class="proof-text mt-0 d-sm-none">7. VAT registration</p>

        </div>

    </div>

</section>

  <section class="section-padding">
    <div class="container text-center">
        <p class="doc-required-text">
            Why CredifiNow
        </p>
        <p class="why-text mb-5">We know that as a business owner, time is money—and so is cash flow. That’s why we make it our mission to help you get the money you need when you need it. We are here to help you grow your business, regardless of whether or not you have collateral in place.</p>
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-4 col-12 text-center pb-md-0 px-5">
                <div class="why-points mt-5">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/why1.png')); ?>" class="lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/why1.png')); ?>" data-was-processed="true" style="height: 100px;">
                    <p class="mt-5 mb-4 why-points-text">Instant Loan Approval</p>
                    <p class="mb-0 why-points-text1">
                        Get your loan request approved and disbursed in less than 72 hours.
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-12 text-center pb-md-0 px-5">
                <div class="why-points mt-5">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/why2.png')); ?>" class="lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/why2.png')); ?>" data-was-processed="true" style="height: 100px;">
                    <p class="mt-5 mb-4 why-points-text">Paperless <br>Process</p>
                    <p class="mb-0 why-points-text1">
                        No documentation, no lengthy forms to fill out, just a paperless process.
                    </p>
                </div>
            </div>
            <div class="col-md-4 col-12 text-center pb-md-0 px-5">
                <div class="why-points mt-5">
                    <img data-src="<?php echo e(URL::asset('public/front/assets/img/light-img/why3.png')); ?>" class="lazy loaded" src="<?php echo e(URL::asset('public/front/assets/img/light-img/why3.png')); ?>" data-was-processed="true" style="height: 100px;">
                    <p class="mt-5 mb-4 why-points-text">Zero Collateral Required</p>
                    <p class="mb-0 why-points-text1">
                        Unsecured loans, no need to submit collateral and property for security.
                    </p>
                </div>
            </div>
        </div>
        <div class="col-sm-12 text-center pb-md-0 pb-5 p-0">
            <a href="#middle" class="scrollTo"><button type="button" class="btn btn-primary b-btn spacing-btn">Fund my business</button></a>
            <p class="fund-text">Superfast Processing | No Collateral | Fair Interest Rates</p>
        </div>
    </div>
</section>

  <h1 style="text-align:center;">Frequently asked questions</h1>

  <div class="wrapper">
      
      <div class="container">
        <div class="question">
          What is a business loan and what purpose does it serve?
        </div>
        
        <div class="answercont">
          <div class="answer">
            A business loan refers to the borrowed capital that helps businesses or companies meet their financial needs. Simply put, it is borrowing money for business needs and then repaying it at a fixed interest rate. It helps organizations, especially small and mid-sized businesses, to fund their business investments and projects and remove all the financial barriers that might hinder the completion of a particular project.
          </div>
        </div>
      </div>

      <div class="container">
        <div class="question">
          What are the benefits of taking a business loan from CredifiNow? 
        </div>
       
        <div class="answercont">
          <div class="answer">
            <p>The following are the benefits of taking loans from CredifiNow:</p>
            <p>1. Three-steps process, thus allowing you to get loan very quickly.</p>
            <p>2. The process only takes 3 days, while banks may take 8-10 working days to complete the process.</p>
            <p>3. Reasonable &amp; lower interest rates.</p>
            <p>4. Unsecured loans I.e., no need to submit any collateral or property for security.</p>
            <p>5. No hidden charges or additional costs. Also, no additional penalties for a loan foreclosure.</p>
          </div>
        </div>
       </div>
       
      <div class="container">
        <div class="question">
          How to apply for loans through CredifiNow? 
        </div>
       
        <div class="answercont">
          <div class="answer">
            <p>The best thing about borrowing loans from CredifiNow is that it is a 3-step process and is completely an online procedure.</p>
            <p>1. The first step is to submit your application for the loan. In this step, you must submit all your personal, business, and financial information to receive a business loan offer.</p>
            <p>2. The second step involves updating the documents for verification. </p>
            <p>3. In the third step you must relax as your loan is getting approved and you can expect the disbursal within 3 working days. </p>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="question">
          What are the eligibility criteria to get business loans from CredifiNow?
        </div>
        
        <div class="answercont">
          <div class="answer">
            If you are an established organization that has been in the business for over 6 months with a turnover of more than INR 90K, you are fully eligible to get loans from CredifiNow.
          </div>
        </div>
      </div>

      <div class="container">
        <div class="question">
          How can I check the application status for my business loans?
        </div>
       
        <div class="answercont">
          <div class="answer">
            You can check your loan application status by logging into your CredifiNow account or you can also contact our customer support team at <a href="mailto:support@credifiNow.com">support@credifiNow.com</a>.
          </div>
        </div>
      </div>
 
      <div class="container">
        <div class="question">
          What is the maximum amount of loan I can get from CredifiNow?
        </div>
       
        <div class="answercont">
          <div class="answer">
            <p>INR 2 Crores is the maximum amount of loan one can borrow from CredifiNow. </p>
          </div>
        </div>
      </div>
     
 </div>
 
 <br>
    
  <div class="pg-footer dark-blue-bg">
    <footer class="dark-blue-bg" id="footer">
      
      <div class="footer-content">
        <div class="footer-content-column col-pro-log">
          <div class="footer-logo">
            <a class="footer-logo-link" href="#">
             <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/footer-logo.png')); ?>" alt="demo">
            </a>
          </div>
          <br>
          <div class="mt-5">
            <div class="img-hover-zoom">
                <a href="#" target="_blank" title="Facebook">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/facebook.svg')); ?>" alt="Facebook">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/facebook.svg')); ?>" alt="Facebook" class="hover">
                </a>
            </div>                
            <div class="img-hover-zoom">
                <a href="#" target="_blank" title="Instagram">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/instagram.svg')); ?>" alt="Instagram">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/instagram.svg')); ?>" alt="Instagram" class="hover">
                </a>
            </div>
            <div class="img-hover-zoom">
                <a href="#" target="_blank" title="Linkedin">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/linkedin.svg')); ?>" alt="LinkedIn">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/linkedin.svg')); ?>" alt="LinkedIn" class="hover">
                </a>
            </div>
            <div class="img-hover-zoom">
                <a href="#" target="_blank" title="Twitter" gtitle="Twitter">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/twitter.svg')); ?>" alt="Twitter">
                    <img src="<?php echo e(URL::asset('public/front/assets/img/light-img/twitter.svg')); ?>" alt="Twitter" class="hover">
                </a>
            </div>
          </div>
        </div>
        <div class="footer-content-column col-pro">
          <div class="footer-menu">
            <h2 class="footer-menu-name col-pro"> Products</h2>
            <ul id="menu-get-started" class="footer-menu-list">
              <li class="menu-item menu-item-type-post_type menu-item-object-product color-pro">
                <a href="<?php echo e(route('personal_loan')); ?>">Personal Loans</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-product color-pro">
                <a href="<?php echo e(route('business_loan')); ?>">Business Loan</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-product color-pro">
                <a href="#">Credit Cards</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-product color-pro">
                <a href="<?php echo e(route('credit_report')); ?>">Credit Score</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-product color-pro">
                <a href="<?php echo e(route('gold_loan')); ?>">Gold Loan</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-content-column col-pro">
          <div class="footer-menu">
            <h2 class="footer-menu-name col-pro"> Resources</h2>
            <ul id="menu-company" class="footer-menu-list">
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a href="<?php echo e(route('emi_calculator')); ?>">EMI Calculator</a>
              </li>
              <li class="menu-item menu-item-type-taxonomy menu-item-object-category color-pro">
                <a href="#">IFSC Code</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a href="<?php echo e(route('faqs')); ?>">FAQs</a>
              </li>
              <li class="menu-item menu-item-type-taxonomy menu-item-object-category color-pro">
                <a href="#">My Dashboard</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a href="#">PAN Card</a>
              </li>
              <li class="menu-item menu-item-type-taxonomy menu-item-object-category color-pro">
                <a href="#">Tax</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a href="#">Credit Cards in India</a>
              </li>
            </ul>
          </div>
       
        </div>
        <div class="footer-content-column col-pro">
          <div class="footer-menu">
            <h2 class="footer-menu-name col-pro"> Company</h2>
            <ul id="menu-quick-links" class="footer-menu-list">
              <li class="menu-item menu-item-type-custom menu-item-object-custom color-pro">
                <a target="_blank" rel="noopener noreferrer" href="#">About Us</a>
              </li>
              <li class="menu-item menu-item-type-custom menu-item-object-custom color-pro">
                <a target="_blank" rel="noopener noreferrer" href="#">Blogs</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a href="#<?php echo e(route('contact_us')); ?>">Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="footer-content-column col-pro">
          <div class="footer-call-to-action">
            <h2 class="footer-call-to-action-title col-pro"> MORE</h2>
            <ul id="menu-quick-links" class="footer-menu-list">
              <li class="menu-item menu-item-type-custom menu-item-object-custom color-pro">
                <a target="_blank" href="#">Help Desk</a>
              </li>
              <li class="menu-item menu-item-type-custom menu-item-object-custom color-pro">
                <a target="_blank" href="<?php echo e(route('privacy_policy')); ?>">Privacy Policy</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a target="_blank" href="<?php echo e(route('terms_conditions')); ?>">Terms & Conditions</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a target="_blank" href="#">Offers T&C</a>
              </li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page color-pro">
                <a target="_blank" href="#">Lender Compliance</a>
              </li>
            </ul>
            
          </div>
          
        </div>
      </div>
      
    </footer>
  </div>  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layoutother', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/front/business_loan.blade.php ENDPATH**/ ?>