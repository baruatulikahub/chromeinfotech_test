
<?php $__env->startSection('content'); ?>
  
    <br><br><br><br><br>
    <div class="container-fluid mt--6">

       <div class="row">
        <div class="col-lg-8 ml-auto mr-auto">
            <?php if(Session::has('passwordmsg')): ?>                 
                <div class="alert alert-<?php echo e(Session::get('message')); ?> alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>  
                     <strong><?php echo e(Session::get('passwordmsg')); ?></strong>
                </div>
                <?php echo e(Session::forget('message')); ?>

                <?php echo e(Session::forget('passwordmsg')); ?>

            <?php endif; ?>
            <br><br>
        </div>
      </div>

     

      <div class="row">
        <div class="col-xl-12 order-xl-1">
          <div class="card">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Change Password</h3>
                </div>
              </div>
            </div>
            <div class="card-body">
             <form method="post" action="<?php echo e(route('update_password')); ?>" >
              <?php echo csrf_field(); ?>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Old Password</label>
                        <input type="password" id="input-username" class="form-control" name="old" placeholder="Old Password" required="">
                        <?php if($errors->has('old')): ?>
                          <strong class="text-danger"><?php echo e($errors->first('old')); ?></strong>                                  
                        <?php endif; ?>
                      </div>
                    </div>
                    
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-last-name">New Password</label>
                         <input type="password" id="input-username" class="form-control" name="new" placeholder="New Password" required="">
                        <?php if($errors->has('new')): ?>
                            <strong class="text-danger"><?php echo e($errors->first('new')); ?></strong>                                  
                        <?php endif; ?>
                      </div>
                    </div>

                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-control-label" for="input-last-name">Confirm Password</label>
                         <input type="password" id="input-username" class="form-control" name="con" placeholder="Confirm Password" required="">
                        <?php if($errors->has('con')): ?>
                            <strong class="text-danger"><?php echo e($errors->first('con')); ?></strong>                                  
                        <?php endif; ?>
                      </div>
                    </div>

                    <div class="col-sm-4">
                      <div class="form-group bmd-form-group">
                          <button type="submit" class="btn btn-success btn-block">Submit</button>
                      </div>
                  </div>

                  </div>
                </div>              
              </form>
            </div>
          </div>
        </div>
      </div>

      
      

     

    </div>

    
      
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/amarbixg/public_html/loan-laravel/resources/views/admin/setting.blade.php ENDPATH**/ ?>