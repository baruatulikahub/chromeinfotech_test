
<?php $__env->startSection('content'); ?>

  <br>
  <!-- Icon Boxes -->
  <div class="section gray padding-top-100">
    <div class="container">
      <div class="row">
        <div class="col-xl-12"> 
          <div class="utf-section-headline-item centered margin-top-0 margin-bottom-40">

            <?php 
            foreach ($user_details as $u) {?>
			<h3> Hi, <b style="color:#21218b"><?php echo $u->user_name?></b>! 
			<?php 
		
                  if($u->user_type == 'Admin'){
            ?>
			<br>Welcome Admin Portal</h3>
			<?php }elseif($u->user_type == 'Employee'){ ?>
			
			<br>Welcome Employee Portal</h3>
			
			<?php }else{ ?>
			
			<?php }  ?>
			
			<?php } ?>
			
			<?php 
			foreach ($user_details as $u) {
                  if($u->user_type == 'Admin'){
            ?>
		
			<a href="<?php echo e(route('user_list')); ?>"><span>View User List <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a>
			
			<?php }elseif($u->user_type == 'Employee'){ ?>
			<a href="<?php echo e(route('my_profile')); ?>"><span>Check Your Profile <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a>
			<?php }else{ ?>
			
		    
            
			<?php } } ?>
          </div>
        </div>
	
      </div>
    </div>
  </div>
  <!-- Icon Boxes / End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/luckyy5b/public_html/tulikatest06.07.2022/resources/views/front/my_dashboard.blade.php ENDPATH**/ ?>