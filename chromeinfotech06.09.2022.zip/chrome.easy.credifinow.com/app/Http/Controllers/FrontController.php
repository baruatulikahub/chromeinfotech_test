<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;
use Validator;
use Session;
use Mail;
use Image;
use App\Models\sizes;
use App\Models\products;
use App\Models\categories;
use App\Models\colors;
use Illuminate\Support\Str;
use Carbon\Carbon;

class FrontController extends Controller
{

   	public function index()
    {   
        $data['category_details']=categories::orderby('id','asc')->get();
        $data['color_details']=colors::orderby('id','asc')->get();
        $data['size_details']=sizes::orderby('id','asc')->get();
        $data['product_details']=products::orderby('id','asc')->get();
        
        // $data['product_by_details'] = products::join('colors', 'colors.id', '=', 'products.color_id')
        // ->join('sizes', 'sizes.id', '=', 'products.size_id')
        // ->get();
        
        //echo $data['product_by_details']; exit();
        
        return view('front/index')->with($data);
    }
    
    public function colors()
    {   
        $data['color_details']=colors::orderby('id','asc')->get();
        return view('front/colors')->with($data);
    }
    
    public function categories()
    {   
        $data['category_details']=categories::orderby('id','asc')->get();
        return view('front/categories')->with($data);
    }
    
    public function sizes()
    {   
        $data['size_details']=sizes::orderby('id','asc')->get();
        return view('front/sizes')->with($data);
    }
    
    public function apply_color_registration(Request $request)
    {
        
        Validator::make(
                      $request->all(),
                      [                  
                          'name'    => ['required', 'string'],
                          'code'   => ['required','string'],
                      ]
                  )->validate();
			
				$result=colors::create([
				    
                  'name'=>$request->name,
                  'code'=>$request->code,
              ]);
              
                //echo $result; exit();

				if($result==true)
				{
					session(['message' =>'success', 'regmsg' =>'Your color data is now successfully registered!']);

					return redirect('thank_you');
				}
				else
				{
					session(['message' =>'danger', 'regmsg'=>'Your color data is not successfully registered!']); 
					return redirect()->back();
				}
			
	}
	
	public function apply_category_registration(Request $request)
    {
        
        Validator::make(
                      $request->all(),
                      [                  
                          'cat_name'    => ['required', 'string'],
                      ]
                  )->validate();
			
				$result=categories::create([
				    
                  'cat_name'=>$request->cat_name,
              ]);
              
                //echo $result; exit();

				if($result==true)
				{
					session(['message' =>'success', 'regmsg' =>'Your category is now successfully registered!']);

					return redirect('thank_you');
				}
				else
				{
					session(['message' =>'danger', 'regmsg'=>'Your category is not successfully registered!']); 
					return redirect()->back();
				}
			
	}
	
	public function apply_size_registration(Request $request)
    {
        
        Validator::make(
                      $request->all(),
                      [                  
                          'code' => ['required', 'string'],
                          'sort' => ['required','string'],
                      ]
                  )->validate();
			
				$result=sizes::create([
                  'code'=>$request->code,
                  'sort'=>$request->sort,
              ]);
              
                //echo $result; exit();

				if($result==true)
				{
					session(['message' =>'success', 'regmsg' =>'Your size data is now successfully registered!']);

					return redirect('thank_you');
				}
				else
				{
					session(['message' =>'danger', 'regmsg'=>'Your size data is now successfully registered!']); 
					return redirect()->back();
				}
			
	}
    
    public function apply_product_registration(Request $request)
    {
        
        Validator::make(
               $request->all(),
                      [                  
                          'pname' => ['required', 'string'],
                          'color_id' => ['required', 'string'],
                          'category_id' => ['required', 'string'],
                          'size_id' => ['required','string'],
                          'price' => ['required','string'],
                      ]
                  )->validate();
			
				$result=products::create([
                  'pname'=>$request->pname,
                  'color_id'=>$request->color_id,
                  'category_id'=>$request->category_id,
                  'size_id'=>$request->size_id,
                  'price'=>$request->price,
              ]);
              
                //echo $result; exit();

				if($result==true)
				{
					session(['message' =>'success', 'regmsg' =>'Your product data is now successfully registered!']);

					return redirect('thank_you');
				}
				else
				{
					session(['message' =>'danger', 'regmsg'=>'Your product data is now successfully registered!']); 
					return redirect()->back();
				}
	}
    
    public function thank_you()
    { 
        return view('front/thank_you');
    }
    
    public function edit_size_details()
    {   
        $data['size_details']=sizes::orderby('id','asc')->get();
        return view('front/edit_size_details')->with($data);
    }
    
    public function edit_color_details()
    {   
        $data['color_details']=colors::orderby('id','asc')->get();
        return view('front/edit_color_details')->with($data);
    }
    
    public function edit_category_details()
    {   
        $data['category_details']=categories::orderby('id','asc')->get();
        return view('front/edit_category_details')->with($data);
    }
    
    public function delete_size_details($id)
    {   
       $res=sizes::find($id)->delete();
        
        if($res==true)
        {
            session(['message' =>'success', 'sizemsg' =>'Delete Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'sizemsg'=>'Delete Failed.']); 
            return redirect()->back();
        }
    }
    
    public function delete_color_details($id)
    {   
       $res=colors::find($id)->delete();
        
        if($res==true)
        {
            session(['message' =>'success', 'colorsmsg' =>'Delete Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'colorsmsg'=>'Delete Failed.']); 
            return redirect()->back();
        }
    }
    
    public function delete_category_details($id)
    {   
       $res=categories::find($id)->delete();
        
        if($res==true)
        {
            session(['message' =>'success', 'sizemsg' =>'Delete Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'sizemsg'=>'Delete Failed.']); 
            return redirect()->back();
        }
    }
    
    public function update_size_details(Request $request)
    {   
       Validator::make(
            $request->all(),
            [
                'code' => ['required'],
                'sort'=>['required'],
            ]
        )->validate();
      
       $result=sizes::where('id', $request->update)->update([
            
            'code'=>$request->code,
            'sort'=>$request->sort,

          ]);
    
       if($result==true)
        {
            session(['message' =>'success', 'sizemsg' =>'Update Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'sizemsg'=>'Update Failed.']); 
            return redirect()->back();
        }
    }
    
    public function update_category_details(Request $request)
    {   
       Validator::make(
            $request->all(),
            [
                'name' => ['required'],
            ]
        )->validate();
      
       $result=categories::where('id', $request->update)->update([
            
            'name'=>$request->name,

          ]);
    
       if($result==true)
        {
            session(['message' =>'success', 'categorymsg' =>'Update Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'categorymsg'=>'Update Failed.']); 
            return redirect()->back();
        }
    }
    
    public function update_color_details(Request $request)
    {   
       Validator::make(
            $request->all(),
            [
                'code' => ['required'],
                'name'=>['required'],
            ]
        )->validate();
      
       $result=colors::where('id', $request->update)->update([
            
            'code'=>$request->code,
            'name'=>$request->name,

          ]);
    
       if($result==true)
        {
            session(['message' =>'success', 'colormsg' =>'Update Successfully.']);
            return redirect()->back();
        }
        else
        {
            session(['message' =>'danger', 'colormsg'=>'Update Failed.']); 
            return redirect()->back();
        }
    }

}
